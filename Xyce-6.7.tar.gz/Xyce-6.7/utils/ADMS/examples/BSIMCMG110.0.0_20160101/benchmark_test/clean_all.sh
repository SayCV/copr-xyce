#!/bin/bash
rm -f *.ac* *.ic* *.pa* *.st* *.val *.sw* *.tr* *.sc* *.mt* *.ma* sxcmd.log acsymm.sp acsymm.lis *.out *.ms* *.valog
rm -rf *.pvadir *.ahdlSimDB
