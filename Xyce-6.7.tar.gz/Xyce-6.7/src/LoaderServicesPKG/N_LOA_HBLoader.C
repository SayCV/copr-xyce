//-----------------------------------------------------------------------------
// Copyright Notice
//
//   Copyright 2002 Sandia Corporation. Under the terms
//   of Contract DE-AC04-94AL85000 with Sandia Corporation, the U.S.
//   Government retains certain rights in this software.
//
//    Xyce(TM) Parallel Electrical Simulator
//    Copyright (C) 2002-2017 Sandia Corporation
//
//    This program is free software: you can redistribute it and/or modify
//    it under the terms of the GNU General Public License as published by
//    the Free Software Foundation, either version 3 of the License, or
//    (at your option) any later version.
//
//    This program is distributed in the hope that it will be useful,
//    but WITHOUT ANY WARRANTY; without even the implied warranty of
//    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//    GNU General Public License for more details.
//
//    You should have received a copy of the GNU General Public License
//    along with this program.  If not, see <http://www.gnu.org/licenses/>.
//-----------------------------------------------------------------------------

//-----------------------------------------------------------------------------
// Purpose       :
// Special Notes :
// Creator       :
// Creation Date :
//
//-----------------------------------------------------------------------------

#include <Xyce_config.h>


// ---------- Standard Includes ----------
#include <iostream>

// ----------   Xyce Includes   ----------

#include <N_LOA_HBLoader.h>
#include <N_ERH_ErrorMgr.h>

#include <N_LAS_Builder.h>
#include <N_LAS_HBBuilder.h>
#include <N_LAS_Matrix.h>
#include <N_LAS_BlockVector.h>
#include <N_LAS_BlockMatrix.h>
#include <N_LAS_FilteredMatrix.h>
#include <N_LAS_BlockSystemHelpers.h>
#include <N_LAS_SystemHelpers.h>
#include <N_LAS_MultiVector.h>

#include <N_UTL_fwd.h>
#include <N_UTL_FeatureTest.h>
#include <N_UTL_Math.h>

#include <N_PDS_ParMap.h>
#include <N_DEV_DeviceMgr.h>

#include <Epetra_BlockMap.h>
#include <Epetra_CrsGraph.h>
#include <Epetra_CrsMatrix.h>

#include <N_PDS_Comm.h>  

using Teuchos::rcp;
using Teuchos::RCP;
using Teuchos::rcp_dynamic_cast;

namespace Xyce {
namespace Loader {

HBLoader::HBLoader(
  Device::DeviceMgr &                 device_manager,
  Linear::Builder &                   builder,
  const int refID,
  const bool hbOsc)
  : CktLoader(device_manager, builder),
    periodicTimesOffset_(0),
    period_(0),
    refID_(refID),
    hbOsc_(hbOsc),
    matrixFreeFlag_(false),
    deviceManager_(device_manager),
    builder_(builder)
{
  // Now initialize all the time domain working vectors.
  appVecPtr_ = rcp(builder_.createVector());
  appNextStaVecPtr_ = rcp(builder_.createStateVector());
  appCurrStaVecPtr_ = rcp(builder_.createStateVector());
  appLastStaVecPtr_ = rcp(builder_.createStateVector());

  appdQdxPtr_ = rcp(builder_.createMatrix());
  appdFdxPtr_ = rcp(builder_.createMatrix());

  appNextStoVecPtr_ = rcp(builder_.createStoreVector());
  appCurrStoVecPtr_ = rcp(builder_.createStoreVector());
  
  appNextLeadFVecPtr_ = rcp(builder.createLeadCurrentVector());
  appLeadQVecPtr_     = rcp(builder.createLeadCurrentVector());
  appNextJunctionVVecPtr_ = rcp(builder.createLeadCurrentVector());
}

//-----------------------------------------------------------------------------
// Function      : HBLoader::registerHBBuilder
// Purpose       : Registration method for the HB builder
// Special Notes :
// Scope         : public
// Creator       : Heidi Thornquist, Sandia Labs
// Creation Date : 11/08/13
//-----------------------------------------------------------------------------
void HBLoader::registerHBBuilder( Teuchos::RCP<Linear::HBBuilder> hbBuilderPtr )
{
  hbBuilderPtr_ = hbBuilderPtr;

  if (hbOsc_)
    bQPtr_ = hbBuilderPtr_->createExpandedRealFormTransposeBlockVector();

  // Now initialize all the frequency domain working vectors.
  bXtPtr_ = hbBuilderPtr_->createTimeDomainBlockVector();
  bVtPtr_ = hbBuilderPtr_->createTimeDomainBlockVector();

  // Vectors related to lead currents
//  bStoreVecFreqPtr_ = hbBuilderPtr_->createExpandedRealFormTransposeStoreBlockVector();

  bLeadCurrentVecFreqPtr_ = hbBuilderPtr_->createExpandedRealFormTransposeLeadCurrentBlockVector();
  bLeadCurrentQVecFreqPtr_ = hbBuilderPtr_->createExpandedRealFormTransposeLeadCurrentBlockVector();
}

//-----------------------------------------------------------------------------
// Function      : HBLoader::setFreq
// Purpose       : Assign times for fast time scale
// Special Notes :
// Scope         : public
// Creator       :
// Creation Date :
//-----------------------------------------------------------------------------
void HBLoader::setHBFreqs( const std::vector<double> & freqs)
{
   freqs_ = freqs;
}



//-----------------------------------------------------------------------------
// Function      : HBLoader::setFastTimes
// Purpose       : Assign times for fast time scale
// Special Notes :
// Scope         : public
// Creator       :
// Creation Date :
//-----------------------------------------------------------------------------
void HBLoader::setFastTimes( const std::vector<double> & times )
{
  times_ = times;
}

//-----------------------------------------------------------------------------
// Function      : HBLoader::loadDAEMatrices
// Purpose       :
// Special Notes :
// Scope         : public
// Creator       :
// Creation Date :
//-----------------------------------------------------------------------------
bool HBLoader::loadDAEMatrices( Linear::Vector * X,
                                Linear::Vector * S,
                                Linear::Vector * dSdt,
                                Linear::Vector * Store,
                                Linear::Matrix * dQdx,
                                Linear::Matrix * dFdx,
                                int loadType)
{
  if (matrixFreeFlag_)
  {
    if (DEBUG_HB)
    {
      Xyce::dout() << std::endl
                   << Xyce::section_divider << std::endl
                   << "  HBLoader::loadDAEMatrices:  matrixFree case" << std::endl;
    }

    dQdx->put(0.0);
    dFdx->put(0.0);
  }
  else
  {
    Report::DevelFatal0().in("HBLoader::loadDAEMatrices") << "This function actually was called in a non matrix free case";
  }

  return(true);
  
}

//-----------------------------------------------------------------------------
// Function      : HBLoader::applyDAEMatrices
// Purpose       :
// Special Notes :
// Scope         : public
// Creator       :
// Creation Date :
//-----------------------------------------------------------------------------
bool HBLoader::applyDAEMatrices( Linear::Vector * Xf,
                                 Linear::Vector * S,
                                 Linear::Vector * dSdt,
                                 Linear::Vector * Store,
                                 const Linear::Vector & Vf,
                                 Linear::Vector * dQdxV,
                                 Linear::Vector * dFdxV )
{
  if (!matrixFreeFlag_)
  {
    Report::DevelFatal0().in("HBLoader::applyDAEMatrices") << "This function should only be called in the matrix free case";
  }
  if (DEBUG_HB) 
  {
    Xyce::dout() << std::endl
                 << Xyce::section_divider << std::endl
                 << "  HBLoader::applyDAEMatrices" << std::endl;
  }

  const std::vector<int> & augmentedLIDs = hbBuilderPtr_->getAugmentedLIDs();
  double fScalar = 1.0;

  double vfScalar = 0.0;

  Linear::BlockVector & bXf = *dynamic_cast<Linear::BlockVector*>(Xf);

  // We have to do something special with Vf because AztecOO (or Belos)
  // probably used the Epetra_LinearProblem's Epetra_Maps to create the input
  // vector here.  In this case, Vf is just an Linear::Vector and not a
  // Linear::BlockVector.
  const Linear::BlockVector bVf(Vf, bXf.blockSize());

  if (hbOsc_)
  {
    double tmpfScalar = 0.0;   

    double tmpVf = 0.0; 

    if (augmentedLIDs.size() )
    {
      tmpfScalar = (*Xf)[(augmentedLIDs)[0 ]];
      tmpVf = (Vf)[(augmentedLIDs)[0 ]];
    }

    Xf->pmap()->pdsComm().sumAll( &tmpfScalar, &fScalar, 1 );
    Xf->pmap()->pdsComm().sumAll( &tmpVf, &vfScalar, 1 );

  }

  Linear::BlockVector * bdQdxV = dynamic_cast<Linear::BlockVector*>(dQdxV);
  Linear::BlockVector * bdFdxV = dynamic_cast<Linear::BlockVector*>(dFdxV);

  std::vector<double> norm(1, 0.0);
  Vf.infNorm( &norm[0] );
  if (norm[0] > 0.0)
  {
    // Calculate contributions of the portion of the Jacobian relating to the nonlinear devices.
    permutedIFT(bVf, &*bVtPtr_);

    // Initialize resulting vector, since operations on separated Jacobian may not touch every entry.
    bdFdxV->putScalar( 0.0 );
    bdQdxV->putScalar( 0.0 );

    Teuchos::RCP<Linear::BlockVector>  bdQdxVt = hbBuilderPtr_->createTimeDomainBlockVector();
    Teuchos::RCP<Linear::BlockVector>  bdFdxVt = hbBuilderPtr_->createTimeDomainBlockVector();

    int BlockCount = bVtPtr_->blockCount();

    for( int i = 0; i < BlockCount; ++i )
    {
      if (DEBUG_HB)
      {
        Xyce::dout() << "Processing diagonal matrix block " << i << " of " << BlockCount-1 << std::endl;
      }

      // Get the already stored nonlinear time-domain Jacobian matrices
      vecNLAppdQdxPtr_[ i ]->matvec( bVtPtr_->block(i), bdQdxVt->block(i) );
      vecNLAppdFdxPtr_[ i ]->matvec( bVtPtr_->block(i), bdFdxVt->block(i) );

      if (DEBUG_HB)
      {
        Xyce::dout() << "bVtPtr block i = " << i << " : " << std::endl;
        bVtPtr_->block(i).printPetraObject(dout());

        Xyce::dout() << "bdQdxVt block i = " << i << " : " << std::endl;
        bdQdxVt->block(i).printPetraObject(dout());

        Xyce::dout() << "bdFdxVt block i = " << i << " : " << std::endl;
        bdFdxVt->block(i).printPetraObject(dout());
      }
    }

    permutedFFT(*bdQdxVt, bdQdxV, &nonlinQNZRows_);
    permutedFFT(*bdFdxVt, bdFdxV, &nonlinFNZRows_);

    int blockCount = bXf.blockCount();
    int blockSize = bXf.block(0).globalLength();

    int size_ = freqs_.size();
    int posFreq = (size_-1)/2;
    double omega = 2.0 * M_PI * freqs_[posFreq] * fScalar;

    // Add in contributions from part of Jacobian related to the linear devices.
    // Act on bVf or Vf, see if we can put it into a MultiVector and 
    // apply linAppdQdxPtr_ and linAppdFdxPtr_ to the transpose.

    Teuchos::RCP<Linear::BlockVector> permlindQdxV = hbBuilderPtr_->createExpandedRealFormTransposeBlockVector();
    Teuchos::RCP<Linear::BlockVector> permlindFdxV = hbBuilderPtr_->createExpandedRealFormTransposeBlockVector();

    applyLinearMatrices (bVf, *permlindQdxV, *permlindFdxV);

    if(!linAppdFdxPtr_->isEmpty()) 
    {
      bdFdxV->update (1.0, *permlindFdxV, 1.0);
    } 
    if(!linAppdQdxPtr_->isEmpty()) 
    {
      bdQdxV->update (1.0, *permlindQdxV, 1.0);
    }

    Teuchos::RCP<Linear::BlockVector> bQVec = hbBuilderPtr_->createExpandedRealFormTransposeBlockVector();
    double omega_1 = 2.0 * M_PI * freqs_[posFreq];

    Teuchos::RCP<Linear::BlockVector> bcolVec;

    if (hbOsc_) 
      bcolVec = hbBuilderPtr_->createExpandedRealFormTransposeBlockVector();

    for( int i = 0; i < blockCount; ++i )
    {
    // QVec needs to be created here since only one processor owns each block
    // and we do not know which one it is in parallel.
      Linear::Vector& QVec = bQVec->block(i);
      Linear::Vector& freqVec = bdQdxV->block(i);

    // Only one processor owns each block of the frequency-domain vector
      if (freqVec.localLength() > 0)
      {
        omega = 2.0 * M_PI * freqs_[posFreq] * fScalar;

        QVec[0] = -freqVec[1]*omega;
        QVec[1] = freqVec[0]*omega;
        

        for (int j=1; j < (blockSize/2+1)/2; ++j)
        {
          omega = 2.0 * M_PI * freqs_[posFreq+j] * fScalar;
          QVec[2*j] = -freqVec[2*j+1]*omega;
          QVec[2*(blockSize/2-j)] = -freqVec[2*j+1]*omega;

          QVec[2*j+1] = freqVec[2*j]*omega;
          QVec[2*(blockSize/2-j)+1] = -freqVec[2*j]*omega;
        }

        bdFdxV->block(i).update(1.0, QVec , 1.0);

      }

      if ( hbOsc_ && freqVec.localLength() > 0 )
      {

        Linear::Vector& fcolVec = bcolVec->block(i);
        Linear::Vector& fqVec = bQPtr_->block(i);

        omega_1 = 2.0 * M_PI * freqs_[posFreq];
        fcolVec[0] = -fqVec[1]*omega_1;
        fcolVec[1]  = fqVec[0]*omega_1;

        for (int j=1; j < (blockSize/2+1)/2; ++j)
        {
          omega_1 = 2.0 * M_PI * freqs_[posFreq+j];

          fcolVec[2*j] = -fqVec[2*j+1]*omega_1;
          fcolVec[2*(blockSize/2-j)] = -fqVec[2*j+1]*omega_1;

          fcolVec[2*j+1] = fqVec[2*j]*omega_1;
          fcolVec[2*(blockSize/2-j)+1] = -fqVec[2*j]*omega_1;
        }

        bdFdxV->block(i).update(vfScalar, fcolVec, 1.0);
      }

    }

  }
  else
  {
    // X is zero, so Y is zero.
    bdQdxV->putScalar( 0.0 );
    bdFdxV->putScalar( 0.0 );
  }

  if (hbOsc_)
  {

//    if (augmentedLIDs.size() )
//      (*bdFdxV)[(augmentedLIDs)[0 ]] = Vf[(augmentedLIDs)[0 ]];
    double refValue = 0.0;
    double tmpValue= 0.0;
    Linear::Vector & freqVec = bVf.block(refID_);

    if (freqVec.localLength() > 0)
    {
       tmpValue = freqVec[3];
    }

    bXf.pmap()->pdsComm().sumAll( &tmpValue, &refValue, 1 );

    if (augmentedLIDs.size() )
      (*bdFdxV)[(augmentedLIDs)[0 ]] = refValue;
  }

  if (DEBUG_HB)
  {
    Xyce::dout() << "HB bVf:" << std::endl;
    bVf.printPetraObject(std::cout);
    Xyce::dout() << "HB bdQdxV:" << std::endl;
    bdQdxV->printPetraObject(std::cout);
    Xyce::dout() << "HB bdFdxV:" << std::endl;
    bdFdxV->printPetraObject(std::cout);

    Xyce::dout() << Xyce::section_divider << std::endl;
  }

  return true;

}

//-----------------------------------------------------------------------------
// Function      : HBLoader::updateState
// Purpose       :
// Special Notes : ERK.  This function needs to be a no-op.  The reason
//                 is that the state information needs to be the same
//                 at the time of updateState, loadDAEVectors and
//                 loadDAEMatrices.  Thus, they have to all happen inside
//                 of the same "fast time" loop.  So, this functionality
//                 has been moved up into loadDAEVectors.
//
//                 Note: for similar reasons, loadDAEMatrices is called from
//                 within that function as well.
//
// Scope         : public
// Creator       : Todd Coffey, 1414
// Creation Date : 01/17/07
//-----------------------------------------------------------------------------
bool HBLoader::updateState
 (Linear::Vector * nextSolVectorPtr,
  Linear::Vector * currSolVectorPtr,
  Linear::Vector * lastSolVectorPtr,
  Linear::Vector * nextStaVectorPtr,
  Linear::Vector * currStaVectorPtr,
  Linear::Vector * lastStaVectorPtr,
  Linear::Vector * nextStoVectorPtr,
  Linear::Vector * currStoVectorPtr,
  int loadType
  )
{
  bool bsuccess = true;

  // For HB case, this needs to be a no-op.

  return bsuccess;
}
//-----------------------------------------------------------------------------
// Function      : HBLoader::applyLinearMatrices
// Purpose       : apply matrices related to linear nodes
// Special Notes : This is done in frequency domain
// Scope         : public
//
// Creator       : Ting Mei and Heidi Thornquist
// Creation Date : 04/10/2015
//-----------------------------------------------------------------------------
bool HBLoader::applyLinearMatrices( const Linear::BlockVector & bVf,
                                    Linear::BlockVector & permlindQdxV,
                                    Linear::BlockVector & permlindFdxV )
{

  if ( !linAppdQdxPtr_->isEmpty() || !linAppdFdxPtr_->isEmpty())
  {
    Linear::MultiVector lindQdxV( *(bVtPtr_->blockPmap()), bVf.blockSize()/2 );
    Linear::MultiVector lindFdxV( *(bVtPtr_->blockPmap()), bVf.blockSize()/2 );

    int first = bVf.startBlock();
    Linear::MultiVector permVf( *(bVtPtr_->blockPmap()), bVf.blockSize()/2 );

    // Now copy over data for the blocks that this processor owns.
    for (std::vector<int>::iterator it = linNZRows_.begin(); it != linNZRows_.end(); it++)
    {
      int row = *it;

      Linear::Vector & currBlock = bVf.block(first + row);

      // Insert zero-th value of the Fourier expansion, only need real value.
      permVf[0][row] = currBlock[0];
      for (int j=1; j<currBlock.localLength()/2; j++) 
      {
        permVf[j][row] = currBlock[j+1];
      } 
    }

    linAppdQdxPtr_->matvec(permVf, lindQdxV);
    linAppdFdxPtr_->matvec(permVf, lindFdxV);

    int numharms = bVtPtr_->blockCount();

    // Now copy over data for the blocks that this processor owns.
    for (std::vector<int>::iterator it = linNZRows_.begin(); it != linNZRows_.end(); it++)
    {
      int row = *it;

      if (!linAppdQdxPtr_->isEmpty())
      {
        Linear::Vector & currBlock = permlindQdxV.block(first + row);

        currBlock[0] = lindQdxV[0][row];
        currBlock[1] = 0.0;

        for (int j=1; j< (numharms + 1)/2; j++)
        {
          currBlock[2*j] = lindQdxV[2*j-1][row];
          currBlock[2*(numharms-j)] = lindQdxV[2*j-1][row];
     
          currBlock[2*j+1] = lindQdxV[2*j][row];
          currBlock[2*( numharms - j) + 1] = -lindQdxV[2*j][row];
        }
      }

      if (!linAppdFdxPtr_->isEmpty())
      {
        Linear::Vector & currBlockF = permlindFdxV.block(first + row);
        currBlockF[0] = lindFdxV[0][row];
        currBlockF[1] = 0.0;

        for (int j=1; j< (numharms + 1)/2; j++)
        {
          currBlockF[2*j] = lindFdxV[2*j-1][row];
          currBlockF[2*(numharms-j)] = lindFdxV[2*j-1][row];

          currBlockF[2*j+1] = lindFdxV[2*j][row];
          currBlockF[2*( numharms - j) + 1] = -lindFdxV[2*j][row];
        }
      }
    }
  }
  return true;
}


//-----------------------------------------------------------------------------
// Function      : HBLoader::loadDAEVectors
// Purpose       :
// Special Notes :
// Scope         : public
// Creator       :
// Creation Date :
//-----------------------------------------------------------------------------
bool HBLoader::loadDAEVectors( Linear::Vector * Xf,
                               Linear::Vector * currX,
                               Linear::Vector * lastX,
                               Linear::Vector * S,
                               Linear::Vector * currS,
                               Linear::Vector * lastS,
                               Linear::Vector * dSdt,
                               Linear::Vector * Store,
                               Linear::Vector * currStore,
                               Linear::Vector * nextLeadFVectorPtr,
                               Linear::Vector * nextLeadQVectorPtr,
                               Linear::Vector * nextJunctionVVectorPtr,
                               Linear::Vector * Q,
                               Linear::Vector * F,
                               Linear::Vector * B,
                               Linear::Vector * dFdxdVp,
                               Linear::Vector * dQdxdVp,
                               int loadType )
{
  if (DEBUG_HB)
  {
    Xyce::dout() << std::endl
                 << Xyce::section_divider << std::endl
                 << "  HBLoader::loadDAEVectors" << std::endl;
  }

  //Zero out vectors
  appVecPtr_->putScalar(0.0);
  appNextStaVecPtr_->putScalar(0.0);
  appCurrStaVecPtr_->putScalar(0.0);
  appLastStaVecPtr_->putScalar(0.0);
  Linear::Vector appdSdt( *appNextStaVecPtr_ );

  appNextStoVecPtr_->putScalar(0.0);
  appCurrStoVecPtr_->putScalar(0.0);

  Linear::Vector * appQ = builder_.createVector();
  Linear::Vector * appF = builder_.createVector();
  Linear::Vector * appB = builder_.createVector();

  Linear::Vector * appdFdxdVp = builder_.createVector();
  Linear::Vector * appdQdxdVp = builder_.createVector();

  bXtPtr_->putScalar(0.0);

  Linear::BlockVector & bXf = *dynamic_cast<Linear::BlockVector*>(Xf);

  permutedIFT(bXf, &*bXtPtr_);

  const std::vector<int> & augmentedLIDs = hbBuilderPtr_->getAugmentedLIDs();
  double fScalar = 1.0;


  if (hbOsc_)
  {
    double tmpfScalar = 0.0;   

    if (augmentedLIDs.size() )
      tmpfScalar = (*Xf)[(augmentedLIDs)[0 ]];

    Xf->pmap()->pdsComm().sumAll( &tmpfScalar, &fScalar, 1 );
  }


  // 12/8/06 tscoffe:   Note:  "b" at beginning of variable name means Linear::BlockVector
  Linear::BlockVector & bX = *bXtPtr_;
  Linear::BlockVector & bS = *dynamic_cast<Linear::BlockVector*>(S);
  Linear::BlockVector & bcurrS = *dynamic_cast<Linear::BlockVector*>(currS);
  Linear::BlockVector & blastS = *dynamic_cast<Linear::BlockVector*>(lastS);
  Linear::BlockVector & bdSdt = *dynamic_cast<Linear::BlockVector*>(dSdt);
  Linear::BlockVector & bStore = *dynamic_cast<Linear::BlockVector*>(Store);
  Linear::BlockVector & bcurrStore = *dynamic_cast<Linear::BlockVector*>(currStore);
  
  Linear::BlockVector & bNextLeadF = *dynamic_cast<Linear::BlockVector*>(nextLeadFVectorPtr);
  Linear::BlockVector & bLeadQ = *dynamic_cast<Linear::BlockVector*>(nextLeadQVectorPtr);
  Linear::BlockVector & bNextJunctionV = *dynamic_cast<Linear::BlockVector*>(nextJunctionVVectorPtr);
  
  Linear::BlockVector * bQ = dynamic_cast<Linear::BlockVector*>(Q);
  Linear::BlockVector * bF = dynamic_cast<Linear::BlockVector*>(F);
  Linear::BlockVector * bB = dynamic_cast<Linear::BlockVector*>(B);

  Linear::BlockVector * bdFdxdVp = dynamic_cast<Linear::BlockVector*>(dFdxdVp);
  Linear::BlockVector * bdQdxdVp = dynamic_cast<Linear::BlockVector*>(dQdxdVp);

  Teuchos::RCP<Linear::BlockVector> bQt = hbBuilderPtr_->createTimeDomainBlockVector();
  Teuchos::RCP<Linear::BlockVector> bFt = hbBuilderPtr_->createTimeDomainBlockVector();
  Teuchos::RCP<Linear::BlockVector> bBt = hbBuilderPtr_->createTimeDomainBlockVector();

  Teuchos::RCP<Linear::BlockVector> bdQdxdVpt = hbBuilderPtr_->createTimeDomainBlockVector();
  Teuchos::RCP<Linear::BlockVector> bdFdxdVpt = hbBuilderPtr_->createTimeDomainBlockVector();

  int BlockCount = bX.blockCount();

  if (vecNLAppdQdxPtr_.size() != BlockCount)
  {
    vecNLAppdQdxPtr_.resize( BlockCount );
    vecNLAppdFdxPtr_.resize( BlockCount );
  }

  int nlQrows = nonlinQNZRows_.size();
  int nlFrows = nonlinFNZRows_.size();

  // Now perform implicit application of frequency domain Jacobian. 
  for( int i = 0; i < BlockCount; ++i )
  {
    if (DEBUG_HB)
    {
      Xyce::dout() << "Processing vectors for block " << i << " of " << BlockCount-1 << std::endl;
    }

    //Set Time for fast time scale somewhere
//    state_.fastTime = times_[i];

    deviceManager_.setFastTime( times_[i]/ fScalar);

    if (DEBUG_HB)
    {
      Xyce::dout() << "Calling updateSources on the appLoader" << std::endl;
    }

    //Update the sources
    appLoaderPtr_->updateSources();  // this is here to handle "fast" sources.

    *appVecPtr_ = bX.block(i);
    *appNextStaVecPtr_ = bS.block(i);
    *appCurrStaVecPtr_ = bcurrS.block(i);
    *appLastStaVecPtr_ = blastS.block(i);
    appdSdt = bdSdt.block(i);
    *appNextStoVecPtr_ = bStore.block(i);
    *appCurrStoVecPtr_ = bcurrStore.block(i);
    *appNextLeadFVecPtr_  = bNextLeadF.block(i);
    *appLeadQVecPtr_      =  bLeadQ.block(i);
    *appNextJunctionVVecPtr_  =  bNextJunctionV.block(i);
    
    if (DEBUG_HB)
    {
      Xyce::dout() << "Updating State for block " << i << " of " << BlockCount-1 << std::endl;
    }

    // Note: This updateState call is here (instead of in the
    // HBLoader::updateState function) because it has to be called
    // for the same fast time point.
    appLoaderPtr_->updateState
      ( &*appVecPtr_,
        &*appVecPtr_,  // note, this is a placeholder! ERK
        &*appVecPtr_,  // note, this is a placeholder! ERK
        &*appNextStaVecPtr_, &*appCurrStaVecPtr_ , &*appLastStaVecPtr_,
        &*appNextStoVecPtr_, &*appCurrStoVecPtr_,
        Xyce::Device::NONLINEAR );

    bS.block(i) = *appNextStaVecPtr_;
    bcurrS.block(i) = *appCurrStaVecPtr_;
    blastS.block(i) = *appLastStaVecPtr_;
    bStore.block(i) = *appNextStoVecPtr_;
    bcurrStore.block(i) = *appCurrStoVecPtr_;

    if (DEBUG_HB)
    {
      Xyce::dout() << "Calling loadDAEVectors on the appLoader" << std::endl;
    }

    // This has to be done because the app loader does NOT zero these vectors out.
    appQ->putScalar(0.0);
    appF->putScalar(0.0);
    appB->putScalar(0.0);
    appdFdxdVp->putScalar(0.0);
    appdQdxdVp->putScalar(0.0);

    appLoaderPtr_->loadDAEVectors
      ( &*appVecPtr_,
        &*appVecPtr_,  // note, this is a placeholder! ERK
        &*appVecPtr_,  // note, this is a placeholder! ERK
        &*appNextStaVecPtr_, &*appCurrStaVecPtr_, &*appLastStaVecPtr_, &appdSdt,
        &*appNextStoVecPtr_, &*appCurrStoVecPtr_, 
        &*appNextLeadFVecPtr_, &*appLeadQVecPtr_, 
        &*appNextJunctionVVecPtr_, 
        appQ, appF, appB,
        appdFdxdVp, appdQdxdVp,
        Xyce::Device::NONLINEAR );

    // Load the sources into appB.   
    appLoaderPtr_->loadBVectorsforSources();

    appB->fillComplete();

    bQt->block(i) = *appQ;
    bFt->block(i) = *appF;
    bBt->block(i) = *appB;

    bdQdxdVpt->block(i) = *appdQdxdVp;
    bdFdxdVpt->block(i) = *appdFdxdVp;

    bStore.block(i) = *appNextStoVecPtr_;  //lead current get loaded during loadDAEVectors

    bNextLeadF.block(i) = *appNextLeadFVecPtr_;  // lead currents loaded into lead current vector.
    bLeadQ.block(i) = *appLeadQVecPtr_;

    // Store the time domain Jacobian for future use.
    appdQdxPtr_->put(0.0);
    appdFdxPtr_->put(0.0);

    // Load dQdx and dFdx into the storage location for this time point, for linear devices.
    if (i == 0 && Teuchos::is_null(linAppdQdxPtr_) && Teuchos::is_null(linAppdFdxPtr_))
    {
      appLoaderPtr_->loadDAEMatrices( &*appVecPtr_, &*appNextStaVecPtr_, &appdSdt, &*appNextStoVecPtr_, &*appdQdxPtr_, &*appdFdxPtr_, Xyce::Device::LINEAR);

      // Copy over matrix values into linear storage
      linAppdQdxPtr_ = Teuchos::rcp( new Xyce::Linear::FilteredMatrix( &*appdQdxPtr_, appVecPtr_->pmap(), false ) );
      linAppdFdxPtr_ = Teuchos::rcp( new Xyce::Linear::FilteredMatrix( &*appdFdxPtr_, appVecPtr_->pmap(), false ) );

      // Create a vector containing the unique NZ rows in dQdx and dFdx.
      linNZRows_.clear();
      linNZRows_.insert( linNZRows_.end(), (linAppdQdxPtr_->getNZRows()).begin(), (linAppdQdxPtr_->getNZRows()).end() );
      linNZRows_.insert( linNZRows_.end(), (linAppdFdxPtr_->getNZRows()).begin(), (linAppdFdxPtr_->getNZRows()).end() );
      std::sort( linNZRows_.begin(), linNZRows_.end() );
      linNZRows_.erase( std::unique( linNZRows_.begin(), linNZRows_.end() ), linNZRows_.end() );
 
      appdQdxPtr_->put(0.0);
      appdFdxPtr_->put(0.0);
    }

    // Load dQdx and dFdx into the storage location for this time point, for nonlinear devices.
    appLoaderPtr_->loadDAEMatrices( &*appVecPtr_, &*appNextStaVecPtr_, &appdSdt, &*appNextStoVecPtr_, &*appdQdxPtr_, &*appdFdxPtr_, Xyce::Device::NONLINEAR);

    // Copy over matrix values into storage for nonlinear.
    // Try to reuse filtered matrix objects whenever possible, for efficiency.
    if (Teuchos::is_null(vecNLAppdQdxPtr_[i]))
    {
      vecNLAppdQdxPtr_[i] = Teuchos::rcp( new Xyce::Linear::FilteredMatrix( &*appdQdxPtr_, appVecPtr_->pmap(), false ) );

      // Add new rows to vector containing the unique NZ rows in dQdx.
      nonlinQNZRows_.insert( nonlinQNZRows_.end(), (vecNLAppdQdxPtr_[i]->getNZRows()).begin(), (vecNLAppdQdxPtr_[i]->getNZRows()).end() );
    }
    else
    {
      // Attempt to use previous NZ entries to filter new appdQdxPtr_, recreate filtered matrix if necessary
      bool reset = vecNLAppdQdxPtr_[i]->filterMatrix( &*appdQdxPtr_, appVecPtr_->pmap(), false );
      if (reset)
        nonlinQNZRows_.insert( nonlinQNZRows_.end(), (vecNLAppdQdxPtr_[i]->getNZRows()).begin(), (vecNLAppdQdxPtr_[i]->getNZRows()).end() );
    }

    if (Teuchos::is_null(vecNLAppdFdxPtr_[i]))
    {
      vecNLAppdFdxPtr_[i] = Teuchos::rcp( new Xyce::Linear::FilteredMatrix( &*appdFdxPtr_, appVecPtr_->pmap(), false ) );

      // Add new rows to vector containing the unique NZ rows in dFdx.
      nonlinFNZRows_.insert( nonlinFNZRows_.end(), (vecNLAppdFdxPtr_[i]->getNZRows()).begin(), (vecNLAppdFdxPtr_[i]->getNZRows()).end() );
    }
    else
    {
      // Attempt to use previous NZ entries to filter new appdFdxPtr_, recreate filtered matrix if necessary
      bool reset = vecNLAppdFdxPtr_[i]->filterMatrix( &*appdFdxPtr_, appVecPtr_->pmap(), false ); 
      if (reset)
        nonlinFNZRows_.insert( nonlinFNZRows_.end(), (vecNLAppdFdxPtr_[i]->getNZRows()).begin(), (vecNLAppdFdxPtr_[i]->getNZRows()).end() );
    }
  }

  // Generate unique list of NZ rows for dQdx and dFdx. 
  if (nlQrows < nonlinQNZRows_.size())
  {
    std::sort( nonlinQNZRows_.begin(), nonlinQNZRows_.end() );
    nonlinQNZRows_.erase( std::unique( nonlinQNZRows_.begin(), nonlinQNZRows_.end() ), nonlinQNZRows_.end() );
  }
  if (nlFrows < nonlinFNZRows_.size())
  {
    std::sort( nonlinFNZRows_.begin(), nonlinFNZRows_.end() );
    nonlinFNZRows_.erase( std::unique( nonlinFNZRows_.begin(), nonlinFNZRows_.end() ), nonlinFNZRows_.end() );
  }

  permutedFFT2(*bBt, bB);

  permutedFFT2(*bQt, bQ); 

  permutedFFT2(*bFt, bF);

  permutedFFT2(*bdQdxdVpt, bdQdxdVp);

  permutedFFT2(*bdFdxdVpt, bdFdxdVp);

  // Clean up temporary vectors before moving on.
  delete appQ; 
  delete appF;
  delete appB;
  delete appdFdxdVp;
  delete appdQdxdVp; 

  bLeadCurrentVecFreqPtr_->putScalar(0.0);
  bLeadCurrentQVecFreqPtr_->putScalar(0.0);
  permutedFFT2(bNextLeadF, &*bLeadCurrentVecFreqPtr_);
  permutedFFT2(bLeadQ, &*bLeadCurrentQVecFreqPtr_);

  // Add in linear contributions into vectors.
  Teuchos::RCP<Linear::BlockVector> permlindQdxX = hbBuilderPtr_->createExpandedRealFormTransposeBlockVector();
  Teuchos::RCP<Linear::BlockVector> permlindFdxX = hbBuilderPtr_->createExpandedRealFormTransposeBlockVector();

  applyLinearMatrices (bXf, *permlindQdxX, *permlindFdxX);

  if(!linAppdFdxPtr_->isEmpty())
  {
    bF->update (1.0, *permlindFdxX, 1.0);
  }
  
  if(!linAppdQdxPtr_->isEmpty())
  {
    bQ->update (1.0, *permlindQdxX, 1.0);
  }

/*
    Xyce::dout() << "HB X Vector" << std::endl;
    bX.printPetraObject(std::cout);
    Xyce::dout() << "HB Q Vector" << std::endl;
    bQ->printPetraObject(std::cout);
    Xyce::dout() << "HB F Vector" << std::endl;
    bF->printPetraObject(std::cout);
    Xyce::dout() << "HB B Vector" << std::endl;
    bB->printPetraObject(std::cout);
*/
  int blockCount = bXf.blockCount();
  int blockSize = bXf.block(0).globalLength();
//  double omega = 2.0 * M_PI/ period_;
  
  int size_ = freqs_.size();
  int posFreq = (size_-1)/2;
  double omega = 2.0 * M_PI * freqs_[posFreq] * fScalar;

  if (hbOsc_) 
    bQPtr_->putScalar( 0.0);

  for( int i = 0; i < blockCount; ++i )
  {
    // Create work vectors from the current frequency block vector
    // NOTE:  This needs to be done for each block to make sure that the
    //        map is the same as the bF block.
    Linear::Vector QVec(bQ->block(i));
    Linear::Vector freqVec = bQ->block(i);

    Linear::Vector dQdxdVpVec(bdQdxdVp->block(i));
    Linear::Vector freqVec1 = bdQdxdVp->block(i);


    if (hbOsc_)
      bQPtr_->block(i) = bQ->block(i);

    // Only one processor owns each block of the frequency-domain vector
    if (freqVec.localLength() > 0)
    {
      omega = 2.0 * M_PI * freqs_[posFreq] * fScalar;

      QVec[0] = -freqVec[1]*omega;
      QVec[1] = freqVec[0]*omega;

      dQdxdVpVec[0] = -freqVec1[1]*omega;
      dQdxdVpVec[1] = freqVec1[0]*omega;

      for (int j=1; j < (blockSize/2+1)/2; ++j)
      {
        
        omega = 2.0 * M_PI * freqs_[posFreq + j] * fScalar;

        QVec[2*j] = -freqVec[2*j+1]*omega;
        QVec[2*(blockSize/2-j)] = -freqVec[2*j+1]*omega;

        QVec[2*j+1] = freqVec[2*j]*omega;
        QVec[2*(blockSize/2-j)+1] = -freqVec[2*j]*omega;

        dQdxdVpVec[2*j] = -freqVec1[2*j+1]*omega;
        dQdxdVpVec[2*(blockSize/2-j)] = -freqVec1[2*j+1]*omega;

        dQdxdVpVec[2*j+1] = freqVec1[2*j]*omega;
        dQdxdVpVec[2*(blockSize/2-j)+1] = -freqVec1[2*j]*omega;

      }
    }

    bF->block(i).update(1.0, QVec , 1.0);

    bdFdxdVp->block(i).update(1.0, dQdxdVpVec, 1.0);
  }

//  blockCount = bStoreVecFreqPtr_->blockCount();
//  blockSize =  bStoreVecFreqPtr_->blockSize();

  // 
  // take care of the lead current vector 
  blockCount = bLeadCurrentVecFreqPtr_->blockCount();
  blockSize =  bLeadCurrentVecFreqPtr_->blockSize();

  for( int i = 0; i < blockCount; ++i )
  {
    // Create work vectors from the current frequency block vector
    // NOTE:  This needs to be done for each block to make sure that the
    //        map is the same as the bF block.
    Linear::Vector leadCurrdQdtVec(bLeadCurrentQVecFreqPtr_->block(i));
    Linear::Vector leadCurrQVec = bLeadCurrentQVecFreqPtr_->block(i);

    // Only one processor owns each block of the frequency-domain vector
    if (leadCurrQVec.localLength() > 0)
    {

      omega = 2.0 * M_PI * freqs_[posFreq] * fScalar;
      leadCurrdQdtVec[0] = leadCurrQVec[1]*omega;
      leadCurrdQdtVec[1] = leadCurrQVec[0]*omega;

      for (int j=1; j < (blockSize/2+1)/2; ++j)
      {
        omega = 2.0 * M_PI * freqs_[posFreq+ j] * fScalar;

        leadCurrdQdtVec[2*j] = -leadCurrQVec[2*j+1]*omega;
        leadCurrdQdtVec[2*(blockSize/2-j)] = -leadCurrQVec[2*j+1]*omega;

        leadCurrdQdtVec[2*j+1] = leadCurrQVec[2*j]*omega;
        leadCurrdQdtVec[2*(blockSize/2-j)+1] = -leadCurrQVec[2*j]*omega;
      }
    }

    bLeadCurrentVecFreqPtr_->block(i).update(1.0, leadCurrdQdtVec, 1.0);
  }

  if (DEBUG_HB)
  {
    Xyce::dout() << "HB X Vector" << std::endl;
    bX.printPetraObject(std::cout);
    //  Xyce::dout() << "HB S Vector" << std::endl;
    //  bS.printPetraObject(Xyce::dout());
    //  Xyce::dout() << "HB dSdt Vector" << std::endl;
    //  bdSdt.printPetraObject(Xyce::dout());
    Xyce::dout() << "HB Store Vector" << std::endl;
    bStore.printPetraObject(std::cout);
    Xyce::dout() << "HB Q Vector" << std::endl;
    bQ->printPetraObject(std::cout);
    Xyce::dout() << "HB F Vector" << std::endl;
    bF->printPetraObject(std::cout);
    Xyce::dout() << "HB bdFdxdVp Vector" << std::endl;
    bdFdxdVp->printPetraObject(std::cout);
    Xyce::dout() << "HB bdQdxdVp Vector" << std::endl;
    bdQdxdVp->printPetraObject(std::cout);
    Xyce::dout() << Xyce::section_divider << std::endl;
  }

  if (hbOsc_)
  {

//    if (augmentedLIDs.size() )
//      (*bF)[(augmentedLIDs)[0 ]] = fScalar - 1.0;
    double refValue = 0.0;
    double tmpValue= 0.0;
    Linear::Vector freqVec = bXf.block(refID_);

    if (freqVec.localLength() > 0)
    {
       tmpValue = freqVec[3];
    }

    Xf->pmap()->pdsComm().sumAll( &tmpValue, &refValue, 1 );

    if (augmentedLIDs.size() )
      (*bF)[(augmentedLIDs)[0 ]] = refValue;
  }

  return true;

}

//-----------------------------------------------------------------------------
// Function      : HBLoader::loadDeviceErrorWeightMask
// Purpose       :
// Special Notes :
// Scope         : public
// Creator       : Eric Keiter
// Creation Date : 11/1/2014
//-----------------------------------------------------------------------------
bool
HBLoader::loadDeviceErrorWeightMask(
  Linear::Vector *      deviceMask) const
{
#if 0
  Linear::BlockVector & bDevMask = *dynamic_cast<Linear::BlockVector*>(deviceMask);

#if 0
  Xyce::dout() << "HBLoader::loadDeviceErrorWeightMask.  Original (nonblock) deviceMask.size = "
    << appVecPtr_->globalLength() <<std::endl;
#endif

  appVecPtr_->putScalar(1.0);
  bool returnValue = deviceManager_.loadErrorWeightMask(&*appVecPtr_);

  int blockCount = bDevMask.blockCount();
  int blockSize =  bDevMask.blockSize();

#if 0
  Xyce::dout() << "bDevMask.blockCount = "<< blockCount <<std::endl;
  Xyce::dout() << "bDevMask.blockSize = "<< blockSize <<std::endl;
  appVecPtr_->printPetraObject(Xyce::dout());
#endif

  //Teuchos::RCP<N_PDS_ParMap> baseMap = Teuchos::rcp_const_cast<N_PDS_ParMap>( hbBuilderPtr_->getBaseStoreMap() );

  for( int i = 0; i < blockCount; ++i )
  {
    // See if this variable is owned by the local processor.
    // If so, this processor owns the entire j-th block of the vector
    //int lid = baseMap->globalToLocalIndex( i );

    Linear::Vector& localVecRef =  bDevMask.block(i);

    for (int j=0;j<blockSize;++j)
    {
      localVecRef[j] = (*appVecPtr_)[i];
    }
  }

#if 0
  bDevMask.printPetraObject(Xyce::dout());
#endif

  return returnValue;
#else
  return true;
#endif
}

//-----------------------------------------------------------------------------
// Function      : HBLoader::permutedFFT
// Purpose       :
// Special Notes :
// Scope         : public
// Creator       : Ting Mei
// Creation Date : 09/05/08
//---------------------------------------------------------------------------
void HBLoader::permutedFFT(const Linear::BlockVector & xt, Linear::BlockVector * xf, std::vector<int>* lids)
{
  // Call the function to compute the permuted FFT from the block system helper functions.
  computePermutedDFT( *dftInterface_, xt, xf, lids );
}

//-----------------------------------------------------------------------------
// Function      : HBLoader::permutedFFT2
// Purpose       :
// Special Notes :
// Scope         : public
// Creator       : Ting Mei
// Creation Date : 09/05/08
//---------------------------------------------------------------------------
void HBLoader::permutedFFT2(const Linear::BlockVector & xt, Linear::BlockVector * xf)
{
  // Call the function to compute the permuted FFT from the block system helper functions.
  computePermutedDFT2( *dftInterface_, xt, xf );
}

//-----------------------------------------------------------------------------
// Function      : HBLoader::permutedIFT
// Purpose       :
// Special Notes :
// Scope         : public
// Creator       : Ting Mei
// Creation Date : 09/05/08
//---------------------------------------------------------------------------
void HBLoader::permutedIFT(const Linear::BlockVector & xf, Linear::BlockVector * xt, int numTimePts_ )
{
  // Call the function to compute the permuted IFT from the block system helper functions.
  computePermutedIFT( *dftInterface_, xf, xt, numTimePts_ );  
} 

//-----------------------------------------------------------------------------
// Function      : HBLoader::getVoltageLimiterStatus
// Purpose       :
// Special Notes :
// Scope         : public
// Creator       : Eric Keiter
// Creation Date : 6/22/2015
//---------------------------------------------------------------------------
bool HBLoader::getVoltageLimiterStatus()
{
  return appLoaderPtr_->getVoltageLimiterStatus();
}

//-----------------------------------------------------------------------------
// Function      : HBLoader::setVoltageLimiterStatus
// Purpose       :
// Special Notes :
// Scope         : public
// Creator       : Eric Keiter
// Creation Date : 6/22/2015 
//---------------------------------------------------------------------------
void HBLoader::setVoltageLimiterStatus(bool voltageLimterStatus)
{
  return appLoaderPtr_->setVoltageLimiterStatus(voltageLimterStatus);
}

} // namespace Loader
} // namespace Xyce
