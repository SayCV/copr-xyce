// This demo program, when linked with Xyce's shared libraries, will enable not
// only running normal Xyce netlists
// but also those that contain "General External" devices.
//
// It only recognizes the General External devices if they're given specific
// names, because we've only coded three special types of devices, a simple
// resistor,  a series RLC subcircuit, and a voltage-controlled-current source.
//
// The program will recognize these devices in the netlist based on their names.
// YGENEXT R1 <node1> <node2>
// YGENEXT RLC1 <node1> <node2>
// YGENEXT VCCS1 <node+> <node-> <control +> <control -> <modelname>
//    (NOTE:  A parser limitation of Xyce requires that a model be specified
//     any time any more than 2 nodes are given to the YGENEXT device.
//     This is true even though the YGenExt device has no model parameters.
//     A null model card like:
//     .model dummy genext ()
//     is sufficient to get past this limitation)
//
// You can only have at most one of each of these in your netlist.
//
// Usage:
// testGenCoup  <netlistname>
//
// This version demonstrates a very simple resistor device, which depends on
// the default behaviors of the GenExt device when neither numIntVars nor
// jacobian stamp are set by the caller.
//
// The RLC device has two internal variables and sets a sparse jacobian stamp.

#include <Xyce_config.h>
#include <N_CIR_GenCouplingSimulator.h>
#include <N_DEV_VectorComputeInterface.h>
#include <iostream>
#include <Sacado.hpp>

class resistorVectorCompute : public Xyce::Device::VectorComputeInterface
{
public:
  resistorVectorCompute(double R) : R_(R) {};
  
  virtual bool computeXyceVectors(std::vector<double> & sV, double t,
                          std::vector<double> & F,
                          std::vector<double> & Q,
                          std::vector<double> & B,
                          std::vector<std::vector<double> > & dFdX,
                          std::vector<std::vector<double> > & dQdX)
  {
    int numVars=sV.size();

    F.resize(numVars);
    Q.clear();
    B.clear();
    dQdX.clear();
    dFdX.resize(numVars);
    for (int i=0; i<numVars; i++)
      dFdX[i].resize(numVars);

    std::vector<Sacado::Fad::DFad<double> > indepVars,Fcontribs;
    indepVars.resize(numVars);
    Fcontribs.resize(numVars);
    for (int i=0;i<numVars; i++)
    {
      indepVars[i]=sV[i];
      indepVars[i].diff(i,numVars);
    }

    Fcontribs[0] = (indepVars[0]-indepVars[1])/R_; 
    Fcontribs[1] = -Fcontribs[0];

    for (int i=2; i<Fcontribs.size();i++)
      Fcontribs[i]=0;

    for (int i=0; i<numVars; i++)
    {
      F[i] = Fcontribs[i].val();
      for (int j=0; j<numVars; j++)
        dFdX[i][j] = Fcontribs[i].dx(j);
    }
    return true;
  };
private:
  double R_;
  
};

class rlcVectorCompute : public Xyce::Device::VectorComputeInterface
{
public:
  rlcVectorCompute(double R, double L, double C)
    : R_(R),
      L_(L),
      C_(C)
  {
    // set up our jacobian stamp
    // in this example we're just keeping jacStamp around as a public
    // variable that can be pulled out of the object.  It could have been done
    // in other ways.
    jacStamp.resize(4);

    jacStamp[node1].resize(1);
    jacStamp[node1][0] = branch;

    jacStamp[node2].resize(2);
    jacStamp[node2][0]=node2;
    jacStamp[node2][1]=nodeInt;

    jacStamp[nodeInt].resize(3);
    jacStamp[nodeInt][0]=node2;
    jacStamp[nodeInt][1]=nodeInt;
    jacStamp[nodeInt][2]=branch;

    jacStamp[branch].resize(3);
    jacStamp[branch][0]=node1;
    jacStamp[branch][1]=nodeInt;
    jacStamp[branch][2]=branch;
  };
  
  virtual bool computeXyceVectors(std::vector<double> & sV, double t,
                          std::vector<double> & F,
                          std::vector<double> & Q,
                          std::vector<double> & B,
                          std::vector<std::vector<double> > & dFdX,
                          std::vector<std::vector<double> > & dQdX)
  {
    int numVars=sV.size();
    
    F.resize(numVars);
    Q.resize(numVars);
    B.clear();
    dFdX.resize(numVars);
    dQdX.resize(numVars);
    for (int i=0; i<numVars; i++)
    {
      dFdX[i].resize(numVars);
      dQdX[i].resize(numVars);
    }

    std::vector<Sacado::Fad::DFad<double> > indepVars,Fcontribs,Qcontribs;
    indepVars.resize(numVars);
    Fcontribs.resize(numVars);
    Qcontribs.resize(numVars);
    for (int i=0;i<numVars; i++)
    {
      indepVars[i]=sV[i];
      indepVars[i].diff(i,numVars);
      Fcontribs[i]=0;
      Qcontribs[i]=0;
    }

    // vars 0 and 1 are the external nodes
    // var 2 is the internal node
    // var 3 is the branch current
    // equation 0 and 1 are the equations for the external node
    // equation 2 is the equation for the internal node
    // equation 3 is the branch equation
    
    // Do the resistor and inductor as a single branch with just one
    // internal node (c.f rlc2.va in Xyce/utils/ADMS/examples/toys)
    // Branch equation is then
    //    (branch_current*R + L d(branch_current)/dt)-(v0-v2) = 0
    // Current between external node 0 and internal node 2 is just
    // the branch current
    Fcontribs[node1] = indepVars[branch];
    Fcontribs[nodeInt] = -indepVars[branch];

    Fcontribs[branch] = indepVars[branch]*R_
      - (indepVars[node1]-indepVars[nodeInt]);
    Qcontribs[branch] = L_*indepVars[branch];


    // Now the capacitor.  Current flowing from node 2 to node 1 is
    // just dQ/dt where Q=CV.
    Sacado::Fad::DFad<double> capCharge
      = C_*(indepVars[nodeInt]-indepVars[node2]);
    Qcontribs[nodeInt] = capCharge;
    Qcontribs[node2] = -capCharge;

    for (int i=0; i<numVars; i++)
    {
      F[i] = Fcontribs[i].val();
      Q[i] = Qcontribs[i].val();
      for (int j=0; j<numVars; j++)
      {
        dFdX[i][j] = Fcontribs[i].dx(j);
        dQdX[i][j] = Qcontribs[i].dx(j);
      }
    }
    return true;
  };
public:
  std::vector< std::vector<int> > jacStamp;
private:
  double R_;
  double L_;
  double C_;
  static const int node1=0;
  static const int node2=1;
  static const int nodeInt=2;
  static const int branch=3;
};

/// Implements a voltage-controlled current source
/// nodes 3 and 4 are the control nodes
/// current flows from positive (node 1) to negative (node2)
class vccsVectorCompute : public Xyce::Device::VectorComputeInterface
{
public:
  vccsVectorCompute(double tC)
    : transConductance_(tC)
  {
    // set up our jacobian stamp
    // in this example we're just keeping jacStamp around as a public
    // variable that can be pulled out of the object.  It could have been done
    // in other ways.
    jacStamp.resize(4);

    jacStamp[nodePos].resize(2);
    jacStamp[nodePos][0] = controlNodePos;
    jacStamp[nodePos][1] = controlNodeNeg;
    jacStamp[nodeNeg].resize(2);
    jacStamp[nodeNeg][0] = controlNodePos;
    jacStamp[nodeNeg][1] = controlNodeNeg;

    // No loading happens to nodes 2 and 3, so those jacStamp rows are
    // zero length.
  };
  
  virtual bool computeXyceVectors(std::vector<double> & sV, double t,
                          std::vector<double> & F,
                          std::vector<double> & Q,
                          std::vector<double> & B,
                          std::vector<std::vector<double> > & dFdX,
                          std::vector<std::vector<double> > & dQdX)
  {
    int numVars=sV.size();

    std::cout << " In vccs computeXyceVectors, number vars = " << numVars
              << std::endl;
    
    F.resize(numVars);
    Q.clear();
    B.clear();
    dFdX.resize(numVars);
    dQdX.clear();
    for (int i=0; i<numVars; i++)
    {
      dFdX[i].resize(numVars);
    }

    std::vector<Sacado::Fad::DFad<double> > indepVars,Fcontribs;
    indepVars.resize(numVars);
    Fcontribs.resize(numVars);
    for (int i=0;i<numVars; i++)
    {
      indepVars[i]=sV[i];
      indepVars[i].diff(i,numVars);
      Fcontribs[i]=0;
    }


    Sacado::Fad::DFad<double> current
      = transConductance_*(indepVars[controlNodePos]-indepVars[controlNodeNeg]);
    Fcontribs[nodePos] = current;
    Fcontribs[nodeNeg] = -current;
    
    for (int i=0; i<numVars; i++)
    {
      F[i] = Fcontribs[i].val();
      for (int j=0; j<numVars; j++)
      {
        dFdX[i][j] = Fcontribs[i].dx(j);
      }
    }
    return true;
  };
public:
  std::vector< std::vector<int> > jacStamp;
private:
  double transConductance_;

  static const int nodePos=0;
  static const int nodeNeg=1;
  static const int controlNodePos=2;
  static const int controlNodeNeg=3;
};

int main(int argc, char **argv)
{
  bool debug=false;
  
  Xyce::Circuit::Simulator::RunStatus run_status=Xyce::Circuit::Simulator::SUCCESS;
  Xyce::Circuit::GenCouplingSimulator xyce;

  run_status=xyce.initializeEarly(argc,argv);
  if (run_status==Xyce::Circuit::Simulator::ERROR) exit(1);
  if (run_status==Xyce::Circuit::Simulator::DONE) exit(0);

  std::vector<std::string> deviceNames;
  bool bsuccess=xyce.getDeviceNames("YGENEXT",deviceNames);
  if (!bsuccess && debug)
  {
    std::cout << " No external devices found.. regular xyce netlist." << std::endl;
  }
  
  resistorVectorCompute rvc(1000);
  vccsVectorCompute vccsvc(1);
  rlcVectorCompute rlcvc(1000,1e-3,1e-12);
  for (int i =0; i<deviceNames.size(); i++)
  {
    std::cout << "GenExt Device " << i << " name is " << deviceNames[i] << std::endl;
    if (deviceNames[i] == "YGENEXT!R1")
    {
      // bsuccess=xyce.setNumInternalVars("YGENEXT!R1",0);
      //if (!bsuccess)
      //{
      //std::cerr << " Failed to set internal vars for YGENEXT!R1" << std::endl;
      //exit(1);
      //}
      
      bsuccess=xyce.setVectorLoader("YGENEXT!R1",&rvc);
      if (!bsuccess)
      {
        std::cerr << " Failed to set vector loader for YGENEXT!R1" << std::endl;
        exit(1);
      }
    }
    if (deviceNames[i] == "YGENEXT!RLC1")
    {
      bsuccess=xyce.setNumInternalVars("YGENEXT!RLC1",2);
      if (!bsuccess)
      {
        std::cerr << " Failed to set internal vars for YGENEXT!RLC1" << std::endl;
        exit(1);
      }
      bsuccess=xyce.setJacStamp("YGENEXT!RLC1",rlcvc.jacStamp);
      if (!bsuccess)
      {
        std::cerr << " Failed to set Jacobian Stamp for YGENEXT!RLC1" << std::endl;
        exit(1);
      }
      
      bsuccess=xyce.setVectorLoader("YGENEXT!RLC1",&rlcvc);
      if (!bsuccess)
      {
        std::cerr << " Failed to set vector loader for YGENEXT!RLC1" << std::endl;
        exit(1);
      }
    }

    if (deviceNames[i] == "YGENEXT!VCCS1")
    {
      bsuccess=xyce.setJacStamp("YGENEXT!VCCS1",vccsvc.jacStamp);
      if (!bsuccess)
      {
        std::cerr << " Failed to set Jacobian Stamp for YGENEXT!VCCS1" << std::endl;
        exit(1);
      }
      
      bsuccess=xyce.setVectorLoader("YGENEXT!VCCS1",&vccsvc);
      if (!bsuccess)
      {
        std::cerr << " Failed to set vector loader for YGENEXT!VCCS1" << std::endl;
        exit(1);
      }
    }
    
  }
  run_status=xyce.initializeLate();
  if (run_status==Xyce::Circuit::Simulator::ERROR) exit(1);
  if (run_status==Xyce::Circuit::Simulator::DONE) exit(0);
  try
  {
    run_status = xyce.runSimulation();
  }
  catch (std::exception &x)
  {
    run_status=Xyce::Circuit::Simulator::ERROR;
  }
  if (run_status != Xyce::Circuit::Simulator::DONE)
  {
    try
    {
      xyce.finalize();
    }
    catch (std::exception &x)
    {
      run_status = Xyce::Circuit::Simulator::ERROR;
    }
  }
  exit ((run_status==Xyce::Circuit::Simulator::ERROR)?1:0);
}
