%%MatrixMarket matrix coordinate real general
% 
% Sandia National Laboratories is a multi-program laboratory managed and operated by Sandia Corporation,
% a wholly owned subsidiary of Lockheed Martin Corporation, for the U.S. Department of Energy's National Nuclear 
% Security Administration under contract DE-AC04-94AL85000.
%
% Xyce circuit matrix.
%%
6 6 16
1 1 1.0000000000000000e-03
1 2 1.0000000000000000e+00
1 3 -1.0000000000000000e-03
2 1 1.0000000000000000e+00
3 1 -1.0000000000000000e-03
3 3 1.0000000000000000e-03
3 4 0.0000000000000000e+00
3 6 0.0000000000000000e+00
4 3 0.0000000000000000e+00
4 4 1.0000000277327002e-04
4 6 -1.3866350114911383e-12
5 6 1.0000000000000000e+00
6 3 0.0000000000000000e+00
6 4 -1.3866350114911383e-12
6 5 1.0000000000000000e+00
6 6 1.3866350114911383e-12
