//-----------------------------------------------------------------------------
// Copyright Notice
//
//   Copyright 2002 Sandia Corporation. Under the terms
//   of Contract DE-AC04-94AL85000 with Sandia Corporation, the U.S.
//   Government retains certain rights in this software.
//
//    Xyce(TM) Parallel Electrical Simulator
//    Copyright (C) 2002-2017 Sandia Corporation
//
//    This program is free software: you can redistribute it and/or modify
//    it under the terms of the GNU General Public License as published by
//    the Free Software Foundation, either version 3 of the License, or
//    (at your option) any later version.
//
//    This program is distributed in the hope that it will be useful,
//    but WITHOUT ANY WARRANTY; without even the implied warranty of
//    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//    GNU General Public License for more details.
//
//    You should have received a copy of the GNU General Public License
//    along with this program.  If not, see <http://www.gnu.org/licenses/>.
//-----------------------------------------------------------------------------

//-------------------------------------------------------------------------
//
// Purpose       :
//
// Special Notes :
//
// Creator       : David G. Baur
//
// Creation Date : 1/24/2014
//
//
//
//
//-------------------------------------------------------------------------

#include <Xyce_config.h>

#include <iostream>

#include <N_UTL_NetlistLocation.h>

namespace Xyce {

bool operator<(const NetlistLocation &s0, const NetlistLocation &s1)
{
  return s0.getFilename() < s1.getFilename() || (!(s1.getFilename() < s0.getFilename()) && s0.getLineNumber() < s1.getLineNumber());
}

std::ostream &operator<<(std::ostream &os, const NetlistLocation &x)
{
  os << "file " << x.getFilename() << " at or near line " << x.getLineNumber();
  return os;
}

Util::Marshal &operator<<(Util::Marshal &mout, const NetlistLocation &netlist_location) 
{
  return mout << netlist_location.getFilename() << netlist_location.getLineNumber();
}

Util::Marshal &operator>>(Util::Marshal &min, NetlistLocation &netlist_location) {
  std::string filename;
  int line_number;
  min >> filename >> line_number;
  netlist_location.setFilename(filename);
  netlist_location.setLineNumber(line_number);
  return min;
}

} // namespace Xyce

