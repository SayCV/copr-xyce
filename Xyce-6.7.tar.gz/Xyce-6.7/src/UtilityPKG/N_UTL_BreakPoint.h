//-----------------------------------------------------------------------------
// Copyright Notice
//
//   Copyright 2002 Sandia Corporation. Under the terms
//   of Contract DE-AC04-94AL85000 with Sandia Corporation, the U.S.
//   Government retains certain rights in this software.
//
//    Xyce(TM) Parallel Electrical Simulator
//    Copyright (C) 2002-2017 Sandia Corporation
//
//    This program is free software: you can redistribute it and/or modify
//    it under the terms of the GNU General Public License as published by
//    the Free Software Foundation, either version 3 of the License, or
//    (at your option) any later version.
//
//    This program is distributed in the hope that it will be useful,
//    but WITHOUT ANY WARRANTY; without even the implied warranty of
//    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//    GNU General Public License for more details.
//
//    You should have received a copy of the GNU General Public License
//    along with this program.  If not, see <http://www.gnu.org/licenses/>.
//-----------------------------------------------------------------------------

//-----------------------------------------------------------------------------
//
// Purpose        : Provide a basic "breakpoint" class that can be used in
//                  STL sets, with appropriate operators so that the set will
//                  automatically eliminate duplicates on insert, with
//                  "duplicate" meaning "within a certain tolerance"
//
// Special Notes  : There remains some lingering issue with the assignment
//                  operator, so the STL "unique" algorithm doesn't work yet
//
//
// Creator        : Tom Russo, SNL, Component Information and Models
//
// Creation Date  : 04/28/2004
//
//
//
//
//-----------------------------------------------------------------------------
#ifndef Xyce_N_UTL_BreakPoint_h
#define Xyce_N_UTL_BreakPoint_h

#include <N_UTL_Math.h>

namespace Xyce {
namespace Util {

struct BreakPointLess;

//-----------------------------------------------------------------------------
// ClassFunction      : BreakPoint
// Purpose       :
// Special Notes :
// Scope         : public
// Creator       : David G. Baur  Raytheon  Sandia National Laboratories 1355
// Creation Date : Tue Oct 14 10:29:20 2014
//-----------------------------------------------------------------------------
///
/// Breakpoint for identifying significant points in time to hit during time integration.
///
/// Breakpoint times are compared with a tolerance.  This tolerance is specified and
/// utilized by the BreakPointLess less predicate.
///
/// A SIMPLE breakpoint is.... and a PAUSE breakpoint is....
///
class BreakPoint
{
  friend struct BreakPointLess;                 ///< Allow less compare to access values

public:
  static const double defaultTolerance_;        ///< Default tolerance

  enum Type {SIMPLE, PAUSE};                    ///< Bre

  //-----------------------------------------------------------------------------
  // Function      : BreakPoint
  // Purpose       :
  // Special Notes :
  // Scope         : public
  // Creator       : David G. Baur  Raytheon  Sandia National Laboratories 1355
  // Creation Date : Tue Oct 14 10:32:58 2014
  //-----------------------------------------------------------------------------
  ///
  /// Constructs a breakpoint.
  ///
  /// @invariant Type is either SIMPLE to PAUSE
  ///
  /// @param time       Time of the breakpoint
  /// @param type       SIMPLE or PAUSE
  ///
  BreakPoint(double time = 0.0, Type type = SIMPLE)
    : time_(time),
      type_(type)
  {}

  //-----------------------------------------------------------------------------
  // Function      : BreakPoint
  // Purpose       :
  // Special Notes :
  // Scope         : public
  // Creator       : David G. Baur  Raytheon  Sandia National Laboratories 1355
  // Creation Date : Tue Oct 14 10:32:58 2014
  //-----------------------------------------------------------------------------
  ///
  /// Constructs a breakpoint.
  ///
  /// @invariant Type is either SIMPLE to PAUSE
  ///
  /// @param time       Time of the breakpoint
  /// @param type       1 for PAUSE, all other values set to SIMPLE
  ///
  BreakPoint(double time, int type)
    : time_(time),
      type_(type == 1 ? PAUSE : SIMPLE)
  {}

  //-----------------------------------------------------------------------------
  // Function      : BreakPoint
  // Purpose       :
  // Special Notes :
  // Scope         : public
  // Creator       : David G. Baur  Raytheon  Sandia National Laboratories 1355
  // Creation Date : Tue Oct 14 10:32:58 2014
  //-----------------------------------------------------------------------------
  ///
  /// Copies a breakpoint.
  ///
  /// @invariant Type is either SIMPLE to PAUSE
  ///
  /// @param right      Breakpoint to copy
  ///
  BreakPoint(const BreakPoint& right)
    : time_(right.time_),
      type_(right.type_)
  {}

  //-----------------------------------------------------------------------------
  // Function      : BreakPoint
  // Purpose       :
  // Special Notes :
  // Scope         : public
  // Creator       : David G. Baur  Raytheon  Sandia National Laboratories 1355
  // Creation Date : Tue Oct 14 10:32:58 2014
  //-----------------------------------------------------------------------------
  ///
  /// Assigns a breakpoint.
  ///
  /// @invariant Type is either SIMPLE to PAUSE
  ///
  /// @param right      Breakpoint to copy
  ///
  BreakPoint &operator=(const BreakPoint &b)
  {
    time_ = b.time_;
    type_ = b.type_;

    return *this;
  }

  //-----------------------------------------------------------------------------
  // Function      : value
  // Purpose       :
  // Special Notes :
  // Scope         : public
  // Creator       : David G. Baur  Raytheon  Sandia National Laboratories 1355
  // Creation Date : Tue Oct 14 10:36:25 2014
  //-----------------------------------------------------------------------------
  ///
  /// Returns the breakpoint time.
  ///
  /// @return Returns breakpoint time
  ///
  double value() const
  {
    return time_;
  }

  //-----------------------------------------------------------------------------
  // Function      : value
  // Purpose       :
  // Special Notes :
  // Scope         : public
  // Creator       : David G. Baur  Raytheon  Sandia National Laboratories 1355
  // Creation Date : Tue Oct 14 10:36:25 2014
  //-----------------------------------------------------------------------------
  ///
  /// Returns the breakpoint type.
  ///
  /// @return Returns breakpoint type
  ///
  Type bptype() const
  {
    return type_;
  }

private:
  double        time_;                  ///< Breakpoint time
  Type          type_;                  ///< SIMPLE or PAUSE
};

//-----------------------------------------------------------------------------
// Class         : BreakPointLess
// Purpose       :
// Special Notes :
// Scope         : public
// Creator       : David G. Baur  Raytheon  Sandia National Laboratories 1355
// Creation Date : Tue Oct 14 10:38:27 2014
//-----------------------------------------------------------------------------
///
/// Compares breakpoint times within the specified tolerance.  Times are considered equal
/// if the magnitude of the difference is less than the specified tolerance
///
/// @param tolerance    Tolerance value to use for comparison
///
struct BreakPointLess
{
  //-----------------------------------------------------------------------------
  // Function      : BreakPointLess
  // Purpose       :
  // Special Notes :
  // Scope         : public
  // Creator       : David G. Baur  Raytheon  Sandia National Laboratories 1355
  // Creation Date : Tue Oct 14 10:40:09 2014
  //-----------------------------------------------------------------------------
  ///
  /// Construct a breakpoint compare object with the specified tolerance.
  ///
  /// @invariant Tolerance must be non-negative
  ///
  /// @param tolerance  Tolerance used for compare
  ///
  BreakPointLess(double tolerance)
    : tolerance_(tolerance)
  {}

  //-----------------------------------------------------------------------------
  // Function      : operator
  // Purpose       :
  // Special Notes :
  // Scope         : public
  // Creator       : David G. Baur  Raytheon  Sandia National Laboratories 1355
  // Creation Date : Tue Oct 14 10:41:28 2014
  //-----------------------------------------------------------------------------
  ///
  /// Returns true if the left hand side is less than the right hand side by more than the
  /// tolerance.
  ///
  /// @return true if the left hand side is less than the right hand side by more than the
  /// tolerance
  ///
  ///
  bool operator()(const BreakPoint &l, const BreakPoint &r) const
  {
    return l.time_ < r.time_ && std::fabs(r.time_ - l.time_) > tolerance_;
  }

  //-----------------------------------------------------------------------------
  // Function      : operator
  // Purpose       :
  // Special Notes :
  // Scope         : public
  // Creator       : David G. Baur  Raytheon  Sandia National Laboratories 1355
  // Creation Date : Tue Oct 14 10:41:28 2014
  //-----------------------------------------------------------------------------
  ///
  /// Returns true if the left hand side is less than the right hand side by more than the
  /// tolerance.
  ///
  /// @return true if the left hand side is less than the right hand side by more than the
  /// tolerance
  ///
  ///
  bool operator()(const BreakPoint &l, const double &d) const
  {
    return l.time_ < d && std::fabs(d - l.time_) > tolerance_;
  }

public:
  double tolerance_;                            ///< Tolerance
};

} // namespace Util
} // namespace Xyce

#endif
