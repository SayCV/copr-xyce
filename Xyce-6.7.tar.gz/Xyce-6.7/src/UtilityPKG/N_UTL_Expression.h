//-----------------------------------------------------------------------------
// Copyright Notice
//
//   Copyright 2002 Sandia Corporation. Under the terms
//   of Contract DE-AC04-94AL85000 with Sandia Corporation, the U.S.
//   Government retains certain rights in this software.
//
//    Xyce(TM) Parallel Electrical Simulator
//    Copyright (C) 2002-2017 Sandia Corporation
//
//    This program is free software: you can redistribute it and/or modify
//    it under the terms of the GNU General Public License as published by
//    the Free Software Foundation, either version 3 of the License, or
//    (at your option) any later version.
//
//    This program is distributed in the hope that it will be useful,
//    but WITHOUT ANY WARRANTY; without even the implied warranty of
//    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//    GNU General Public License for more details.
//
//    You should have received a copy of the GNU General Public License
//    along with this program.  If not, see <http://www.gnu.org/licenses/>.
//-----------------------------------------------------------------------------

//-----------------------------------------------------------------------------
//
// Purpose        :
//
// Special Notes  :
//
// Creator        : Eric Keiter
//
// Creation Date  : 04/17/08
//
//-----------------------------------------------------------------------------

#ifndef N_UTL_Expression_H
#define N_UTL_Expression_H

// ---------- Standard Includes ----------
#include <vector>
#include <string>
#include <list>
#include <iosfwd>

#include <N_UTL_fwd.h>
#include <N_UTL_Interface_Enum_Types.h>
#include <N_UTL_ExpressionSymbolTable.h>

namespace Xyce {
namespace Util {

class ExpressionInternals;

//-----------------------------------------------------------------------------
// Class         : Expression
// Purpose       :
// Special Notes :
// Creator       : Eric Keiter
// Creation Date : 04/17/08
//-----------------------------------------------------------------------------
class Expression
{

public:

  Expression (std::string const & exp = std::string());
  Expression (const Expression &);
  //  Expression& operator=(const Expression& right) ;  ///< Should never have copy constructor without this too?!?
  ~Expression (void);

  bool parsed() const;
    
  bool set (std::string const & exp);
  void getSymbolTable (std::vector< ExpressionSymbolTableEntry > & names) const;
  void get_names (int const & type, std::vector< std::string > & names) const;
  int get_type (std::string const & var);
  bool make_constant (std::string const & var, double const & val);
  bool make_var (std::string const & var);

  int differentiate();

  bool set_var (const std::string &, const double &);
  bool set_vars (const std::vector< double > &);

  std::string get_expression (void) const;
  std::string get_derivative(std::string const & var);
  int get_num(int const & type);

  int evaluate (double &result, std::vector< double > &derivs, std::vector< double > &vals);
  int evaluateFunction (double &result, std::vector< double > &vals);

  int evaluate (double &result, std::vector< double > &derivs);
  int evaluateFunction (double &result);

  bool set_sim_time (double time);
  bool set_temp (double const & temp);
  void set_accepted_time ();
  double get_break_time (void);
  double get_break_time_i (void);
  const std::string & get_input (void);
  int order_names (std::vector< std::string > const & new_names);
  int replace_func (std::string const & func_name, Expression & func_def, int numArgs);
  bool replace_name (const std::string & old_name, const std::string & new_name);
  int replace_var(std::string const & var_name, const Expression & subexpr);
  int replace_var(const std::string & var_name, Op::Operator *op);
  int getNumDdt();
  void getDdtVals (std::vector<double> &);
  void setDdtDerivs (std::vector<double> &);
  int num_vars() const;
  bool isTimeDependent() const;
  void dumpParseTree();

  static void seedRandom(long seed);
private:

  ExpressionInternals *expPtr_;

};

} // namespace Util
} // namespace Xyce

#endif // N_UTL_EXPRESSION_H

