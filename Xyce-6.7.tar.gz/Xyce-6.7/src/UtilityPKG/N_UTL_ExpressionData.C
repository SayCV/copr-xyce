//-----------------------------------------------------------------------------
// Copyright Notice
//
//   Copyright 2002 Sandia Corporation. Under the terms
//   of Contract DE-AC04-94AL85000 with Sandia Corporation, the U.S.
//   Government retains certain rights in this software.
//
//    Xyce(TM) Parallel Electrical Simulator
//    Copyright (C) 2002-2017 Sandia Corporation
//
//    This program is free software: you can redistribute it and/or modify
//    it under the terms of the GNU General Public License as published by
//    the Free Software Foundation, either version 3 of the License, or
//    (at your option) any later version.
//
//    This program is distributed in the hope that it will be useful,
//    but WITHOUT ANY WARRANTY; without even the implied warranty of
//    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//    GNU General Public License for more details.
//
//    You should have received a copy of the GNU General Public License
//    along with this program.  If not, see <http://www.gnu.org/licenses/>.
//-----------------------------------------------------------------------------

//-------------------------------------------------------------------------
//
// Purpose        : Handle data for one expression object
//
// Special Notes  :
//
// Creator        : Richard Schiek
//
// Creation Date  : 8/24/2009
//
//
//
//
//-------------------------------------------------------------------------
#include <Xyce_config.h>

#include <fstream>
#include <iostream>
#include <limits>
#include <sstream>

#include <N_ERH_ErrorMgr.h>
#include <N_IO_Op.h>
#include <N_IO_OptionBlock.h>
#include <N_LAS_Vector.h>
#include <N_UTL_Expression.h>
#include <N_UTL_ExpressionData.h>
#include <N_UTL_FeatureTest.h>
#include <N_UTL_Param.h>
#include <N_UTL_ExpressionSymbolTable.h>

namespace Xyce {
namespace Util {

//-----------------------------------------------------------------------------
// Function      : ExpressionData::ExpressionData
// Purpose       : constructor
// Special Notes :
// Scope         : public
// Creator       : Eric R. Keiter, SNL, Parallel Computational Sciences
// Creation Date : 08/09/04
//-----------------------------------------------------------------------------
ExpressionData::ExpressionData (
  const std::string &   expression)
  : expression_(0),
    expressionString_(expression),
    state_(NOT_SETUP)
{}

//-----------------------------------------------------------------------------
// Function      : ExpressionData::ExpressionData
// Purpose       : constructor -- used to take an existing expression pointer
//                 not a string that can be converted to an expression
// Special Notes :
// Scope         : public
// Creator       : Eric R. Keiter, SNL, Parallel Computational Sciences
// Creation Date : 08/09/04
//-----------------------------------------------------------------------------
ExpressionData::ExpressionData (
  const Expression &  expression)
  : expression_(new Expression( expression )),
    expressionString_(expression_->get_expression()),
    state_(NOT_SETUP)
{}

//-----------------------------------------------------------------------------
// Function      : ExpressionData::~ExpressionData
// Purpose       : destructor
// Special Notes :
// Scope         : public
// Creator       : Eric R. Keiter, SNL, Parallel Computational Sciences
// Creation Date : 08/09/04
//-----------------------------------------------------------------------------
ExpressionData::~ExpressionData ()
{
  delete expression_;

  for (Util::Op::OpList::iterator it = expressionOps_.begin(); it != expressionOps_.end(); ++it)
    delete *it;
}


bool ExpressionData::parsed() const
{
  return expression_ ? expression_->parsed() : false;
}

//-----------------------------------------------------------------------------
// Function      : ExpressionData::evaluate
// Purpose       :
// Special Notes :
// Scope         : public
// Creator       : Eric R. Keiter, SNL, Parallel Computational Sciences
// Creation Date : 08/09/04
//-----------------------------------------------------------------------------
double
ExpressionData::evaluate(
  Parallel::Machine     comm,
  double                current_circuit_time,
  const Linear::Vector *  solnVecPtr,
  const Linear::Vector *  stateVecPtr,
  const Linear::Vector *  stoVecPtr,
  const Linear::Vector *  solnVecImagPtr) const
{
  if (state_ == NOT_SETUP)
  {
    Report::DevelFatal().in("ExpressionData::evaluate") << "Must call setup() prior to evaluate()";
  }
  else if (state_ == PARSE_FAILED)
  {
    Report::DevelFatal().in("ExpressionData::evaluate") << "Expression parse failed";
  }
  else if (state_ == UNRESOLVED_SYMBOL)
  {
    Report::DevelFatal().in("ExpressionData::evaluate") << "Unresolved symbols in expression";
  }

  double value = 0.0;

  if (solnVecPtr)
  {
    // loop over expressionOps_ to get all the values.
    variableValues_.clear();
    for (Util::Op::OpList::const_iterator it = expressionOps_.begin(); it != expressionOps_.end(); ++it)
    {
      Util::Op::OpData opDataTmp(0, solnVecPtr, solnVecImagPtr, stateVecPtr, stoVecPtr, 0);

      variableValues_.push_back( Util::Op::getValue(comm, *(*it), opDataTmp).real());
    }

    // STD and DDT are implicitly time dependent.  Check the underlying expression
    // for time dependence, and if it is set the current time in the underlying expression
    if (expression_->isTimeDependent())
    {
      expression_->set_sim_time(current_circuit_time);
    }

    // now get expression value and partial derivatives.
    // Note that for these purposes (.PRINT output) we only
    // really need the value, not the derivs.
    if (expression_)
    {
      expression_->evaluateFunction(value, variableValues_);
    }
  }

  return value;
}

//-----------------------------------------------------------------------------
// Function      : ExpressionData::evaluate
// Purpose       :
// Special Notes :
// Scope         : public
// Creator       : Eric R. Keiter, SNL, Parallel Computational Sciences
// Creation Date : 02/16/2015
//-----------------------------------------------------------------------------
double
ExpressionData::evaluate(
  Parallel::Machine             comm,
  double                        current_circuit_time,
  const Util::Op::OpData &      op_data) const
{
  if (state_ == NOT_SETUP)
  {
    Report::DevelFatal().in("ExpressionData::evaluate") << "Must call setup() prior to evaluate()";
  }
  else if (state_ == PARSE_FAILED)
  {
    Report::DevelFatal().in("ExpressionData::evaluate") << "Expression parse failed";
  }
  else if (state_ == UNRESOLVED_SYMBOL)
  {
    Report::DevelFatal().in("ExpressionData::evaluate") << "Unresolved symbols in expression";
  }

  double value = 0.0;

  // loop over expressionOps_ to get all the values.
  variableValues_.clear();
  for (Util::Op::OpList::const_iterator it = expressionOps_.begin(); it != expressionOps_.end(); ++it)
  {
    variableValues_.push_back( Util::Op::getValue(comm, *(*it), op_data).real());
  }

  // STD and DDT are implicitly time dependent.  Check the underlying expression
  // for time dependence, and if it is set the current time in the underlying expression
  if (expression_->isTimeDependent())
  {
    expression_->set_sim_time(current_circuit_time);
  }

  // now get expression value and partial derivatives.
  // Note that for these purposes (.PRINT output) we only
  // really need the value, not the derivs.
  if (expression_)
  {
    expression_->evaluateFunction(value, variableValues_);
  }

  return value;
}

//-----------------------------------------------------------------------------
// Namespace     : Unnamed
// Purpose       : file-local scoped methods and data
// Special Notes : just the declaration, definition at end of file
// Creator       : Tom Russo, SNL
// Creation Date : 11/27/2013
//-----------------------------------------------------------------------------
namespace {
void convertNodalComputation(std::string &nodalComputation, ParamList &paramList);
} // namespace (unnamed)

//-----------------------------------------------------------------------------
// Function      : ExpressionData::setup
//
// Purpose       : Manages all the basic setup for this class.
//
// Special Notes : Originally, all this stuff was in the constructor,
//                 but it needs to happen after topology is
//                 completely done setting itself up, and the
//                 constructor call was too early for that.
//
// Scope         : public
// Creator       : Eric R. Keiter, SNL, Parallel Computational Sciences
// Creation Date : 08/10/04
//-----------------------------------------------------------------------------
ExpressionData::State
ExpressionData::setup(
  Parallel::Machine                     comm,
  const Util::Op::BuilderManager &      op_builder_manager,
  const Util::ParamMap &                context_function_map,
  const Util::ParamMap &                context_param_map,
  const Util::ParamMap &                context_global_param_map)
{
  int unresolved_symbol_count = 0;

  // allocate expression pointer if we need to
  if( expression_ == NULL )
  {
    expression_ = new Expression(expressionString_);
  }

  if (!expression_->parsed())
  {
    state_ = PARSE_FAILED;
    return state_;
  }

  std::vector<std::string> global_function_names;

  // query the expression object for all of its dependent vars.
  expression_->get_names(XEXP_FUNCTION, global_function_names);

  for (std::vector<std::string>::iterator it = global_function_names.begin(), end = global_function_names.end(); it != end; ++it)
  {
    Util::ParamMap::const_iterator x = context_function_map.find(*it);

    if (x == context_function_map.end())
    {
      Report::UserError0() << "Cannot find global function definition for " << *it << " in expression " << expression_->get_expression();
      break;
    }

    const Util::Param &functionParameter = (*x).second;

    std::string functionPrototype(functionParameter.tag());
    std::string functionBody(functionParameter.stringValue());

    // The function prototype is defined here as a string whose
    // value is the  function name together with its parenthese
    // enclosed comma separated argument list. To resolve a
    // function, create an expression from the function prototype
    // and get its ordered list of arguments via get_names, then
    // create an expression from the function definition and
    // order its names from that list. Finally, replace the
    // function in the expression to be resolved.
    Util::Expression prototypeExression(functionPrototype);
    std::vector<std::string> arguments;
    prototypeExression.get_names(XEXP_STRING, arguments);
    Util::Expression functionExpression(functionBody);
    functionExpression.order_names(arguments);

    if (expression_->replace_func(*it, functionExpression, static_cast<int>(arguments.size())) < 0)
    {
      Report::UserError0() << "Wrong number of arguments for user defined function " << functionPrototype << " in expression " << expression_->get_expression();
    }
  }

  // this varNames vec is a list of string representations of all of
  // the vars in the expression.  use this list to make a list of
  // Param objects which we can then call the
  // IO::OutputMgr::setParamContextType() and then use
  // getPrintValue_() to get the results.  This reuses code that is
  // already in place to handle solution, state, store and lead
  // currents.

  ParamList param_list;

  // query the expression object for all of its dependent vars.
  std::vector<Xyce::Util::ExpressionSymbolTableEntry> theSymbolTable;
  
  expression_ -> getSymbolTable(theSymbolTable);
  for (std::vector<Xyce::Util::ExpressionSymbolTableEntry>::iterator it = theSymbolTable.begin(), end = theSymbolTable.end(); it != end; ++it)
  {
    std::string varName = it -> name;
    int varType = it -> type;
    char varLeadDesignator = it -> leadDesignator;
    
    // based on the type of variable, create the needed Param
    // objects for setParmContextType_ to work.

    switch (varType)
    {
      case XEXP_NODAL_COMPUTATION:
        // deconstruct the string and turn it into params, push back into
        // param_list
        convertNodalComputation(varName, param_list);
        break;

      case XEXP_NODE:
        param_list.push_back(Param( "V" , 1 ));
        param_list.push_back(Param( varName , 0.0 ));
        break;

      case XEXP_INSTANCE:
      case XEXP_LEAD:
      {
        std::string currentName("I");
        if( (varLeadDesignator != 0) && (varLeadDesignator!=' ') )
        {
          currentName = currentName + varLeadDesignator;
        }
        param_list.push_back( Param( currentName , 1 ) );
        param_list.push_back( Param( varName , 0.0 ) );
      }
      break;

      case XEXP_SPECIAL:
        param_list.push_back( Param( varName , 0.0 ) );
        break;

      case XEXP_STRING:
      {
        Util::ParamMap::const_iterator param_it = context_param_map.find(varName);
        if (param_it != context_param_map.end())
        {
          const Util::Param &replacement_param = (*param_it).second;

          if ( replacement_param.getType() == Xyce::Util::STR ||
               replacement_param.getType() == Xyce::Util::DBLE )
          {
            if (!expression_->make_constant(varName, replacement_param.getImmutableValue<double>()))
            {
              Report::UserWarning0() << "Problem converting parameter " << varName << " to its value.";
            }
          }
          else if (replacement_param.getType() == Xyce::Util::EXPR)
          {
            std::string expressionString=expression_->get_expression();
            if (expression_->replace_var(varName, replacement_param.getValue<Util::Expression>()) != 0)
            {
              Report::UserWarning0() << "Problem inserting expression " << replacement_param.getValue<Util::Expression>().get_expression()
                                     << " as substitute for " << varName << " in expression " << expressionString;
            }
          }
        }
        else
        {
          param_it = context_global_param_map.find(varName);
          if (param_it != context_global_param_map.end())
          {
            const Util::Param &replacement_param = (*param_it).second;

            if (!expression_->make_var(varName))
            {
              Report::UserWarning0() << "Problem setting global parameter " << varName;
            }
            param_list.push_back( Param( "GLOBAL_PARAMETER" , varName ) );
          }
          else
            param_list.push_back( Param( varName , 0.0 ) );
        }
      }
      break;

      case XEXP_VARIABLE:
        // this case is a global param that must be resolved at each use because
        // it can change during a simulation
        param_list.push_back( Param( "GLOBAL_PARAMETER" , varName ) );
        break;

      default:
      {
        Report::UserError0() << "Can't find context for expression variable " << varName << " in expression "
                               << expressionString_ << std::endl
                               << "Please check to ensure this parameter is correct and set in your netlist.";
        ++unresolved_symbol_count;
      }
    }
  }

  Parallel::AllReduce(comm, MPI_MIN, &unresolved_symbol_count, 1);

  if (unresolved_symbol_count > 0 )
  {
    state_ = UNRESOLVED_SYMBOL;
    return state_;
  }

  state_ = READY;

  Util::Op::makeOps(comm, op_builder_manager, NetlistLocation(), param_list.begin(), param_list.end(), std::back_inserter(expressionOps_));

  return state_;
}


//-----------------------------------------------------------------------------
// Namespace     : Unnamed
// Purpose       : file-local scoped methods and data
// Special Notes :
// Creator       : Tom Russo, SNL
// Creation Date : 11/27/2013
//-----------------------------------------------------------------------------
namespace {

//-----------------------------------------------------------------------------
// Function      : convertNodalComputation
// Purpose       : given a nodal expression string (e.g. "VM(A,B)"),
//                 construct the set of Params that makeOps would expect for
//                 it
// Special Notes :
//
// Scope         : file-local
// Creator       : Tom Russo
// Creation Date : 11/27/2013
//-----------------------------------------------------------------------------
void
convertNodalComputation(
  std::string &         nodalComputation,
  ParamList &           paramList)
{
  ParamList tempParamList;

  std::size_t firstParen = nodalComputation.find_first_of("(");
  std::size_t lastParen = nodalComputation.find_first_of("(");
  // the length of the name of the param is actually equal to the position
  // of the first paren
  std::string compName=nodalComputation.substr(0,firstParen);
  std::string args=nodalComputation.substr(firstParen+1,nodalComputation.length()-compName.length()-2);

  if (DEBUG_EXPRESSION)
    Xyce::dout() << "Processing nodalComputation : " << nodalComputation << Util::push<< std::endl
                 << "name of computation: " << compName << std::endl
                 << "args: " << args << Util::push << std::endl;

  std::size_t firstComma=args.find_first_of(",");
  while (firstComma != std::string::npos)
  {
    std::string arg = args.substr(0,firstComma);
    std::size_t argsLength = args.length();
    args = args.substr(firstComma+1,argsLength-arg.length()-1);
    firstComma = args.find_first_of(",");
    tempParamList.push_back(Param(arg,0.0));
    if (DEBUG_EXPRESSION)
      Xyce::dout() << "arg " << arg << std::endl;
  }

  tempParamList.push_back(Param(args, 0.0));

  if (DEBUG_EXPRESSION)
    Xyce::dout() << "Remaining arg " << args << std::endl
                 << "There were " << tempParamList.size() << " args." << Util::pop << std::endl
                 << Util::pop << std::endl;

  paramList.push_back(Param(compName, static_cast<int>(tempParamList.size())));
  std::copy (tempParamList.begin(), tempParamList.end(), std::back_inserter(paramList));

} // namespace (unnammed)

}
} // namespace Util
} // namespace Xyce
