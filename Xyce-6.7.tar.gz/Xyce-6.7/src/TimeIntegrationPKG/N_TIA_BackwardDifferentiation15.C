//-----------------------------------------------------------------------------
// Copyright Notice
//
//   Copyright 2002 Sandia Corporation. Under the terms
//   of Contract DE-AC04-94AL85000 with Sandia Corporation, the U.S.
//   Government retains certain rights in this software.
//
//    Xyce(TM) Parallel Electrical Simulator
//    Copyright (C) 2002-2017 Sandia Corporation
//
//    This program is free software: you can redistribute it and/or modify
//    it under the terms of the GNU General Public License as published by
//    the Free Software Foundation, either version 3 of the License, or
//    (at your option) any later version.
//
//    This program is distributed in the hope that it will be useful,
//    but WITHOUT ANY WARRANTY; without even the implied warranty of
//    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//    GNU General Public License for more details.
//
//    You should have received a copy of the GNU General Public License
//    along with this program.  If not, see <http://www.gnu.org/licenses/>.
//-----------------------------------------------------------------------------

//-----------------------------------------------------------------------------
//
// Purpose       : This file contains the functions which define the
//		             backward differentiation, order 1-5, class.
//
// Special Notes :
//
// Creator       : Todd Coffey
//
// Creation Date : 2/16/04
//
//
//
//
//-----------------------------------------------------------------------------

#include <Xyce_config.h>

// ---------- Standard Includes ----------
#include <iostream>

// ----------   Xyce Includes   ----------
#include <N_TIA_TimeIntegrationMethods.h>

#include <N_ANP_OutputMgrAdapter.h>
#include <N_ERH_ErrorMgr.h>
#include <N_IO_InitialConditions.h>
#include <N_LAS_BlockVector.h>
#include <N_LAS_Matrix.h>
#include <N_LAS_Builder.h>
#include <N_LAS_Vector.h>
#include <N_PDS_Comm.h>
#include <N_PDS_Manager.h>
#include <N_TIA_BackwardDifferentiation15.h>
#include <N_TIA_DataStore.h>
#include <N_TIA_StepErrorControl.h>
#include <N_TIA_TIAParams.h>
#include <N_UTL_MachDepParams.h>
#include <N_UTL_Diagnostic.h>
#include <N_UTL_FeatureTest.h>

namespace Xyce {
namespace TimeIntg {

const char *
BackwardDifferentiation15::name = "Backward Differentiation 15";

//-----------------------------------------------------------------------------
// Function      : BackwardDifferentiation15::factory
// Purpose       :
// Special Notes :
// Scope         : public
// Creator       : Todd Coffey, SNL
// Creation Date : 2/16/04
//-----------------------------------------------------------------------------
TimeIntegrationMethod *
BackwardDifferentiation15::factory(
    const TIAParams &   tia_params,
    StepErrorControl &  step_error_control,
    DataStore &         data_store)
{
  return new BackwardDifferentiation15(tia_params, step_error_control, data_store);
}

//-----------------------------------------------------------------------------
// Function      : BackwardDifferentiation15::
//                                               BackwardDifferentiation15
// Purpose       : constructor
// Special Notes :
// Scope         : public
// Creator       : Todd Coffey, SNL
// Creation Date : 2/16/04
//-----------------------------------------------------------------------------

BackwardDifferentiation15::BackwardDifferentiation15(
  const TIAParams &     tia_params,
  StepErrorControl &    secTmp,
  DataStore &           dsTmp)
  : TimeIntegrationMethod(),
    ds(dsTmp),
    sec(secTmp),
    leadingCoeff(1.0),
    sn0Ptr(0),
    qpn0Ptr(0),
    spn0Ptr(0),
    ston0Ptr(0),
    leadCurrentn0Ptr(0),
    leadCurrentQn0Ptr(0),
    leadCurrentQpn0Ptr(0),
    leadDeltaVn0Ptr(0),
    sNewtonCorrectionPtr(0),
    stoNewtonCorrectionPtr(0),
    leadCurrentNewtonCorrectionPtr(0),
    leadCurrentQNewtonCorrectionPtr(0),
    leadCurrentQDerivNewtonCorrectionPtr(0),
    leadDeltaVNewtonCorrectionPtr(0)
{
  leadingCoeff = 1;
  sec.maxOrder_ = std::min(5, tia_params.maxOrder);
  sec.minOrder_ = std::max(1, tia_params.minOrder);
  if (sec.minOrder_ > sec.maxOrder_)
  {
    sec.minOrder_ = sec.maxOrder_;
  }
  timept_ = -1.0;

  // Allocate local vectors
  qpn0Ptr = ds.builder_.createVector();
  sn0Ptr = ds.builder_.createStateVector();
  spn0Ptr = ds.builder_.createStateVector();
  ston0Ptr = ds.builder_.createStoreVector();
  leadCurrentn0Ptr = ds.builder_.createLeadCurrentVector();
  leadCurrentQn0Ptr = ds.builder_.createLeadCurrentVector();
  leadCurrentQpn0Ptr = ds.builder_.createLeadCurrentVector();
  leadDeltaVn0Ptr = ds.builder_.createLeadCurrentVector();
  sNewtonCorrectionPtr = ds.builder_.createStateVector();
  stoNewtonCorrectionPtr = ds.builder_.createStoreVector();
  leadCurrentNewtonCorrectionPtr = ds.builder_.createLeadCurrentVector();
  leadCurrentQNewtonCorrectionPtr = ds.builder_.createLeadCurrentVector();
  leadCurrentQDerivNewtonCorrectionPtr = ds.builder_.createLeadCurrentVector();
  leadDeltaVNewtonCorrectionPtr = ds.builder_.createLeadCurrentVector();

  sec.currentOrder_ = (std::min(sec.currentOrder_, sec.maxOrder_) );
}


//-----------------------------------------------------------------------------
// Function      : BackwardDifferentiation15::~BackwardDifferentiation15
// Purpose       : destructor
// Special Notes :
// Scope         : public
// Creator       : Todd Coffey, SNL
// Creation Date : 2/16/04
//-----------------------------------------------------------------------------
BackwardDifferentiation15::~BackwardDifferentiation15()
{
  delete qpn0Ptr;
  delete sn0Ptr;
  delete spn0Ptr;
  delete ston0Ptr;
  delete leadCurrentn0Ptr;
  delete leadCurrentQn0Ptr;
  delete leadCurrentQpn0Ptr;
  delete leadDeltaVn0Ptr;
  delete sNewtonCorrectionPtr;
  delete stoNewtonCorrectionPtr;
  delete leadCurrentNewtonCorrectionPtr;
  delete leadCurrentQNewtonCorrectionPtr;
  delete leadCurrentQDerivNewtonCorrectionPtr;
  delete leadDeltaVNewtonCorrectionPtr;
}


//-----------------------------------------------------------------------------
// Function      : BackwardDifferentiation15::obtainPredictor
// Purpose       : Calculate predictor
// Special Notes : stored in ds.xn0Ptr,qn0Ptr,qpn0Ptr
// Scope         : public
// Creator       : Todd Coffey, SNL
// Creation Date : 2/16/04
//-----------------------------------------------------------------------------
void BackwardDifferentiation15::obtainPredictor()
{
  // prepare history array for prediction
  for (int i=sec.nscsco_;i<=sec.currentOrder_;++i)
  {
    (ds.xHistory[i])->scale(sec.beta_[i]);
    (ds.qHistory[i])->scale(sec.beta_[i]);
    (ds.sHistory[i])->scale(sec.beta_[i]);
    (ds.stoHistory[i])->scale(sec.beta_[i]);
    (ds.leadCurrentHistory[i])->scale(sec.beta_[i]);
    (ds.leadCurrentQHistory[i])->scale(sec.beta_[i]);
    (ds.leadDeltaVHistory[i])->scale(sec.beta_[i]);
    (ds.leadCurrentQDerivHistory[i])->scale(sec.beta_[i]);
  }

  // evaluate predictor
  *ds.xn0Ptr = *(ds.xHistory[0]);
  *ds.qn0Ptr = *(ds.qHistory[0]);
  *sn0Ptr = *(ds.sHistory[0]);
  *ston0Ptr = *(ds.stoHistory[0]);
  *leadCurrentn0Ptr = (*ds.leadCurrentHistory[0]);
  *leadCurrentQn0Ptr = *(ds.leadCurrentQHistory[0]);
  *leadDeltaVn0Ptr = *(ds.leadDeltaVHistory[0]);

  qpn0Ptr->putScalar(0.0);
  spn0Ptr->putScalar(0.0);
  leadCurrentQpn0Ptr->putScalar(0.0);
  for (int i=1;i<=sec.currentOrder_;++i)
  {
    ds.xn0Ptr->addVec(1.0,*(ds.xHistory[i]));
    ds.qn0Ptr->addVec(1.0,*(ds.qHistory[i]));
    sn0Ptr->addVec(1.0,*(ds.sHistory[i]));
    ston0Ptr->addVec(1.0,*(ds.stoHistory[i]));
    qpn0Ptr->addVec(sec.gamma_[i],*(ds.qHistory[i]));
    spn0Ptr->addVec(sec.gamma_[i],*(ds.sHistory[i]));
    leadCurrentn0Ptr->addVec(1.0,*(ds.leadCurrentHistory[i]));
    leadCurrentQn0Ptr->addVec(1.0,*(ds.leadCurrentQHistory[i]));
    leadCurrentQpn0Ptr->addVec(sec.gamma_[i],*(ds.leadCurrentQHistory[i]));
    leadDeltaVn0Ptr->addVec(1.0,*(ds.leadDeltaVHistory[i]));
  }

  if (DEBUG_TIME && isActive(Diag::TIME_PREDICTOR))
  {
    Xyce::dout().width(21);
    Xyce::dout().precision(13);
    Xyce::dout().setf(std::ios::scientific);
    Xyce::dout() << std::endl;
    Xyce::dout() << Xyce::section_divider << std::endl;
    Xyce::dout() << "  BackwardDifferentiation15::obtainPredictor" << std::endl;
    Xyce::dout() << "\n currentOrder = " << sec.currentOrder_ << std::endl;
    Xyce::dout() << "\n sec.nscsco_: " << sec.nscsco_ << std::endl;
    for (int i=0; i<=sec.currentOrder_ ; ++i)
      Xyce::dout() << "\n sec.beta_[" << i << "] = " << sec.beta_[i] << "\n" << std::endl;
    for (int i=0; i<=sec.currentOrder_ ; ++i)
    {
      Xyce::dout() << "\n xHistory["<< i << "]: \n" << std::endl;
      (ds.xHistory[i])->printPetraObject(Xyce::dout());
      Xyce::dout() << std::endl;
    }
    for (int i=0; i<=sec.currentOrder_ ; ++i)
    {
      Xyce::dout() << "\n qHistory["<< i << "]: \n" << std::endl;
      (ds.qHistory[i])->printPetraObject(Xyce::dout());
      Xyce::dout() << std::endl;
    }
    for (int i=0; i<=sec.currentOrder_ ; ++i)
    {
      Xyce::dout() << "\n sHistory["<< i << "]: \n" << std::endl;
      (ds.sHistory[i])->printPetraObject(Xyce::dout());
      Xyce::dout() << std::endl;
    }
    Xyce::dout() << "\n xn0: \n" << std::endl;
    ds.xn0Ptr->printPetraObject(Xyce::dout());
    Xyce::dout() << std::endl;
    Xyce::dout() << "\n qn0: \n" << std::endl;
    ds.qn0Ptr->printPetraObject(Xyce::dout());
    Xyce::dout() << std::endl;
    Xyce::dout() << "\n qpn0: \n" << std::endl;
    qpn0Ptr->printPetraObject(Xyce::dout());
    Xyce::dout() << std::endl;
    Xyce::dout() << "\n sn0: \n" << std::endl;
    sn0Ptr->printPetraObject(Xyce::dout());
    Xyce::dout() << std::endl;
    Xyce::dout() << "\n spn0: \n" << std::endl;
    spn0Ptr->printPetraObject(Xyce::dout());
    Xyce::dout() << std::endl;
    Xyce::dout() << Xyce::section_divider << std::endl;
  }
  // copy the prediction into the next solution:
  *(ds.nextSolutionPtr) = *(ds.xn0Ptr);
}

//-----------------------------------------------------------------------------
// Function      : BackwardDifferentiation15::obtainResidual
// Purpose       : Calculate Residual
// Special Notes :
// Scope         : public
// Creator       : Todd Coffey, SNL
// Creation Date : 3/8/04
//-----------------------------------------------------------------------------
void BackwardDifferentiation15::obtainResidual()
{
  // output: ds.RHSVectorPtr

  // This function returns the following residual:
  // $qpn0 - (sec.alphas_/hn)(Q(x)-qn0)+F(x)-B(t)$

  // Note:  ds.nextSolutionPtr is used to get Q,F,B in Analysis::AnalysisManager::loadRHS.
  ds.RHSVectorPtr->linearCombo(1.0,*ds.daeQVectorPtr,-1.0,*ds.qn0Ptr);
  ds.RHSVectorPtr->update(1.0,*qpn0Ptr,-sec.alphas_/sec.currentTimeStep);

  if (DEBUG_TIME && isActive(Diag::TIME_RESIDUAL))
  {
    Xyce::dout() << std::endl;
    Xyce::dout() << Xyce::section_divider << std::endl;
    Xyce::dout() << "  BackwardDifferentiation15::obtainResidual" << std::endl;
    Xyce::dout() << "\n t = " << sec.nextTime << "\n" << std::endl;
    Xyce::dout() << "\n solution: \n" << std::endl;
    ds.nextSolutionPtr->printPetraObject(Xyce::dout());
    Xyce::dout() << "\n daeQVector: \n" << std::endl;
    ds.daeQVectorPtr->printPetraObject(Xyce::dout());
    Xyce::dout() << "\n qn0: \n" << std::endl;
    ds.qn0Ptr->printPetraObject(Xyce::dout());
    Xyce::dout() << "\n qpn0: \n" << std::endl;
    qpn0Ptr->printPetraObject(Xyce::dout());
    Xyce::dout() << "\n sec.alphas_/hn: " << sec.alphas_/sec.currentTimeStep << "\n" << std::endl;
    Xyce::dout() << "\n daeFVector: \n" << std::endl;
    ds.daeFVectorPtr->printPetraObject(Xyce::dout());

    Xyce::dout() << "\n dQdt-vector: \n" << std::endl;
    ds.RHSVectorPtr->printPetraObject(Xyce::dout());
    Xyce::dout() << std::endl;
  }

  ds.RHSVectorPtr->update(1.0,*ds.daeFVectorPtr,-1.0,*ds.daeBVectorPtr,1.0);

  // since the nonlinear solver is expecting a -f, scale by -1.0:
  ds.RHSVectorPtr->scale(-1.0);

  // if voltage limiting is on, add it in:
  if (ds.limiterFlag)
  {
    (ds.dQdxdVpVectorPtr)->scale( -sec.alphas_/sec.currentTimeStep );

    (ds.RHSVectorPtr)->daxpy(
      *(ds.RHSVectorPtr), +1.0, *(ds.dQdxdVpVectorPtr));

    (ds.RHSVectorPtr)->daxpy(
      *(ds.RHSVectorPtr), +1.0, *(ds.dFdxdVpVectorPtr));
  }

  if (DEBUG_TIME && isActive(Diag::TIME_RESIDUAL))
  {
    Xyce::dout() << "\n Residual-vector: \n" << std::endl;
    Xyce::dout() << "-(qpn0-(sec.alpha_s/h)*(Q-qn0)+F-B) \n" << std::endl;
    ds.RHSVectorPtr->printPetraObject(Xyce::dout());
    Xyce::dout() << Xyce::section_divider << std::endl;
    Xyce::dout() << std::endl;
  }
}

//-----------------------------------------------------------------------------
// Function      : BackwardDifferentiation15::obtainSensitivityResiduals
// Purpose       : Calculate Residual
// Special Notes :
// Scope         : public
// Creator       : Eric Keiter, SNL
// Creation Date :
//-----------------------------------------------------------------------------
void BackwardDifferentiation15::obtainSensitivityResiduals()
{}

//-----------------------------------------------------------------------------
// Function      : BackwardDifferentiation15::obtainAdjointSensitivityResidual
// Purpose       : Calculate Residual
// Special Notes :
// Scope         : public
// Creator       : Eric Keiter, SNL
// Creation Date : 2/23/2015
//-----------------------------------------------------------------------------
void BackwardDifferentiation15::obtainAdjointSensitivityResidual()
{}

//-----------------------------------------------------------------------------
// Function      : BackwardDifferentiation15::obtainJacobian
// Purpose       : Calculate Jacobian
// Special Notes :
// Scope         : public
// Creator       : Todd Coffey, SNL
// Creation Date : 3/8/04
//-----------------------------------------------------------------------------

void BackwardDifferentiation15::obtainJacobian()
{
  if (DEBUG_TIME && isActive(Diag::TIME_JACOBIAN))
  {
    Xyce::dout() << std::endl;
    Xyce::dout() << Xyce::section_divider << std::endl;
    Xyce::dout() << "  BackwardDifferentiation15::obtainJacobian" << std::endl;
  }

  // output: ds.JMatrixPtr

  // This function returns the following matrix:
  // $-(sec.alphas_/hn)dQdx(x)+dFdx$

  // Note:  ds.nextSolutionPtr is used to get dQdx,dFdx in Analysis::AnalysisManager::loadJacobian.
//  ds.JmatrixPtr->linearCombo(-sec.alphas_/sec.currentTimeStep,*ds.dQdxMatrixPtr,+1.0,*ds.dFdxMatrixPtr);

  Linear::Matrix & dQdx = *(ds.dQdxMatrixPtr);
  Linear::Matrix & dFdx = *(ds.dFdxMatrixPtr);
  Linear::Matrix & Jac = *(ds.JMatrixPtr);

  double qscalar(-sec.alphas_/sec.currentTimeStep);

  Jac.linearCombo( qscalar, dQdx, 1.0, dFdx );

  if (DEBUG_TIME && isActive(Diag::TIME_JACOBIAN))
  {
    Xyce::dout() << "\n dFdx:" <<std::endl;
    dFdx.printPetraObject(Xyce::dout());
    Xyce::dout() << "\n Total Jacobian:" <<std::endl;
    Jac.printPetraObject(Xyce::dout());
//    for (int i=0;i<3;++i)
//    {
//      printf("[ %25.20g\t%25.20g\t%25.20g ]\n",Jac[i][0],Jac[i][1],Jac[i][2]);
//    }

    Xyce::dout() << Xyce::section_divider << std::endl;
    Xyce::dout() << std::endl;
  }
}

//-----------------------------------------------------------------------------
// Function      : BackwardDifferentiation15::interpolateSolution
// Purpose       : Interpolate solution approximation at prescribed time point.
// Special Notes : This routine computes the solution at the output
//               : timepoint by intepolation of the history using the order
//               : used for the most recent completed step, orderUsed.
//               : The output is put into ds.tmpSolVectorPtr.
// Scope         : public
// Creator       : Todd Coffey, SNL
// Creation Date : 2/16/04
//-----------------------------------------------------------------------------

bool BackwardDifferentiation15::interpolateSolution(double timepoint,
    	Linear::Vector * tmpSolVectorPtr, std::vector<Linear::Vector*> & historyVec)
{
  // 03/23/04 tscoffe:  Currently this code is nearly identical to the IDA code
  // for interpolating to an output time.  Either we acknowledge the copyright,
  // the list of conditions in the license and the disclaimer or we rewrite this
  // function.  The IDA license is included after this routine.
  double tfuzz;   // fuzz factor to check for valid output time
  double tp;      // approximately t_{n-1}
  double delt;    // distance between timepoint and currentTime
  double c = 1.0; // coefficient for interpolation
  double gam;     // coefficient for interpolation
  int kord;       // order of interpolation
  double tn = sec.currentTime;
  double hh = sec.currentTimeStep;
  double hused = sec.usedStep_;
  int kused = sec.usedOrder_;
  // TVR: changed line below in addressing bug 1258
  // This is what was here prior to my change:
  //  double uround = 0.0;  // unit round-off (set to zero for now)
  // The value below is a WAG
  double uround = Util::MachineDependentParams::MachinePrecision();

  tfuzz = 100 * uround * (tn + hh);
  tp = tn - hused - tfuzz;

  if ( (timepoint - tp)*hh < 0.0 )
    return false;

  *tmpSolVectorPtr = *(historyVec[0]);
  kord = kused;
  if ( (kused == 0) || (timepoint == tn) )
    kord = 1;

  delt = timepoint - tn;
  gam = delt/sec.psi_[0];
  for (int j=1 ; j <= kord ; ++j)
  {
    c = c*gam;
    gam = (delt + sec.psi_[j-1])/sec.psi_[j];
    tmpSolVectorPtr->addVec(c,*(historyVec[j]));
  }
  return true;
}

//-----------------------------------------------------------------------------
// Function      : BackwardDifferentiation15::interpolateMPDESolution
// Purpose       : Interpolate solution approximation at prescribed time points.
// Special Notes : This routine computes the solution at the output
//               : timepoints by intepolation of the history using the order
//               : used for the most recent completed step, orderUsed.
//               : The output is put into provided Linear::Vector pointer.
//               : The interpolation is as follows:
//               : tmpSolVectorPtr->block(i) is interpolated at timepoint(i)
//               : Therefore, if you want them all interpolated at the same time,
//               : then use timepoint(i) = timepoint(0) forall i
//               : or use interpolateSolution.
// Scope         : public
// Creator       : Todd Coffey, Eric Keiter, SNL
// Creation Date : 11/28/06
//-----------------------------------------------------------------------------

bool BackwardDifferentiation15::interpolateMPDESolution(std::vector<double>& timepoint,
    	Linear::Vector * tmpSolVectorPtr)
{
  Linear::BlockVector * blockTempSolVectorPtr =
     dynamic_cast<Linear::BlockVector*>(tmpSolVectorPtr);
  if (blockTempSolVectorPtr == NULL)
  {
    Report::DevelFatal0().in("BackwardDifferentiation15::interpolateMPDESolution")
      << "Linear::Vector tmpSolVectorPtr is not of type Linear::BlockVector";
    return(false);
  }

  double tfuzz;   // fuzz factor to check for valid output time
  double tp;      // approximately t_{n-1}
  int numblocks = timepoint.size();
  int blockCount = blockTempSolVectorPtr->blockCount();
  if (numblocks > blockCount)
  {
    Report::DevelFatal0().in("BackwardDifferentiation15::interpolateMPDESolution")
      << "Number of time points requested is greater than number of fast time points in MPDE block vector";
    return(false);
  }
  double delt;
  double c = 1.0;
  double gam;
  int kord;       // order of interpolation
  double tn = sec.currentTime;
  double hh = sec.currentTimeStep;
  double hused = sec.usedStep_;
  int kused = sec.usedOrder_;
  double uround = 0.0;  // unit round-off (set to zero for now)

  tfuzz = 100 * uround * (tn + hh);
  tp = tn - hused - tfuzz;
  for (int i=0; i<numblocks ; ++i)
  {
    if ( (timepoint[i] - tp)*hh < 0.0 )
      return false;
  }

  *tmpSolVectorPtr = *(ds.xHistory[0]);

  Linear::Vector * solVectorPtr;
  Linear::Vector * xHistoryVectorPtr;
  // Loop over blocks first so that maximal order can be maintained
  for (int i=0; i < numblocks ; ++i)
  {
    if ((kused == 0) || (timepoint[i] == tn)) { kord = 1; }
    else { kord = kused; }
    solVectorPtr = &(blockTempSolVectorPtr->block(i));
    c = 1.0;
    delt = timepoint[i] - tn;
    gam = delt/sec.psi_[0];
    for (int j=1 ; j <= kord ; ++j)
    {
      c = c*gam;
      gam = (delt + sec.psi_[j-1])/sec.psi_[j];
      Linear::BlockVector * blockXHistoryVectorPtr =
        dynamic_cast<Linear::BlockVector*>(ds.xHistory[j]);
      if (blockXHistoryVectorPtr == NULL)
      {
        Xyce::Report::DevelFatal0().in("BackwardDifferentiation15::interpolateMPDESolution") << "Linear::Vector ds.xHistory[j] is not of type Linear::BlockVector\n j = " << j;
        return(false);
      }
      xHistoryVectorPtr = &(blockXHistoryVectorPtr->block(i));
      solVectorPtr->addVec(c,*xHistoryVectorPtr);
    }
  }
  return true;
}

//-----------------------------------------------------------------------------
// Function      : BackwardDifferentiation15::printMPDEOutputSolution()
// Purpose       : Print transient output from MPDE simulation
// Special Notes : This routine uses interpolateMPDESolution.
// Scope         : public
// Creator       : Todd Coffey, SNL, 1414
// Creation Date : 11/28/06
//-----------------------------------------------------------------------------
bool BackwardDifferentiation15::printMPDEOutputSolution(
  Analysis::OutputMgrAdapter & outputManagerAdapter,
  const double time,
  Linear::Vector * solnVecPtr,
  const std::vector<double> & fastTimes )
{
  if (DEBUG_TIME && isActive(Diag::TIME_OUTPUT))
  {
    Xyce::dout() << std::endl;
    Xyce::dout() << Xyce::section_divider << std::endl;
    Xyce::dout() << "  BackwardDifferentiation15::printMPDEOutputSolution" << std::endl;
  }

  double timestep = sec.lastAttemptedTimeStep;
  double lasttime = sec.currentTime - timestep;
  double tn = sec.currentTime;
  // Set these values up to read output time intervals.  FIXME
  double beg_of_output_time_interval = lasttime;
  double end_of_output_time_interval = tn;
  double start_time = std::max(lasttime,beg_of_output_time_interval);
  double stop_time = std::min(tn,end_of_output_time_interval);
  if (DEBUG_TIME && isActive(Diag::TIME_OUTPUT))
  {
    Xyce::dout() << "timestep = " << timestep << std::endl;
    Xyce::dout() << "lasttime = " << lasttime << std::endl;
    Xyce::dout() << "tn = " << tn << std::endl;
    Xyce::dout() << "beg_of_output_time_interval = " << beg_of_output_time_interval << std::endl;
    Xyce::dout() << "end_of_output_time_interval = " << end_of_output_time_interval << std::endl;
    Xyce::dout() << "start_time = " << start_time << std::endl;
    Xyce::dout() << "stop_time = " << stop_time << std::endl;
  }

  Linear::BlockVector * blockTmpSolVectorPtr =
    dynamic_cast<Linear::BlockVector*>(ds.tmpSolVectorPtr);

  if (blockTmpSolVectorPtr == NULL)
  {
    Report::DevelFatal0().in("BackwardDifferentiation15::printMPDEOutputSolution")
      << "Linear::Vector ds.tmpSolVectorPtr is not of type Linear::BlockVector";
    return(false);
  }
  int blockCount = blockTmpSolVectorPtr->blockCount();

  // Create list of timepoints to interpolate (along characteristic curve)
  double T2 = fastTimes.back();
  //double charcross = start_time - floor(start_time/T2)*T2; // (start_time mod T2)
  double charcross = fmod(start_time,T2); // (start_time mod T2)
  int s_ind_0 = -1;
  // find s_ind_0 = first fast time point >= charcross.
  // This could probably be made faster: FIXME
  for (int i=0 ; i<=blockCount ; ++i)
  {
    if (fastTimes[i] >= charcross)
    {
      s_ind_0 = i;
      break;
    }
  }
  if (s_ind_0 == -1)
  {
    Report::DevelFatal0().in("BackwardDifferentiation15::printMPDEOutputSolution")
      << "Cannot find where characteristic curve crosses fast time slice at start_time";
    return(false);
  }
  std::vector<double> h2(blockCount,0);
  for (int j=0 ; j < blockCount ; ++j)
  {
    h2[j] = fastTimes[j+1] - fastTimes[j];
  }
  std::vector<double> ti;
  //double first_interp = floor(start_time/T2)*T2 + fastTimes[s_ind_0];
  double first_interp = start_time - charcross + fastTimes[s_ind_0];
  if (DEBUG_TIME && isActive(Diag::TIME_OUTPUT))
  {
    Xyce::dout() << "first_interp = " << first_interp << std::endl;
  }

  if (s_ind_0 == blockCount) { s_ind_0 = 0; };
  // Don't interpolate the first point
  double eps = fabs(start_time)*1.0e-6;
  if ( fabs(first_interp-timept_) <= eps )
  {
    first_interp += h2[s_ind_0];
    s_ind_0++;
    if (s_ind_0 == blockCount) { s_ind_0 = 0; };
    if (DEBUG_TIME && isActive(Diag::TIME_OUTPUT))
    {
      Xyce::dout() << "Moving first_interp forward to avoid duplicate outputs:  " << first_interp << std::endl;
    }
  }
  int sn = s_ind_0;
  double t = first_interp;
  while (t <= stop_time)
  {
    ti.push_back(t);
    t += h2[sn];
    sn++;
    if (sn >= blockCount) { sn = 0; }
  }
  if (DEBUG_TIME && isActive(Diag::TIME_OUTPUT))
  {
    Xyce::dout() << "T2 = " << T2 << std::endl;
    Xyce::dout() << "charcross = " << charcross << std::endl;
    Xyce::dout() << "s_ind_0 = " << s_ind_0 << std::endl;
    Xyce::dout() << "Expecting to interpolate the following points:" << std::endl;
    unsigned int numinterp = ti.size();
    for (unsigned int i=0 ; i < numinterp ; ++i)
    {
      Xyce::dout() << ti[i] << std::endl;
    }
    Xyce::dout() << "Total of " << numinterp << " points" << std::endl;
  }

  timept_ = start_time;  // used later for interpolating stop_time
  unsigned int tinum = ti.size();
  int total_interp = 0;
  std::vector<double> timepoint_vec(blockCount,stop_time);
  int num_interp_this_cycle = 0;
  int s_ind = s_ind_0;
  for (unsigned int i=0; i < tinum ; ++i)
  {
    timepoint_vec[s_ind] = ti[i];
    num_interp_this_cycle++;
    s_ind++;
    if (s_ind >= blockCount) { s_ind = 0; };
    // If we're back to s_ind_0 or out of ti points, then interpolate:
    if ((s_ind == s_ind_0) || (i == tinum-1))
    {
      interpolateMPDESolution(timepoint_vec, ds.tmpSolVectorPtr);
      // Now we print these points out
      int s = s_ind_0;
      for (int j=0 ; j < num_interp_this_cycle ; ++j)
      {
        timept_ = timepoint_vec[s];
        outputManagerAdapter.tranOutput(
          timept_, blockTmpSolVectorPtr->block(s),
          *ds.tmpStaVectorPtr, *ds.tmpStoVectorPtr, *ds.tmpLeadCurrentVectorPtr, *ds.tmpLeadDeltaVPtr, *ds.tmpLeadCurrentQDerivVectorPtr,
          ds.objectiveVec_, ds.dOdpVec_, ds.dOdpAdjVec_,
          ds.scaled_dOdpVec_, ds.scaled_dOdpAdjVec_);
        total_interp++;
        s++;
        if (s >= blockCount) { s = 0; }
        if (DEBUG_TIME && isActive(Diag::TIME_OUTPUT))
          Xyce::dout() << "Interpolated to t = " << timept_ << std::endl;
      }
      num_interp_this_cycle = 0;
    }
  }
  if (DEBUG_TIME && isActive(Diag::TIME_OUTPUT))
    Xyce::dout() << "Total of " << total_interp << " points" << std::endl;

  // Now we interpolate stop_time unless its too close to the last timept interpolated.
  eps = fabs(stop_time)*1.0e-8;
  // fudge factor for printing, this should come from elsewhere FIXME
  if (fabs(timept_ - stop_time) >= eps)
  {
    if (DEBUG_TIME && isActive(Diag::TIME_OUTPUT))
    {
      Xyce::dout() << "Previous timept = " << timept_ << std::endl;
      Xyce::dout() << "Expecting to interpolate the following point: " << stop_time << std::endl;
    }

    Linear::Vector* tmpSolnVecPtr = solnVecPtr;
    Linear::Vector* tmpVecPtr = ds.tmpXn0APtr;
    if (stop_time < tn)
    {
      interpolateSolution(stop_time,ds.tmpXn0BPtr, ds.xHistory);
      tmpSolnVecPtr = ds.tmpXn0BPtr;
    }
    Linear::BlockVector * blockTmpSolnVecPtr =
      dynamic_cast<Linear::BlockVector*>(tmpSolnVecPtr);
    Linear::BlockVector * blockTmpVecPtr =
      dynamic_cast<Linear::BlockVector*>(tmpVecPtr);
    if (blockTmpSolnVecPtr == NULL)
    {
      Report::DevelFatal0().in("BackwardDifferentiation15::printMPDEOutputSolution")
        << "Linear::Vector tmpSolnVecPtr is not of type Linear::BlockVector";
      return(false);
    }
    if (blockTmpVecPtr == NULL)
    {
      Report::DevelFatal0().in("BackwardDifferentiation15::printMPDEOutputSolution")
        << "Linear::Vector tmpVecPtr is not of type Linear::BlockVector";
      return(false);
    }
    // Interpolate where the caracteristic crosses stop_time (instead of start_time).
    //charcross = stop_time - floor(stop_time/T2)*T2;
    charcross = fmod(stop_time,T2);
    int s_ind_1 = -1;
    // Find index just before charcross:
    if( charcross < fastTimes[0] )
    {
      // by periodicity, the one before in this case is the one at the end
      s_ind_1 = blockCount-1;
    }
    else
    {
      for (int i=blockCount-1 ; i>=0 ; --i)
      {
        if (fastTimes[i] <= charcross)
        {
          s_ind_1 = i;
          break;
        }
      }
    }
    if (s_ind_1 == -1)
    {
      Report::DevelFatal0().in("BackwardDifferentiation15::printMPDEOutputSolution")
        << "Cannot find where characteristic curve crosses fast time slice at stop_time";
      return(false);
    }
    int sm = s_ind_1;
    int sp = s_ind_1+1;
    double coeff_sm = fastTimes[sp]-charcross;
    double coeff_sp = charcross-fastTimes[sm];
    if (sp == blockCount) { sp = 0; }
    double dt = h2[s_ind_1];
    timept_ = stop_time;
    if (DEBUG_TIME && isActive(Diag::TIME_OUTPUT))
    {
      Xyce::dout() << "charcross = " << charcross << std::endl;
      Xyce::dout() << "s_ind_1 = " << s_ind_1 << std::endl;
      Xyce::dout() << "sp = " << sp << std::endl;
      Xyce::dout() << "sm = " << sm << std::endl;
      Xyce::dout() << "dt = " << dt << std::endl;
      Xyce::dout() << "timept = " << timept_ << std::endl;
      Xyce::dout() << "coeff_sm = " << coeff_sm << std::endl;
      Xyce::dout() << "coeff_sp = " << coeff_sp << std::endl;
    }

    blockTmpVecPtr->block(0).linearCombo(
      coeff_sm/dt, blockTmpSolnVecPtr->block(sm),
      coeff_sp/dt, blockTmpSolnVecPtr->block(sp)
                                         );
    outputManagerAdapter.tranOutput(
      timept_, blockTmpVecPtr->block(0),
      *ds.tmpStaVectorPtr, *ds.tmpStoVectorPtr, *ds.tmpLeadCurrentVectorPtr, *ds.tmpLeadDeltaVPtr, *ds.tmpLeadCurrentQDerivVectorPtr,
      ds.objectiveVec_, ds.dOdpVec_, ds.dOdpAdjVec_,
      ds.scaled_dOdpVec_, ds.scaled_dOdpAdjVec_);

    if (DEBUG_TIME && isActive(Diag::TIME_OUTPUT))
      Xyce::dout() << "Interpolated to t = " << timept_ << std::endl;
  }

  else if (DEBUG_TIME && isActive(Diag::TIME_OUTPUT))  // no extra interpolation
  {
    Xyce::dout() << "No further interpolation required." << std::endl;
  }

  if (DEBUG_TIME && isActive(Diag::TIME_OUTPUT))
    Xyce::dout() << Xyce::section_divider << std::endl;

  return true;
}


//-----------------------------------------------------------------------------
// Function      : BackwardDifferentiation15::printWaMPDEOutputSolution()
// Purpose       : Print transient output from WaMPDE simulation
// Special Notes : This routine uses interpolateSolution.
// Scope         : public
// Creator       : Todd Coffey, SNL, 1414
// Creation Date : 12/15/06
//-----------------------------------------------------------------------------
bool BackwardDifferentiation15::printWaMPDEOutputSolution(
        Analysis::OutputMgrAdapter & outputManagerAdapter,
        const double time,
        Linear::Vector * solnVecPtr,
        const std::vector<double> & fastTimes,
        const int phiGID )
{
  if (DEBUG_TIME && isActive(Diag::TIME_OUTPUT))
  {
    Xyce::dout() << std::endl;
    Xyce::dout() << Xyce::section_divider << std::endl;
    Xyce::dout() << "  BackwardDifferentiation15::printWaMPDEOutputSolution" << std::endl;
  }

  double timestep = sec.lastAttemptedTimeStep;
  double lasttime = sec.currentTime - timestep;
  double tn = sec.currentTime;
  // Set these values up to read output time intervals.  FIXME
  double beg_of_output_time_interval = lasttime;
  double end_of_output_time_interval = tn;
  double start_time = std::max(lasttime,beg_of_output_time_interval);
  double stop_time = std::min(tn,end_of_output_time_interval);

  if (DEBUG_TIME && isActive(Diag::TIME_OUTPUT))
  {
    Xyce::dout() << "start_time = " << start_time << std::endl;
    Xyce::dout() << "stop_time = " << stop_time << std::endl;
  }

  // 12/15/06 tscoffe:
  // First break the interval up as printOutputSolution does:
  // hh = timestep/(sec.usedOrder_) and interpolate in the intervals:
  // [tn+(i-1)*hh,tn+i*hh], i=1..usedOrder
  // Assume phi(t_1) is linear in these intervals and approximate with:
  // phi(t) = (1/hh)*(phi(tn)(tn+hh-t)+phi(tn+hh)(t-tn))
  // Then the t_1 values we want to interpolate are:
  // n2 = number of fast time points.
  // T2 = fast time period
  // h2 = T2/n2 = average spacing on fast time scale
  // t1_vals = [tn:h2:tn+hh]
  // And the t_2 values we want to interpolate are:
  // t2_vals = phi(t1_vals) mod T2
  // Then take the N_LAS blocks and do 2D linear interpolation on the intervals:
  // (t1,s1), (t1,s2), (t2,s1), (t2,s2)
  // x(t) = x(t,s) approx =
  // (1/(t2-t1))(1/(s2-s1))[  x(t1,s1)(t2-t)(s2-s)
  //                         +x(t1,s2)(t2-t)(s-s1)
  //                         +x(t2,s1)(t-t1)(s2-s)
  //                         +x(t2,s2)(t-t1)(s-s1) ]
  // where t = t1_vals and s = t2_vals

  Linear::BlockVector * blockTmpSolVectorPtr =
    dynamic_cast<Linear::BlockVector*>(ds.tmpSolVectorPtr);
  Linear::BlockVector * blockTmpXn0APtr =
    dynamic_cast<Linear::BlockVector*>(ds.tmpXn0APtr);
  Linear::BlockVector * blockTmpXn0BPtr =
    dynamic_cast<Linear::BlockVector*>(ds.tmpXn0BPtr);
  if (blockTmpSolVectorPtr == NULL)
  {
    Report::DevelFatal0().in("BackwardDifferentiation15::printWaMPDEOutputSolution")
      << "Linear::Vector ds.tmpSolVectorPtr is not of type Linear::BlockVector";
    return(false);
  }
  if (blockTmpXn0APtr == NULL)
  {
    Report::DevelFatal0().in("BackwardDifferentiation15::printWaMPDEOutputSolution")
      << "Linear::Vector ds.tmpXn0APtr is not of type Linear::BlockVector";
    return(false);
  }
  if (blockTmpXn0BPtr == NULL)
  {
    Report::DevelFatal0().in("BackwardDifferentiation15::printWaMPDEOutputSolution")
      << "Linear::Vector ds.tmpXn0BPtr is not of type Linear::BlockVector";
    return(false);
  }
  int phiLID = blockTmpSolVectorPtr->pmap()->globalToLocalIndex(phiGID);
  double hh = timestep/(sec.usedOrder_);
  double timeA = -1.0;
  double timeB = -1.0;
  if (DEBUG_TIME && isActive(Diag::TIME_OUTPUT))
  {
    Xyce::dout() << " sec.usedOrder_ = " << sec.usedOrder_ << std::endl;
    Xyce::dout() << " sec.currentTime_ = " << sec.currentTime << std::endl;
    Xyce::dout() << " lasttime = " << lasttime << std::endl;
  }

  for (int i=0 ; i < sec.usedOrder_ ; ++i)
  {
    if (i == 0)
    {
      bool junk;
      timeA = lasttime + hh*i;
      junk = interpolateSolution(timeA,ds.tmpXn0APtr, ds.xHistory);
      if (!junk)
      {
        Report::DevelFatal0().in("BackwardDifferentiation15::printWaMPDEOutputSolution")
          << "interpolateSolution returned false!";
      }
    }
    else
    {
      // We don't need to interpolate this again.
      *ds.tmpXn0APtr = *ds.tmpXn0BPtr;
      timeA = timeB;
    }
    timeB = lasttime + hh*(i+1);
    interpolateSolution(timeB,ds.tmpXn0BPtr, ds.xHistory);
    if (DEBUG_TIME && isActive(Diag::TIME_OUTPUT))
    {
      Xyce::dout() << "Interpolating in [ " << timeA << ", " << timeB << " ]" << std::endl;
      Xyce::dout() << "timeA = " << timeA << std::endl;
      Xyce::dout() << "timeB = " << timeB << std::endl;
    }

    // Now we can interpolate [tmpXn0APtr,tmpXn0BPtr] in [timeA,timeB].
    std::vector<double> t1vals;
    double T2 = fastTimes.back();
    int blockCount = blockTmpSolVectorPtr->blockCount();
    double h2 = T2/blockCount; // Average mesh width in fast time-scale
    double tval = timeA+h2;
    while (tval <= timeB)
    {
      t1vals.push_back(tval);
      tval += h2;
    }
    // fudge factor for printing, this should come from elsewhere FIXME
    double eps = fabs(timeB)*1.0e-8;
    if ( (t1vals.size() == 0) || (fabs(t1vals.back() - timeB) >= eps) )
    {
      t1vals.push_back(timeB);
    }
    std::vector<double> t2vals, phiAB(2);
    std::vector<double> tmpPhiAB(2, 0.0);
    if (phiLID >= 0)
    {
      tmpPhiAB[0] = (*ds.tmpXn0APtr)[phiLID]; // Get from MPDE Manager
      tmpPhiAB[1] = (*ds.tmpXn0BPtr)[phiLID]; // Get from MPDE Manager
    }
    blockTmpSolVectorPtr->pmap()->pdsComm().sumAll( &tmpPhiAB[0], &phiAB[0], 2 );

    double phiA = phiAB[0], phiB = phiAB[1];
    for (unsigned int j=0 ; j<t1vals.size() ; ++j)
    {
      double phi = (1/(timeB-timeA))*(phiA*(timeB-t1vals[j])+phiB*(t1vals[j]-timeA));
      t2vals.push_back(fmod(phi,T2)); // phi(t1vals[j]) mod T2
    }
    if (DEBUG_TIME && isActive(Diag::TIME_OUTPUT))
    {
      Xyce::dout() << "t1vals = " << std::endl;
      for (unsigned int j=0 ; j < t1vals.size() ; ++j)
      {
        Xyce::dout() << t1vals[j] << std::endl;
      }
      Xyce::dout() << "phi(" << timeA << ") = " << phiA << std::endl;
      Xyce::dout() << "phi(" << timeB << ") = " << phiB << std::endl;
      Xyce::dout() << "t2vals = " << std::endl;
      for (unsigned int j=0 ; j< t2vals.size() ; ++j)
      {
        Xyce::dout() << t2vals[j] << std::endl;
      }
    }

    // Now we can do our block 2D interpolations
    // loop through t1vals and move the fast time blocks as we go
    double t1 = timeA; // slow time indices
    double t2 = timeB;
    double t = t1vals[0]; // current time indices
    double s = t2vals[0];
    int b1,b2; // fast time block indices corresponding to s1,s2
    // Find the block surrounding s:
    b1 = -2;
    for (int j=0 ; j < blockCount ; ++j)
    {
      if ((fastTimes[j] <= s) && (s < fastTimes[j+1]))
      {
        b1 = j;
      }
    }
    b2 = b1+1;
    if (b2 == blockCount)
    {
      b2 = 0;
    }
    double s1 = fastTimes[b1];
    double s2 = fastTimes[b1+1]; // Note:  fastTimes[blockCount] = T2
    if ((s < s1) || (s > s2))
    {
      Report::DevelFatal0().in("BackwardDifferentiation15::printWaMPDEOutputSolution")
        << "  Interpolator cannot find a fast time block containing the first point  ";
    }
    if (DEBUG_TIME && isActive(Diag::TIME_OUTPUT))
    {
      Xyce::dout() << "Found s = " << s << " in block " << b1;
      Xyce::dout() << " with boundary = [" << s1 << "," << s2 << "]" << std::endl;
    }

    for (unsigned int j=0 ; j < t1vals.size() ; ++j)
    {
      t = t1vals[j];
      s = t2vals[j];
      if (t > t2) break; // This should never occur
      // If s has moved outside our block, then increment block.
      if ( (s < s1) || (s > s2) )
      {
        if (DEBUG_TIME && isActive(Diag::TIME_OUTPUT))
          Xyce::dout() << "Incrementing fast time block for next interpolation." << std::endl;

        b1++;
        if (b1 == blockCount)
        {
          b1 = 0;
        }
        b2 = b1+1;
        if (b2 == blockCount)
        {
          b2 = 0;
        }
        s1 = fastTimes[b1];
        s2 = fastTimes[b1+1];
      }
      // If s isn't in the next block, then search for it.
      if ((s < s1) || (s > s2))
      {
        if (DEBUG_TIME && isActive(Diag::TIME_OUTPUT))
          Xyce::dout() << "Searching for fast time block for next interpolation." << std::endl;

        b1 = -2;
        for (int j2=0 ; j2 < blockCount ; ++j2)
        {
          if ((fastTimes[j2] <= s) && (s < fastTimes[j2+1]))
          {
            b1 = j2;
          }
        }
        b2 = b1+1;
        if (b2 == blockCount)
        {
          b2 = 0;
        }
        s1 = fastTimes[b1];
        s2 = fastTimes[b1+1];
      }
      // If a block surrounding s can't be found, then quit.
      if ((s < s1) || (s > s2))
      {
        Report::DevelFatal0().in("BackwardDifferentiation15::printWaMPDEOutputSolution")
          << "  Interpolator moved fast time block but new point is not in this block  ";
      }
      if (s > T2) break; // Just double checking...
      //blockTmpXn0APtr->block(b1) // x(t1,s1)
      //blockTmpXn0APtr->block(b2) // x(t1,s2)
      //blockTmpXn0BPtr->block(b1) // x(t2,s1)
      //blockTmpXn0BPtr->block(b2) // x(t2,s2)
      // (1/(t2-t1))(1/(s2-s1))[  x(t1,s1)(t2-t)(s2-s)
      //                         +x(t1,s2)(t2-t)(s-s1)
      //                         +x(t2,s1)(t-t1)(s2-s)
      //                         +x(t2,s2)(t-t1)(s-s1) ]
      if (DEBUG_TIME && isActive(Diag::TIME_OUTPUT))
      {
        Xyce::dout() << "Interpolating in the block:" << std::endl;
        Xyce::dout() << "(t1,t2) = (" << t1 << "," << t2 << ")" << std::endl;
        Xyce::dout() << "(s1,s2) = (" << s1 << "," << s2 << ")" << std::endl;
      }

      double denom = (t2-t1)*(s2-s1);
      double coeff0 = (t2-t)*(s2-s)/denom;
      double coeff1 = (t2-t)*(s-s1)/denom;
      double coeff2 = (t-t1)*(s2-s)/denom;
      double coeff3 = (t-t1)*(s-s1)/denom;
      (blockTmpSolVectorPtr->block(b1)).linearCombo(
        coeff0, blockTmpXn0APtr->block(b1),
        coeff1, blockTmpXn0APtr->block(b2));
      (blockTmpSolVectorPtr->block(b1)).update(
        coeff2, blockTmpXn0BPtr->block(b1),
        coeff3, blockTmpXn0BPtr->block(b2), 1.0 );

      // erkeite 2/24/07. This is needed because currently the interpolation goes back to t=-1.0.
      if (t >= 0.0)
      {
        outputManagerAdapter.tranOutput(
            t, blockTmpSolVectorPtr->block(b1),
            *ds.tmpStaVectorPtr, *ds.tmpStoVectorPtr, *ds.tmpLeadCurrentVectorPtr, *ds.tmpLeadDeltaVPtr, *ds.tmpLeadCurrentQDerivVectorPtr,
            ds.objectiveVec_, ds.dOdpVec_, ds.dOdpAdjVec_,
            ds.scaled_dOdpVec_, ds.scaled_dOdpAdjVec_);

        if (DEBUG_TIME && isActive(Diag::TIME_OUTPUT))
          Xyce::dout() << "Interpolated to (t,phi(t)) = (" << t << "," << s << ")" << std::endl;
      }
    }
  }

  if (DEBUG_TIME && isActive(Diag::TIME_OUTPUT))
    Xyce::dout() << Xyce::section_divider << std::endl;

  return true;
}

//-----------------------------------------------------------------------------
// Function      : BackwardDifferentiation15::printOutputSolution()
// Purpose       : Print output that is dumbed down in order.
// Special Notes : This routine picks smaller time steps to approximate first
//               : order integration from the perspective of the output.
// Scope         : public
// Creator       : Todd Coffey, SNL, 1414
// Creation Date : 11/21/05
//-----------------------------------------------------------------------------
bool
BackwardDifferentiation15::printOutputSolution(
  Analysis::OutputMgrAdapter &  outputManagerAdapter,
  const TIAParams &             tia_params,
  const double                  time,
  Linear::Vector *                solnVecPtr,
  const bool                    doNotInterpolate,
  const std::vector<double> &   outputInterpolationTimes,
  bool                          skipPrintLineOutput)
{
  if (DEBUG_TIME && isActive(Diag::TIME_OUTPUT))
  {
    Xyce::dout() << std::endl;
    Xyce::dout() << Xyce::section_divider << std::endl;
    Xyce::dout() << "  BackwardDifferentiation15::printOutputSolution" << std::endl;
    Xyce::dout() << "usedOrder_ = " << sec.usedOrder_ << std::endl;
  }

  double timestep = sec.lastAttemptedTimeStep;
  double lasttime = sec.currentTime - timestep;
  bool dointerp = true;
  double hh = timestep/(sec.usedOrder_);
  if (hh <= 10*sec.minTimeStep)
  {
    dointerp = false;
  }

  if (!tia_params.interpOutputFlag)
  {
    dointerp = false;
  }

  if (doNotInterpolate)
  {
    dointerp = false;
  }

  if (dointerp && !outputInterpolationTimes.empty())
  {
    for (unsigned int i=0;i<outputInterpolationTimes.size();++i)
    {
      interpolateSolution(outputInterpolationTimes[i], ds.tmpSolVectorPtr, ds.xHistory);    // interpolate solution vector
      interpolateSolution(outputInterpolationTimes[i], ds.tmpStaVectorPtr, ds.sHistory);    // interpolate state vector
      interpolateSolution(outputInterpolationTimes[i], ds.tmpStoVectorPtr, ds.stoHistory);  // interpolate store vector
      interpolateSolution(outputInterpolationTimes[i], ds.tmpLeadCurrentVectorPtr, ds.leadCurrentHistory);  // interpolate lead current vector
      interpolateSolution(outputInterpolationTimes[i], ds.tmpLeadDeltaVPtr, ds.leadDeltaVHistory);  // interpolate junction voltage vector
      interpolateSolution(outputInterpolationTimes[i], ds.tmpLeadCurrentQDerivVectorPtr, ds.leadCurrentQDerivHistory);  // interpolate lead current q vector
      outputManagerAdapter.tranOutput(outputInterpolationTimes[i], *ds.tmpSolVectorPtr,
        *ds.tmpStaVectorPtr, *ds.tmpStoVectorPtr, *ds.tmpLeadCurrentVectorPtr, *ds.tmpLeadDeltaVPtr, *ds.tmpLeadCurrentQDerivVectorPtr,
        ds.objectiveVec_, ds.dOdpVec_, ds.dOdpAdjVec_,
        ds.scaled_dOdpVec_, ds.scaled_dOdpAdjVec_,
        skipPrintLineOutput);
    }
  }
  else if ( (sec.usedOrder_ > 2) && dointerp )
  {
    for (int i=1 ; i<sec.usedOrder_; ++i)
    {
      double timept = lasttime + hh*i;
      interpolateSolution(timept,ds.tmpSolVectorPtr, ds.xHistory);    // interpolate solution vector
      interpolateSolution(timept,ds.tmpStaVectorPtr, ds.sHistory);    // interpolate state vector
      interpolateSolution(timept,ds.tmpStoVectorPtr, ds.stoHistory);  // interpolate store vector
      interpolateSolution(timept, ds.tmpLeadCurrentVectorPtr, ds.leadCurrentHistory);  // interpolate lead current vector
      interpolateSolution(timept, ds.tmpLeadDeltaVPtr, ds.leadDeltaVHistory);  // interpolate junction voltage vector
      interpolateSolution(timept, ds.tmpLeadCurrentQDerivVectorPtr, ds.leadCurrentQDerivHistory);  // interpolate lead current q vector
      outputManagerAdapter.tranOutput(timept, *ds.tmpSolVectorPtr,
          *ds.tmpStaVectorPtr, *ds.tmpStoVectorPtr, *ds.tmpLeadCurrentVectorPtr, *ds.tmpLeadDeltaVPtr, *ds.tmpLeadCurrentQDerivVectorPtr,
        ds.objectiveVec_, ds.dOdpVec_, ds.dOdpAdjVec_,
        ds.scaled_dOdpVec_, ds.scaled_dOdpAdjVec_,
        skipPrintLineOutput);

      if (DEBUG_TIME && isActive(Diag::TIME_OUTPUT))
        Xyce::dout() << "Interpolated to t = " << timept << std::endl;
    }
  }

  // Either way, do an output on the actual computed time step, but only
  // if we weren't given a list of specific times *or* we were told not to
  // interpoloate.
  if (outputInterpolationTimes.empty() || doNotInterpolate)
    outputManagerAdapter.tranOutput(time, *ds.currSolutionPtr,
        *ds.currStatePtr, *ds.currStorePtr, *ds.currLeadCurrentPtr, *ds.currLeadDeltaVPtr, *ds.currLeadCurrentQDerivPtr,
        ds.objectiveVec_, ds.dOdpVec_, ds.dOdpAdjVec_,
        ds.scaled_dOdpVec_, ds.scaled_dOdpAdjVec_,
        skipPrintLineOutput);

  if (DEBUG_TIME && isActive(Diag::TIME_OUTPUT))
    Xyce::dout() << Xyce::section_divider << std::endl;

  return true;
}

//-----------------------------------------------------------------------------
// Function      : BackwardDifferentiation15::saveOutputSolution
// Purpose       : This is similar to printOutputSolution, but is in support of
//                 the .SAVE capability, rather than .PRINT.
// Special Notes :
// Scope         : public
// Creator       : Eric Keiter, SNL
// Creation Date : 10/21/07
//-----------------------------------------------------------------------------
bool
BackwardDifferentiation15::saveOutputSolution(
  Parallel::Machine                     comm,
  IO::InitialConditionsManager &        initial_conditions_manager,
  const NodeNameMap &                   node_name_map,
  const TIAParams &                     tia_params,
  Linear::Vector *                      solnVecPtr,
  const double                          saveTime,
  const bool                            doNotInterpolate)
{
  if (DEBUG_TIME && isActive(Diag::TIME_OUTPUT))
  {
    Xyce::dout() << std::endl;
    Xyce::dout() << Xyce::section_divider << std::endl;
    Xyce::dout() << "  BackwardDifferentiation15::saveOutputSolution" << std::endl;
  }

  double timestep = sec.lastAttemptedTimeStep;
  double lasttime = sec.currentTime - timestep;
  bool dointerp = true;
  double hh = timestep/(sec.usedOrder_);
  if (hh <= 10*sec.minTimeStep)
  {
    dointerp = false;
  }

  if (!tia_params.interpOutputFlag)
  {
    dointerp = false;
  }

  if (doNotInterpolate)
  {
    dointerp = false;
  }

  if (dointerp)
  {
    interpolateSolution(saveTime,ds.tmpSolVectorPtr, ds.xHistory);
    // outputManagerAdapter.outputDCOP( *(ds.tmpSolVectorPtr) );
    initial_conditions_manager.outputDCOP(comm, node_name_map, *ds.tmpSolVectorPtr);
  }
  else
  {
    // outputManagerAdapter.outputDCOP( *(solnVecPtr) );
    initial_conditions_manager.outputDCOP(comm, node_name_map, *solnVecPtr);
  }

  if (DEBUG_TIME && isActive(Diag::TIME_OUTPUT))
    Xyce::dout() << Xyce::section_divider << std::endl;

  return true;
}

//-----------------------------------------------------------------------------
// IDA source license:
//-----------------------------------------------------------------------------
// Copyright (c) 2002, The Regents of the University of California.
// Produced at the Lawrence Livermore National Laboratory.
// Written by Alan Hindmarsh, Allan Taylor, Radu Serban.
// UCRL-CODE-2002-59
// All rights reserved.
//
// This file is part of IDA.
//
// Redistribution and use in source and binary forms, with or without
// modification, are permitted provided that the following conditions
// are met:
//
// 1. Redistributions of source code must retain the above copyright
// notice, this list of conditions and the disclaimer below.
//
// 2. Redistributions in binary form must reproduce the above copyright
// notice, this list of conditions and the disclaimer (as noted below)
// in the documentation and/or other materials provided with the
// distribution.
//
// 3. Neither the name of the UC/LLNL nor the names of its contributors
// may be used to endorse or promote products derived from this software
// without specific prior written permission.
//
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
// "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
// LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
// FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
// REGENTS OF THE UNIVERSITY OF CALIFORNIA, THE U.S. DEPARTMENT OF ENERGY
// OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
// SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
// LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
// DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
// THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
// (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
// OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
//
// Additional BSD Notice
// ---------------------
// 1. This notice is required to be provided under our contract with
// the U.S. Department of Energy (DOE). This work was produced at the
// University of California, Lawrence Livermore National Laboratory
// under Contract No. W-7405-ENG-48 with the DOE.
//
// 2. Neither the United States Government nor the University of
// California nor any of their employees, makes any warranty, express
// or implied, or assumes any liability or responsibility for the
// accuracy, completeness, or usefulness of any information, apparatus,
// product, or process disclosed, or represents that its use would not
// infringe privately-owned rights.
//
// 3. Also, reference herein to any specific commercial products,
// process, or services by trade name, trademark, manufacturer or
// otherwise does not necessarily constitute or imply its endorsement,
// recommendation, or favoring by the United States Government or the
// University of California. The views and opinions of authors expressed
// herein do not necessarily state or reflect those of the United States
// Government or the University of California, and shall not be used for
// advertising or product endorsement purposes.
//-----------------------------------------------------------------------------


//-----------------------------------------------------------------------------
// Function      : BackwardDifferentiation15::updateHistory
// Purpose       : Update history array after a successful step
// Special Notes :
// Scope         : public
// Creator       : Todd Coffey, SNL
// Creation Date : 03/08/04
//-----------------------------------------------------------------------------
void BackwardDifferentiation15::updateHistory()
{

  if (DEBUG_TIME && isActive(Diag::TIME_HISTORY))
  {
    Xyce::dout() << std::endl;
    Xyce::dout() << Xyce::section_divider << std::endl;
    Xyce::dout() <<
                           "  BackwardDifferentiation15::updateHistory" << std::endl;
    Xyce::dout() << "\n Before updates \n" << std::endl;
    for (int i=0; i<=sec.maxOrder_ ; ++i)
    {
      Xyce::dout() << "\n xHistory["<< i << "]: \n" << std::endl;
      (ds.xHistory[i])->printPetraObject(Xyce::dout());
      Xyce::dout() << std::endl;
    }
    for (int i=0; i<=sec.maxOrder_ ; ++i)
    {
      Xyce::dout() << "\n qHistory["<< i << "]: \n" << std::endl;
      (ds.qHistory[i])->printPetraObject(Xyce::dout());
      Xyce::dout() << std::endl;
    }
    for (int i=0; i<=sec.maxOrder_ ; ++i)
    {
      Xyce::dout() << "\n sHistory["<< i << "]: \n" << std::endl;
      (ds.sHistory[i])->printPetraObject(Xyce::dout());
      Xyce::dout() << std::endl;
    }
    Xyce::dout() << Xyce::section_divider << std::endl;
  }

  // Save Newton correction for potential order increase on next step.
  if (sec.usedOrder_ < sec.maxOrder_)
  {
    *(ds.xHistory[sec.usedOrder_+1]) = *ds.newtonCorrectionPtr;
    *(ds.qHistory[sec.usedOrder_+1]) = *ds.qNewtonCorrectionPtr;
  }
  (ds.xHistory[sec.usedOrder_])->addVec(1.0,*ds.newtonCorrectionPtr);
  (ds.qHistory[sec.usedOrder_])->addVec(1.0,*ds.qNewtonCorrectionPtr);
  for (int j=sec.usedOrder_-1;j>=0;j--)
  {
    (ds.xHistory[j])->addVec(1.0,*(ds.xHistory[j+1]));
    (ds.qHistory[j])->addVec(1.0,*(ds.qHistory[j+1]));
  }

  if (sec.usedOrder_ < sec.maxOrder_)
  {
    *(ds.sHistory[sec.usedOrder_+1]) = *sNewtonCorrectionPtr;
  }
  (ds.sHistory[sec.usedOrder_])->addVec(1.0,*sNewtonCorrectionPtr);
  for (int j=sec.usedOrder_-1;j>=0;j--)
  {
    (ds.sHistory[j])->addVec(1.0,*(ds.sHistory[j+1]));
  }

  // Update Store History
  if (sec.usedOrder_ < sec.maxOrder_)
  {
    *(ds.stoHistory[sec.usedOrder_+1]) = *stoNewtonCorrectionPtr;
  }
  (ds.stoHistory[sec.usedOrder_])->addVec(1.0,*stoNewtonCorrectionPtr);
  for (int j=sec.usedOrder_-1;j>=0;j--)
  {
    (ds.stoHistory[j])->addVec(1.0,*(ds.stoHistory[j+1]));
  }

  // Update lead currenti and junction voltage History
  if (sec.usedOrder_ < sec.maxOrder_)
  {
    *(ds.leadCurrentHistory[sec.usedOrder_+1]) = *leadCurrentNewtonCorrectionPtr;
    *(ds.leadCurrentQHistory[sec.usedOrder_+1]) = *leadCurrentQNewtonCorrectionPtr;
    *(ds.leadDeltaVHistory[sec.usedOrder_+1]) = *leadDeltaVNewtonCorrectionPtr;
    *(ds.leadCurrentQDerivHistory[sec.usedOrder_+1]) = *leadCurrentQDerivNewtonCorrectionPtr;
  }
  (ds.leadCurrentHistory[sec.usedOrder_])->addVec(1.0,*leadCurrentNewtonCorrectionPtr);
  (ds.leadCurrentQHistory[sec.usedOrder_])->addVec(1.0,*leadCurrentQNewtonCorrectionPtr);
  (ds.leadDeltaVHistory[sec.usedOrder_])->addVec(1.0,*leadDeltaVNewtonCorrectionPtr);
  (ds.leadCurrentQDerivHistory[sec.usedOrder_])->addVec(1.0,*leadCurrentQDerivNewtonCorrectionPtr);


  for (int j=sec.usedOrder_-1;j>=0;j--)
  {
    (ds.leadCurrentHistory[j])->addVec(1.0,*(ds.leadCurrentHistory[j+1]));
    (ds.leadCurrentQHistory[j])->addVec(1.0,*(ds.leadCurrentQHistory[j+1]));
    (ds.leadDeltaVHistory[j])->addVec(1.0,*(ds.leadDeltaVHistory[j+1]));
    (ds.leadCurrentQDerivHistory[j])->addVec(1.0,*(ds.leadCurrentQDerivHistory[j+1]));
  }

  if (DEBUG_TIME && isActive(Diag::TIME_HISTORY))
  {
    Xyce::dout() << "\n After updates \n" << std::endl;
    Xyce::dout() << "\n newtonCorrectionPtr: " << std::endl;
    ds.newtonCorrectionPtr->printPetraObject(Xyce::dout());
    Xyce::dout() << "\n qnewtonCorrectionPtr: " << std::endl;
    ds.qNewtonCorrectionPtr->printPetraObject(Xyce::dout());
    for (int i=0; i<=sec.maxOrder_ ; ++i)
    {
      Xyce::dout() << "\n xHistory["<< i << "]: \n" << std::endl;
      (ds.xHistory[i])->printPetraObject(Xyce::dout());
      Xyce::dout() << std::endl;
    }
    for (int i=0; i<=sec.maxOrder_ ; ++i)
    {
      Xyce::dout() << "\n qHistory["<< i << "]: \n" << std::endl;
      (ds.qHistory[i])->printPetraObject(Xyce::dout());
      Xyce::dout() << std::endl;
    }
    Xyce::dout() << "\n sNewtonCorrectionPtr: " << std::endl;
    sNewtonCorrectionPtr->printPetraObject(Xyce::dout());
    Xyce::dout() << std::endl;
    Xyce::dout() << "\n nextStatePtr: " << std::endl;
    ds.nextStatePtr->printPetraObject(Xyce::dout());
    Xyce::dout() << std::endl;
    for (int i=0; i<=sec.maxOrder_ ; ++i)
    {
      Xyce::dout() << "\n sHistory["<< i << "]: \n" << std::endl;
      (ds.sHistory[i])->printPetraObject(Xyce::dout());
      Xyce::dout() << std::endl;
    }
    Xyce::dout() << Xyce::section_divider << std::endl;
  }
}

//-----------------------------------------------------------------------------
// Function      : BackwardDifferentiation15::restoreHistory
// Purpose       : Restore history array after a failed step
// Special Notes :
// Scope         : public
// Creator       : Todd Coffey, SNL
// Creation Date : 03/08/04
//-----------------------------------------------------------------------------
void BackwardDifferentiation15::restoreHistory()
{
  // undo preparation of history array for prediction
  for (int i=sec.nscsco_;i<=sec.currentOrder_;++i)
  {
    (ds.xHistory[i])->scale(1/sec.beta_[i]);
    (ds.qHistory[i])->scale(1/sec.beta_[i]);
    (ds.sHistory[i])->scale(1/sec.beta_[i]);
    (ds.stoHistory[i])->scale(1/sec.beta_[i]);
    (ds.leadCurrentHistory[i])->scale(1/sec.beta_[i]);
    (ds.leadDeltaVHistory[i])->scale(1/sec.beta_[i]);
  }
  for (int i=1;i<=sec.currentOrder_;++i)
  {
    sec.psi_[i-1] = sec.psi_[i] - (sec.currentTimeStep);
  }
  if (DEBUG_TIME && isActive(Diag::TIME_HISTORY))
  {
    Xyce::dout() << std::endl;
    Xyce::dout() << Xyce::section_divider << std::endl;
    Xyce::dout() <<
                           "  BackwardDifferentiation15::restoreHistory" << std::endl;
    for (int i=1;i<=sec.currentOrder_;++i)
      Xyce::dout() << "\n sec.psi_[i] = " << sec.psi_[i] << std::endl;
    for (int i=0; i<=sec.maxOrder_ ; ++i)
    {
      Xyce::dout() << "\n xHistory["<< i << "]: \n" << std::endl;
      (ds.xHistory[i])->printPetraObject(Xyce::dout());
      Xyce::dout() << std::endl;
    }
    for (int i=0; i<=sec.maxOrder_ ; ++i)
    {
      Xyce::dout() << "\n qHistory["<< i << "]: \n" << std::endl;
      (ds.qHistory[i])->printPetraObject(Xyce::dout());
      Xyce::dout() << std::endl;
    }
    for (int i=0; i<=sec.maxOrder_ ; ++i)
    {
      Xyce::dout() << "\n sHistory["<< i << "]: \n" << std::endl;
      (ds.sHistory[i])->printPetraObject(Xyce::dout());
      Xyce::dout() << std::endl;
    }
    Xyce::dout() << Xyce::section_divider << std::endl;
  }
}

//-----------------------------------------------------------------------------
// Function      : BackwardDifferentiation15::updateCoeffs
// Purpose       : Update method coefficients
// Special Notes :
// Scope         : public
// Creator       : Todd Coffey, SNL
// Creation Date : 03/08/04
//-----------------------------------------------------------------------------
void BackwardDifferentiation15::updateCoeffs()
{
  // synchronize with Step Error Control
//  sec.psi_[0] = sec.currentTimeStep;
  if (DEBUG_TIME && isActive(Diag::TIME_COEFFICIENTS))
  {
    Xyce::dout() << std::endl;
    Xyce::dout() << Xyce::section_divider << std::endl;
    Xyce::dout() << "  BackwardDifferentiation15::updateCoeffs" << std::endl;
    Xyce::dout() << "  currentTimeStep = " <<  sec.currentTimeStep << std::endl;
    Xyce::dout() << "  numberOfSteps_ = " <<  sec.numberOfSteps_ << std::endl;
    Xyce::dout() << "  currentOrder_ = " <<  sec.currentOrder_ << std::endl;
    Xyce::dout() << "  nscsco_ = " <<  sec.nscsco_ << std::endl;
    Xyce::dout() << "  psi_[0] = " <<  sec.psi_[0] << std::endl;
  }

  // If the number of steps taken with constant order and constant stepsize is
  // more than the current order + 1 then we don't bother to update the
  // coefficients because we've reached a constant step-size formula.  When
  // this is is not true, then we update the coefficients for the variable
  // step-sizes.
  if ((sec.currentTimeStep != sec.usedStep_) || (sec.currentOrder_ != sec.usedOrder_))
    sec.nscsco_ = 0;
  sec.nscsco_ = std::min(sec.nscsco_+1,sec.usedOrder_+2);
  if (sec.currentOrder_+1 >= sec.nscsco_)
  {
    sec.beta_[0] = 1.0;
    sec.alpha_[0] = 1.0;
    double temp1 = sec.currentTimeStep;
    sec.sigma_[0] = 1.0;
    sec.gamma_[0] = 0.0;
    for (int i=1;i<=sec.currentOrder_;++i)
    {
      double temp2 = sec.psi_[i-1];
      sec.psi_[i-1] = temp1;
      sec.beta_[i] = sec.beta_[i-1]*sec.psi_[i-1]/temp2;
      temp1 = temp2 + sec.currentTimeStep;
      sec.alpha_[i] = (sec.currentTimeStep)/temp1;
      sec.sigma_[i] = (i+1)*sec.sigma_[i-1]*sec.alpha_[i];
      sec.gamma_[i] = sec.gamma_[i-1]+sec.alpha_[i-1]/(sec.currentTimeStep);
    }
    sec.psi_[sec.currentOrder_] = temp1;
    sec.alphas_ = 0.0;
    sec.alpha0_ = 0.0;
    for (int i=0;i<sec.currentOrder_;++i)
    {
      sec.alphas_ = sec.alphas_ - 1.0/(i+1.0);
      sec.alpha0_ = sec.alpha0_ - sec.alpha_[i];
    }
    sec.cj_ = -sec.alphas_/(sec.currentTimeStep);
    sec.ck_ = std::abs(sec.alpha_[sec.currentOrder_]+sec.alphas_-sec.alpha0_);
    sec.ck_ = std::max(sec.ck_,sec.alpha_[sec.currentOrder_]);
  }
  if (DEBUG_TIME && isActive(Diag::TIME_COEFFICIENTS))
  {
    Xyce::dout() << "  nscsco_ = " <<  sec.nscsco_ << std::endl;
    Xyce::dout() << "  beta_[0] = " <<  sec.beta_[0] << std::endl;
    Xyce::dout() << "  beta_[1] = " <<  sec.beta_[1] << std::endl;
    Xyce::dout() << "  beta_[2] = " <<  sec.beta_[2] << std::endl;
    Xyce::dout() << "  beta_[3] = " <<  sec.beta_[3] << std::endl;
    Xyce::dout() << "  beta_[4] = " <<  sec.beta_[4] << std::endl;
    Xyce::dout() << "  alpha_[0] = " <<  sec.alpha_[0] << std::endl;
    Xyce::dout() << "  alpha_[1] = " <<  sec.alpha_[1] << std::endl;
    Xyce::dout() << "  alpha_[2] = " <<  sec.alpha_[2] << std::endl;
    Xyce::dout() << "  alpha_[3] = " <<  sec.alpha_[3] << std::endl;
    Xyce::dout() << "  alpha_[4] = " <<  sec.alpha_[4] << std::endl;
    Xyce::dout() << "  alphas_ = " <<  sec.alphas_ << std::endl;
    Xyce::dout() << "  alpha0_ = " <<  sec.alpha0_ << std::endl;
    Xyce::dout() << "  gamma_[0] = " <<  sec.gamma_[0] << std::endl;
    Xyce::dout() << "  gamma_[1] = " <<  sec.gamma_[1] << std::endl;
    Xyce::dout() << "  gamma_[2] = " <<  sec.gamma_[2] << std::endl;
    Xyce::dout() << "  gamma_[3] = " <<  sec.gamma_[3] << std::endl;
    Xyce::dout() << "  gamma_[4] = " <<  sec.gamma_[4] << std::endl;
    Xyce::dout() << "  psi_[0] = " <<  sec.psi_[0] << std::endl;
    Xyce::dout() << "  psi_[1] = " <<  sec.psi_[1] << std::endl;
    Xyce::dout() << "  psi_[2] = " <<  sec.psi_[2] << std::endl;
    Xyce::dout() << "  psi_[3] = " <<  sec.psi_[3] << std::endl;
    Xyce::dout() << "  psi_[4] = " <<  sec.psi_[4] << std::endl;
    Xyce::dout() << "  sigma_[0] = " <<  sec.sigma_[0] << std::endl;
    Xyce::dout() << "  sigma_[1] = " <<  sec.sigma_[1] << std::endl;
    Xyce::dout() << "  sigma_[2] = " <<  sec.sigma_[2] << std::endl;
    Xyce::dout() << "  sigma_[3] = " <<  sec.sigma_[3] << std::endl;
    Xyce::dout() << "  sigma_[4] = " <<  sec.sigma_[4] << std::endl;
    Xyce::dout() << "  ck_ = " <<  sec.ck_ << std::endl;
    Xyce::dout() << Xyce::section_divider << std::endl;
  }
}

//-----------------------------------------------------------------------------
// Function      : BackwardDifferentiation15::initialize
// Purpose       : Initialize method with initial solution & step-size
// Special Notes :
// Scope         : public
// Creator       : Todd Coffey, SNL
// Creation Date : 3/09/04
//-----------------------------------------------------------------------------
void BackwardDifferentiation15::initialize(const TIAParams & tia_params)
{
  // we assume the solution vector is available here
  // Note that I'm using currSolutionPtr instead of
  // nextSolutionPtr because this is the first step.

  // Update next stop time from StepErrorControl:
  // ERK.  Commenting this out, as it is already called from Analysis::AnalysisManager,
  // right before this initialize call.  It should not be called 2x, as
  // it is history dependent (unfortunately), so calling it 2x in a row changes
  // the stop time to a different number.
  // sec.updateStopTime();

  // Choose initial step-size
  double time_to_stop = sec.stopTime - sec.currentTime;
  double currentTimeStep;
  if (tia_params.constantTimeStepFlag)
  {
    currentTimeStep = 0.1 * time_to_stop;
    currentTimeStep = std::min(sec.startingTimeStep, currentTimeStep);
    sec.currentTimeStep = currentTimeStep;
  }
  else
  {
    // compute an initial step-size based on rate of change in the
    // solution initially
    double dnorm_q = ds.delta_x_errorNorm_q1();
    if (dnorm_q > 0.0)  // time-dependent DAE
    {
      currentTimeStep = std::min(sec.h0_max_factor_*std::abs(time_to_stop),sqrt(2.0)/(sec.h0_safety_*dnorm_q));
    }
    else  // non-time-dependent DAE
    {
      currentTimeStep = sec.h0_max_factor_*std::abs(time_to_stop);
    }
    // choose min of user specified value and our value:
    if (sec.startingTimeStep > 0.0)
      currentTimeStep = std::min(sec.startingTimeStep, currentTimeStep);
    // check for maximum step-size:
    double rh = std::abs(currentTimeStep)*sec.h_max_inv_;
    if (rh>1.0) currentTimeStep = currentTimeStep/rh;


    // Apply this new stepsize only if it is smaller than the one preceding
    // the breakpoint, but only do this if this is a non-DCOP breakpoint.
    if (sec.currentTime != sec.initialTime) // if not DCOP:
    {
      sec.currentTimeStep = std::min(sec.lastTimeStep, currentTimeStep);
    }
    else // else if DCOP:
    {
      sec.currentTimeStep = currentTimeStep;
      sec.initialPhase_ = true;     
    }
  }

  sec.currentTimeStepRatio = 1.0;
  sec.currentTimeStepSum   = 2.0*sec.currentTimeStep;

  sec.lastTimeStep      = sec.currentTimeStep;
  sec.lastTimeStepRatio = sec.currentTimeStepRatio;
  sec.lastTimeStepSum   = sec.currentTimeStepSum;

  sec.numberSuccessiveFailures = 0;
  sec.stepAttemptStatus        = true;

//  sec.tolAimFac_ = 0.5;

  sec.nextTime = sec.currentTime + sec.currentTimeStep;

  // x history
  *(ds.xHistory[0]) = *(ds.currSolutionPtr);
  (ds.xHistory[1])->putScalar(0.0); // no need to multiply by dt here

  // q history
  *(ds.qHistory[0]) = *(ds.daeQVectorPtr);
  *(ds.qHistory[1]) = *(ds.daeFVectorPtr);
  (ds.qHistory[1])->scale(-sec.currentTimeStep);

  // state history
  *(ds.sHistory[0]) = *(ds.currStatePtr);
  (ds.sHistory[1])->putScalar(0.0);

  // store history
  *(ds.stoHistory[0]) = *(ds.currStorePtr);
  (ds.stoHistory[1])->putScalar(0.0);

  // lead current and junction voltage history
  *(ds.leadCurrentHistory[0]) = *(ds.currLeadCurrentPtr);
  (ds.leadCurrentHistory[1])->putScalar(0.0);

   *(ds.leadCurrentQHistory[0]) = *(ds.currLeadCurrentQPtr);
  (ds.leadCurrentQHistory[1])->putScalar(0.0);

  *(ds.leadDeltaVHistory[0]) = *(ds.currLeadDeltaVPtr);
  (ds.leadDeltaVHistory[1])->putScalar(0.0);

  // Coefficient initialization
  sec.numberOfSteps_ = 0;    // number of total time integration steps taken
  sec.currentOrder_ = 1;
  sec.usedOrder_ = 1;
  sec.psi_[0] = sec.currentTimeStep;
  sec.cj_ = 1/sec.psi_[0];
  sec.nscsco_ = 0;
  if (DEBUG_TIME &&isActive(Diag::TIME_HISTORY))
  {
    Xyce::dout() << std::endl;
    Xyce::dout() << Xyce::section_divider << std::endl;
    Xyce::dout() << "  BackwardDifferentiation15::initialize" << std::endl;
    Xyce::dout() << "\n xHistory: \n" << std::endl;
    (ds.xHistory[0])->printPetraObject(Xyce::dout());
    Xyce::dout() << std::endl;
    (ds.xHistory[1])->printPetraObject(Xyce::dout());
    Xyce::dout() << std::endl;
    Xyce::dout() << "\n qHistory: \n" << std::endl;
    (ds.qHistory[0])->printPetraObject(Xyce::dout());  // lead current and junction voltage history
    Xyce::dout() << std::endl;
    (ds.qHistory[1])->printPetraObject(Xyce::dout());
    Xyce::dout() << std::endl;
    Xyce::dout() << "\n sHistory: \n" << std::endl;
    (ds.sHistory[0])->printPetraObject(Xyce::dout());
    Xyce::dout() << std::endl;
    (ds.sHistory[1])->printPetraObject(Xyce::dout());
    Xyce::dout() << std::endl;
    Xyce::dout() << "\n" << "currentTimeStep = " << currentTimeStep << "\n" << std::endl;
    Xyce::dout() << "\n" << "time_to_stop = " << time_to_stop << "\n" << std::endl;
    Xyce::dout() << Xyce::section_divider << std::endl;
  }
}


//-----------------------------------------------------------------------------
// Function      : BackwardDifferentiation15::initializeAdjoint
// Purpose       : Initialize method for adjoint sensitivities
// Special Notes :
// Scope         : public
// Creator       : Eric Keiter, SNL
// Creation Date : 2/28/2016
//-----------------------------------------------------------------------------
void BackwardDifferentiation15::initializeAdjoint (int index)
{

}

//-----------------------------------------------------------------------------
// Function      : BackwardDifferentiation15::setTwoLevelTimeInfo
// Purpose       :
// Special Notes :
// Scope         : public
// Creator       : Eric Keiter, SNL
// Creation Date : 03/01/07
//-----------------------------------------------------------------------------
void
BackwardDifferentiation15::setTwoLevelTimeInfo()
{
  // set initial step-size
  double time_to_stop = sec.stopTime - sec.currentTime;

  // x history
  *ds.xHistory[0] = *ds.currSolutionPtr;
  ds.xHistory[1]->putScalar(0.0); // no need to multiply by dt here

  // q history
  *ds.qHistory[0] = *ds.daeQVectorPtr;
  *ds.qHistory[1] = *ds.daeFVectorPtr;
  ds.qHistory[1]->scale(-sec.currentTimeStep);

  // state history
  *ds.sHistory[0] = *ds.nextStatePtr;
  ds.sHistory[1]->putScalar(0.0);

  // store history
  *ds.stoHistory[0] = *ds.nextStatePtr;
  ds.stoHistory[1]->putScalar(0.0);

  // lead current and junction voltage history
  *ds.leadCurrentHistory[0] = *ds.currLeadCurrentPtr;
  ds.leadCurrentHistory[1]->putScalar(0.0);

   *ds.leadCurrentQHistory[0] = *ds.currLeadCurrentQPtr;
  ds.leadCurrentQHistory[1]->putScalar(0.0);

  *ds.leadDeltaVHistory[0] = *ds.currLeadDeltaVPtr;
  ds.leadDeltaVHistory[1]->putScalar(0.0);

  // Coefficient initialization
  sec.numberOfSteps_ = 0;    // number of total time integration steps taken
  sec.usedOrder_ = 1;
  sec.psi_[0] = sec.currentTimeStep;
  sec.cj_ = 1/sec.psi_[0];
  sec.nscsco_ = 0;
}


//-----------------------------------------------------------------------------
// Function      : BackwardDifferentiation15::checkReduceOrder()
// Purpose       : check whether to reduce order independent of local error test
// Special Notes :
// Scope         : public
// Creator       : Todd Coffey, SNL
// Creation Date : 06/08/04
//-----------------------------------------------------------------------------
void BackwardDifferentiation15::checkReduceOrder()
{

// This routine puts its output in sec.newOrder_

// This routine changes the following variables:
//    sec.Ek_, sec.Tk_, sec.Est_, sec.newOrder_, ds.delta_x, 
//    sec.Ekm1_, sec.Tkm1_, sec.Ekm2_, sec.Tkm2_

// This routine reads but does not change the following variables:
//    sec.currentOrder_, sec.sigma_, ds.newtonCorrectionPtr, ds.qNewtonCorrectionPtr,
//    ds.errWtVecPtr, ds.qErrWtVecPtr, ds.xHistory, ds.qHistory

  if (DEBUG_TIME && isActive(Diag::TIME_STEP))
  {
    Xyce::dout() << std::endl;
    Xyce::dout() << Xyce::section_divider << std::endl;
    Xyce::dout() << "  BackwardDifferentiation15::checkReduceOrder" << std::endl;
  }

  // 03/11/04 tscoffe:  I only want to run this block after a step has been
  // attempted, but I want to do this regardless of the status from the local
  // error test.
  // 03/10/04 tscoffe:  Decide whether to reduce the order before considering
  // the local error test result.
  double dnorm_x = sec.estOverTol_;
  double dnorm = dnorm_x;

  sec.Ek_ = sec.sigma_[sec.currentOrder_]*dnorm;
  sec.Tk_ = (sec.currentOrder_+1)*sec.Ek_;
  sec.Est_ = sec.Ek_;
  sec.newOrder_ = sec.currentOrder_;
  if (DEBUG_TIME && isActive(Diag::TIME_STEP))
  {
    Xyce::dout() << "  Est_= " <<  sec.Est_ << std::endl;
    Xyce::dout() << "  Ek_= " <<  sec.Ek_ << std::endl;
    Xyce::dout() << "  dnorm = " <<  dnorm  << std::endl;
    Xyce::dout() << "  sigma[order] = " << sec.sigma_[sec.currentOrder_]  << std::endl;
    Xyce::dout() << "  Tk_= " <<  sec.Tk_ << std::endl;
  }

  if (sec.currentOrder_>1)
  {
    ds.delta_x->linearCombo(1.0,*(ds.xHistory[sec.currentOrder_]),1.0,*ds.newtonCorrectionPtr);
    dnorm_x = sec.ck_ * ds.delta_x_errorNorm_m1();
    dnorm = dnorm_x;

    sec.Ekm1_ = sec.sigma_[sec.currentOrder_-1]*dnorm;
    sec.Tkm1_ = sec.currentOrder_*sec.Ekm1_;
    if (DEBUG_TIME && isActive(Diag::TIME_STEP))
    {
      Xyce::dout() << "  Ekm1_= " <<  sec.Ekm1_ << std::endl;
      Xyce::dout() << "  Tkm1_= " <<  sec.Tkm1_ << std::endl;
    }

    if (sec.currentOrder_>2)
    {
      ds.delta_x->linearCombo(1.0,*(ds.xHistory[sec.currentOrder_-1]),1.0,*ds.delta_x);
      dnorm_x = sec.ck_ * ds.delta_x_errorNorm_m2();
      dnorm = dnorm_x;

      sec.Ekm2_ = sec.sigma_[sec.currentOrder_-2]*dnorm;
      sec.Tkm2_ = (sec.currentOrder_-1)*sec.Ekm2_;
      if (std::max(sec.Tkm1_,sec.Tkm2_)<=sec.Tk_)
      {
        sec.newOrder_--;
        sec.Est_ = sec.Ekm1_;
      }
    }
    else if (sec.Tkm1_ <= sec.Tkm1_Tk_safety_ * sec.Tk_)
    {
      if (DEBUG_TIME && isActive(Diag::TIME_STEP))
      {
        Xyce::dout() << "  Tkm1_Tk_safety= " <<  sec.Tkm1_Tk_safety_ << std::endl;
        Xyce::dout() << "  Tkm1_= " <<  sec.Tkm1_ << std::endl;
        Xyce::dout() << "  Tk_= " <<  sec.Tk_ << std::endl;
        Xyce::dout() << "  Tk_*safety= " <<  sec.Tk_*sec.Tkm1_Tk_safety_ << std::endl;
      }

      sec.newOrder_--;
      sec.Est_ = sec.Ekm1_;
    }
  }
  if (DEBUG_TIME && isActive(Diag::TIME_STEP))
  {
    Xyce::dout() << "  newOrder = " <<  sec.newOrder_ << std::endl;
    Xyce::dout() << Xyce::section_divider << std::endl;
  }
}

//-----------------------------------------------------------------------------
// Function      : BackwardDifferentiation15::rejectStep()
// Purpose       : code to restore history, choose new order/step-size
// Special Notes :
// Scope         : public
// Creator       : Todd Coffey, SNL
// Creation Date : 06/07/04
//-----------------------------------------------------------------------------
void
BackwardDifferentiation15::rejectStep(
  const TIAParams &     tia_params)
{
// This routine puts its output in newTimeStep_ and sec.newOrder_

// This routine changes the following variables:
//    lastAttemptedTimeStep, sec.initialPhase_, sec.nef_, sec.psi_, newTimeStep_,
//    sec.newOrder_, sec.currentOrder_, currentTimeStep_, ds.xHistory,
//    ds.qHistory, nextTimePt, nextTime, currentTimeStepRatio,
//    currentTimeStepSum, nextTimePt

// This routine reades but does not change the following variables:
//    stepAttemptStatus, sec.r_factor_, sec.r_safety_, sec.Est_, sec.r_fudge_, sec.r_min_, sec.r_max_,
//    minTimeStep, maxTimeStep, currentTime, stopTime, lastTimeStep

  // First we decide if we'll reduce the order independent of the local error test:
  checkReduceOrder();

  if (DEBUG_TIME && isActive(Diag::TIME_STEP))
  {
    Xyce::dout() << std::endl;
    Xyce::dout() << Xyce::section_divider << std::endl;
    Xyce::dout() << "  BackwardDifferentiation15::rejectStep" << std::endl;
  }

  // Only update the time step if we are NOT running constant stepsize.
  bool adjustStep = !tia_params.constantTimeStepFlag;

  sec.lastAttemptedTimeStep = sec.currentTimeStep;

  double newTimeStep_ = sec.currentTimeStep;
  double rr = 1.0; // step size ratio = new step / old step
  if ((sec.stepAttemptStatus == false) && (adjustStep))
  {
    sec.initialPhase_ = false;
    sec.nef_++;
    restoreHistory();

    if ((sec.newtonConvergenceStatus <= 0))
    {
      /// 11/11/05 erkeite:  If the Newton solver fails, don't
      // rely on the error estimate - it may be full of Nan's.
      rr = sec.r_min_;
      newTimeStep_ = rr * sec.currentTimeStep;

      if (sec.nef_ > 2) sec.newOrder_ = 1;//consistent with block below.
      if (DEBUG_TIME && isActive(Diag::TIME_STEP))
        Xyce::dout() << "rejectStep 1" << std::endl;
    }
    else
    {
      // 03/11/04 tscoffe:  Here is the block for choosing order &
      // step-size when the local error test FAILS (but Newton
      // succeeded).
      if (sec.nef_ == 1) // first local error test failure
      {
        rr = sec.r_factor_*pow(sec.r_safety_*(sec.Est_+sec.r_fudge_),-1.0/(sec.newOrder_+1.0));
        rr = std::max(sec.r_min_,std::min(sec.r_max_,rr));

        newTimeStep_ = rr * sec.currentTimeStep;
        if (DEBUG_TIME && isActive(Diag::TIME_STEP))
          Xyce::dout() << "rejectStep 2" << std::endl;
      }
      else if (sec.nef_ == 2) // second Dae failure
      {
        rr = sec.r_min_;
        newTimeStep_ = rr * sec.currentTimeStep;
        if (DEBUG_TIME && isActive(Diag::TIME_STEP))
          Xyce::dout() << "rejectStep 3" << std::endl;
      }
      else if (sec.nef_ > 2) // third and later failures
      {
        sec.newOrder_ = 1;
        rr = sec.r_min_;
        newTimeStep_ = rr * sec.currentTimeStep;
        if (DEBUG_TIME && isActive(Diag::TIME_STEP))
          Xyce::dout() << "rejectStep 4" << std::endl;
      }
    }
    if (sec.newOrder_ >= sec.minOrder_)
    {
      sec.currentOrder_ = sec.newOrder_;
      if (DEBUG_TIME && isActive(Diag::TIME_STEP))
        Xyce::dout() << "rejectStep 5" << std::endl;
    }
    if (sec.numberOfSteps_ == 0) // still first step
    {
      sec.psi_[0] = newTimeStep_;
      (ds.xHistory[1])->scale(rr);
      (ds.qHistory[1])->scale(rr);
      if (DEBUG_TIME && isActive(Diag::TIME_STEP))
        Xyce::dout() << "rejectStep 6" << std::endl;
    }
    if (DEBUG_TIME && isActive(Diag::TIME_STEP) && isActive(Diag::TIME_COEFFICIENTS))
    {
      Xyce::dout() << "  currentTimeStep = " <<  sec.currentTimeStep << std::endl;
      Xyce::dout() << "  numberOfSteps_ = " <<  sec.numberOfSteps_ << std::endl;
      Xyce::dout() << "  currentOrder_ = " <<  sec.currentOrder_ << std::endl;
      Xyce::dout() << "  nscsco_ = " <<  sec.nscsco_ << std::endl;
      Xyce::dout() << "  alpha_[0] = " <<  sec.alpha_[0] << std::endl;
      Xyce::dout() << "  alpha_[1] = " <<  sec.alpha_[1] << std::endl;
      Xyce::dout() << "  alpha_[2] = " <<  sec.alpha_[2] << std::endl;
      Xyce::dout() << "  alpha_[3] = " <<  sec.alpha_[3] << std::endl;
      Xyce::dout() << "  alpha_[4] = " <<  sec.alpha_[4] << std::endl;
      Xyce::dout() << "  psi_[0] = " <<  sec.psi_[0] << std::endl;
      Xyce::dout() << "  psi_[1] = " <<  sec.psi_[1] << std::endl;
      Xyce::dout() << "  psi_[2] = " <<  sec.psi_[2] << std::endl;
      Xyce::dout() << "  psi_[3] = " <<  sec.psi_[3] << std::endl;
      Xyce::dout() << "  psi_[4] = " <<  sec.psi_[4] << std::endl;
      Xyce::dout() << "  sigma_[0] = " <<  sec.sigma_[0] << std::endl;
      Xyce::dout() << "  sigma_[1] = " <<  sec.sigma_[1] << std::endl;
      Xyce::dout() << "  sigma_[2] = " <<  sec.sigma_[2] << std::endl;
      Xyce::dout() << "  sigma_[3] = " <<  sec.sigma_[3] << std::endl;
      Xyce::dout() << "  sigma_[4] = " <<  sec.sigma_[4] << std::endl;
      Xyce::dout() << "  rr = " <<  rr << std::endl;
      Xyce::dout() << "  r_factor_ = " <<  sec.r_factor_ << std::endl;
      Xyce::dout() << "  r_safety_ = " <<  sec.r_safety_ << std::endl;
      Xyce::dout() << "  Est_ = " <<  sec.Est_ << std::endl;
      Xyce::dout() << "  r_fudge_ = " <<  sec.r_fudge_ << std::endl;
      Xyce::dout() << "  newOrder_ = " <<  sec.newOrder_ << std::endl;
      Xyce::dout() << "  currentTimeStep = " <<  sec.currentTimeStep << std::endl;
      Xyce::dout() << "  newTimeStep_ = " <<  newTimeStep_ << std::endl;
    }
  }
  else if ((sec.stepAttemptStatus == false) & (!adjustStep))
  {
    std::string tmp = "  BackwardDifferentiation15:rejectStep: Warning: Local error test failed with constant step-size.\n";
    Xyce::dout() << tmp << std::endl;
  }

  // If the step needs to be adjusted:
  if (adjustStep)
  {
    newTimeStep_ = std::max(newTimeStep_, sec.minTimeStep);
    newTimeStep_ = std::min(newTimeStep_, sec.maxTimeStep);

    double nextTimePt = sec.currentTime + newTimeStep_;

    if (nextTimePt > sec.stopTime)
    {
      nextTimePt  = sec.stopTime;
      newTimeStep_ = sec.stopTime - sec.currentTime;
    }

    sec.nextTime = nextTimePt;

    sec.currentTimeStepRatio = newTimeStep_/sec.lastTimeStep;
    sec.currentTimeStepSum   = newTimeStep_ + sec.lastTimeStep;

    if (DEBUG_TIME && isActive(Diag::TIME_STEP))
    {
      Xyce::dout() << "  newTimeStep_ = " <<  newTimeStep_ << std::endl;
      Xyce::dout() << "  nextTime = " <<  sec.nextTime << std::endl;
    }

    sec.currentTimeStep = newTimeStep_;
  }
  else // if time step is constant for this step:
  {
    double nextTimePt = sec.currentTime + sec.currentTimeStep;

    if (nextTimePt > sec.stopTime)
    {
      nextTimePt      = sec.stopTime;
      sec.currentTimeStep = sec.stopTime - sec.currentTime;
    }

    sec.currentTimeStepRatio = sec.currentTimeStep / sec.lastTimeStep;
    sec.currentTimeStepSum   = sec.currentTimeStep + sec.lastTimeStep;

    sec.nextTime = nextTimePt;
  }
  if (DEBUG_TIME && isActive(Diag::TIME_STEP))
  {
    Xyce::dout() << Xyce::section_divider << std::endl;
  }
}

//-----------------------------------------------------------------------------
// Function      : BackwardDifferentiation15::rejectStepForHabanero
// Purpose       : step rejection, but from an outside program (Habanero API)
// Special Notes :
// Scope         : public
// Creator       : Eric Keiter, SNL
// Creation Date : 08/11/09
//-----------------------------------------------------------------------------
void BackwardDifferentiation15::rejectStepForHabanero()
{
  restoreHistory();
  sec.setTimeStep(sec.currentTimeStep);
}

//-----------------------------------------------------------------------------
// Function      : BackwardDifferentiation15::stepLinearCombo()
// Purpose       : code to update history, choose new order/step-size
// Special Notes :
// Scope         : public
// Creator       : Todd Coffey, SNL
// Creation Date : 06/07/04
//-----------------------------------------------------------------------------
void BackwardDifferentiation15::stepLinearCombo()
{
  ds.stepLinearCombo();

  // We also need a State correction between the time steps
  if (ds.stateSize)
    sNewtonCorrectionPtr->linearCombo (1.0,*ds.nextStatePtr,-1.0,*sn0Ptr);

  // We also need a Store correction between the time steps
  if (ds.storeSize)
  stoNewtonCorrectionPtr->linearCombo (1.0,*ds.nextStorePtr,-1.0,*ston0Ptr);

  // This is for the lead current vector
  if (ds.leadCurrentSize)
  {
    leadCurrentNewtonCorrectionPtr->linearCombo (1.0,*ds.nextLeadCurrentPtr,-1.0,*leadCurrentn0Ptr);
    leadCurrentQNewtonCorrectionPtr->linearCombo (1.0, *ds.nextLeadCurrentQPtr, -1.0, *leadCurrentQn0Ptr );
    leadCurrentQDerivNewtonCorrectionPtr->linearCombo (1.0, *ds.nextLeadCurrentQDerivPtr, -1.0, *(ds.leadCurrentQDerivHistory[0]));
    leadDeltaVNewtonCorrectionPtr->linearCombo (1.0, *ds.nextLeadDeltaVPtr, -1.0, *leadDeltaVn0Ptr );
  }
}

//-----------------------------------------------------------------------------
// Function      : BackwardDifferentiation15::completeStep()
// Purpose       : code to update history, choose new order/step-size
// Special Notes :
// Scope         : public
// Creator       : Todd Coffey, SNL
// Creation Date : 06/07/04
//-----------------------------------------------------------------------------
void BackwardDifferentiation15::completeStep(const TIAParams &tia_params)
{
  enum {TIAAction_UNSET, TIAAction_LOWER, TIAAction_MAINTAIN, TIAAction_RAISE};

  sec.numberOfSteps_ ++;
  sec.nef_ = 0;
  sec.lastTime    = sec.currentTime;
  sec.currentTime = sec.nextTime;
  // First we decide if we'll reduce the order independent of the local error test:
  checkReduceOrder();

  if (DEBUG_TIME && isActive(Diag::TIME_STEP))
  {
    Xyce::dout() << std::endl;
    Xyce::dout() << Xyce::section_divider << std::endl;
    Xyce::dout() << "  BackwardDifferentiation15::completeStep" << std::endl;
  }

  // Only update the time step if we are NOT running constant stepsize.
  bool adjustStep = !tia_params.constantTimeStepFlag;

  sec.lastAttemptedTimeStep = sec.currentTimeStep;

  double newTimeStep_ = sec.currentTimeStep;
  double rr = 1.0; // step size ratio = new step / old step
  // 03/11/04 tscoffe:  Here is the block for choosing order & step-size when
  // the local error test PASSES (and Newton succeeded).
  sec.lastTimeStep = sec.currentTimeStep;
  sec.lastTimeStepRatio = sec.currentTimeStepRatio; // copied from calcTStep1
  sec.lastTimeStepSum   = sec.currentTimeStepSum; // copied from calcTStep1
  int orderDiff = sec.currentOrder_ - sec.usedOrder_;
  sec.usedOrder_ = sec.currentOrder_;
  sec.usedStep_ = sec.currentTimeStep;
  if ((sec.newOrder_ == sec.currentOrder_-1) || (sec.currentOrder_ == sec.maxOrder_))
  {
    // If we reduced our order or reached max order then move to the next phase
    // of integration where we don't automatically double the step-size and
    // increase the order.
    sec.initialPhase_ = false;
  }
  if (sec.initialPhase_)
  {
    sec.currentOrder_++;
    newTimeStep_ = sec.h_phase0_incr_ * sec.currentTimeStep;
  }
  else // not in the initial phase of integration
  {
    int action = TIAAction_UNSET;
    if (sec.newOrder_ == sec.currentOrder_-1)
      action = TIAAction_LOWER;
    else if (sec.newOrder_ == sec.maxOrder_)
      action = TIAAction_MAINTAIN;
    else if ((sec.currentOrder_+1>=sec.nscsco_) || (orderDiff == 1))
    {
      // If we just raised the order last time then we won't raise it again
      // until we've taken sec.currentOrder_+1 steps at order sec.currentOrder_.
      action = TIAAction_MAINTAIN;
    }
    else // consider changing the order
    {
      ds.delta_x->linearCombo(1.0,*ds.newtonCorrectionPtr,-1.0,*(ds.xHistory[sec.currentOrder_+1]));
      double dnorm_x = sec.ck_ * ds.delta_x_errorNorm_p1();
      double dnorm = dnorm_x;

      sec.Tkp1_ = dnorm;
      sec.Ekp1_ = sec.Tkp1_/(sec.currentOrder_+2);
      if (sec.currentOrder_ == 1)
      {
        if (sec.Tkp1_ >= sec.Tkp1_Tk_safety_ * sec.Tk_)
          action = TIAAction_MAINTAIN;
        else
          action = TIAAction_RAISE;
      }
      else
      {
        if (sec.Tkm1_ <= std::min(sec.Tk_,sec.Tkp1_))
          action = TIAAction_LOWER;
        else if (sec.Tkp1_ >= sec.Tk_)
          action = TIAAction_MAINTAIN;
        else
          action = TIAAction_RAISE;
      }
    }
    if (sec.currentOrder_ < sec.minOrder_)
    {
      action = TIAAction_RAISE;
    }
    else if ((sec.currentOrder_ == sec.minOrder_) && (action == TIAAction_LOWER))
    {
      action = TIAAction_MAINTAIN;
    }
    if (action == TIAAction_RAISE)
    {
      sec.currentOrder_++;
      sec.Est_ = sec.Ekp1_;
    }
    else if (action == TIAAction_LOWER)
    {
      sec.currentOrder_--;
      sec.Est_ = sec.Ekm1_;
    }
    newTimeStep_ = sec.currentTimeStep;

    // ERK:  if errorAnalysisOption==NO_LOCAL_TRUNCATED_ESTIMATES, that means that we're not using LTE to determine the
    // new step size.  We're only considering whether or not the Newton solve succeeded.
    // If we are in this function, then it succeeded, as otherwise we'd be in the "rejectStep"
    // function.
    if (tia_params.errorAnalysisOption == TimeIntg::NO_LOCAL_TRUNCATED_ESTIMATES)
    {
      rr = 0.4/(sec.r_min_);
      newTimeStep_ = rr*sec.currentTimeStep;
    }
    else
    {
      rr = pow(sec.r_safety_*(sec.Est_+sec.r_fudge_),-1.0/(sec.currentOrder_+1.0));

      if (DEBUG_TIME && isActive(Diag::TIME_STEP))
      {
        Xyce::dout() << "  currentOrder_ = " <<  sec.currentOrder_ << std::endl;
        Xyce::dout() << "  r_safety = " <<  sec.r_safety_ << std::endl;
        Xyce::dout() << "  r_fudge_ = " <<  sec.r_fudge_ << std::endl;
        Xyce::dout() << "  r_hincr_ = " <<  sec.r_hincr_ << std::endl;
        Xyce::dout() << "  r_hincr_test_ = " <<  sec.r_hincr_test_ << std::endl;
        Xyce::dout() << "  Est = " <<  sec.Est_ << std::endl;
        Xyce::dout() << "  Ekp1_ = " <<  sec.Ekp1_ << std::endl;
        Xyce::dout() << "  Ekm1_ = " <<  sec.Ekm1_ << std::endl;
        Xyce::dout() << "  Tkp1_ = " <<  sec.Tkp1_ << std::endl;
        Xyce::dout() << "  raw rr = " <<  rr << std::endl;
      }

      if (rr >= sec.r_hincr_test_)
      {
        rr = sec.r_hincr_;
        newTimeStep_ = rr*sec.currentTimeStep;
      }
      else if (rr <= 1)
      {
        rr = std::max(sec.r_min_,std::min(sec.r_max_,rr));
        newTimeStep_ = rr*sec.currentTimeStep;
      }
    }
  }
  if (DEBUG_TIME && isActive(Diag::TIME_STEP))
  {
    Xyce::dout() << "  initialPhase_ = " <<  sec.initialPhase_ << std::endl;
    Xyce::dout() << "  rr = " <<  rr << std::endl;
    Xyce::dout() << "  currentTimeStep = " <<  sec.currentTimeStep << std::endl;
    Xyce::dout() << "  currentTime = " <<  sec.currentTime << std::endl;
    Xyce::dout() << "  nextTime = " <<  sec.nextTime << std::endl;
    Xyce::dout() << "  newTimeStep_ = " <<  newTimeStep_ << std::endl;
    Xyce::dout() << "  minTimeStep = " <<  sec.minTimeStep << std::endl;
    Xyce::dout() << "  maxTimeStep = " <<  sec.maxTimeStep << std::endl;
  }

  // 03/22/04 tscoffe:  Note that updating the history has nothing to do with
  // the step-size and everything to do with the newton correction vectors.
  updateHistory();


  // 12/01/05 tscoffe:  This is necessary to avoid currentTimeStep == 0 right
  // before a breakpoint.  So I'm checking to see if currentTime is identically
  // equal to stopTime, in which case we are right before a breakpoint and we
  // should not adjust currentStepSize because that would result in
  // currentStepSize == 0.
  if (sec.currentTime < sec.stopTime)
  {
    // If the step needs to be adjusted:
    if (adjustStep)
    {
      newTimeStep_ = std::max(newTimeStep_, sec.minTimeStep);
      newTimeStep_ = std::min(newTimeStep_, sec.maxTimeStep);

      double nextTimePt = sec.currentTime + newTimeStep_;

      if (nextTimePt > sec.stopTime)
      {
        nextTimePt  = sec.stopTime;
        newTimeStep_ = sec.stopTime - sec.currentTime;
      }

      sec.nextTime = nextTimePt;

      sec.currentTimeStepRatio = newTimeStep_/sec.lastTimeStep;
      sec.currentTimeStepSum   = newTimeStep_ + sec.lastTimeStep;

      if (DEBUG_TIME && isActive(Diag::TIME_STEP))
      {
        Xyce::dout() << "  nextTime = " <<  sec.nextTime << std::endl;
        Xyce::dout() << "  newTimeStep_ = " <<  newTimeStep_ << std::endl;
      }

      sec.currentTimeStep = newTimeStep_;
    }
    else // if time step is constant for this step:
    {
      double nextTimePt = sec.currentTime + sec.currentTimeStep;

      if (nextTimePt > sec.stopTime)
      {
        nextTimePt      = sec.stopTime;
        sec.currentTimeStep = sec.stopTime - sec.currentTime;
      }

      sec.currentTimeStepRatio = sec.currentTimeStep / sec.lastTimeStep;
      sec.currentTimeStepSum   = sec.currentTimeStep + sec.lastTimeStep;

      sec.nextTime = nextTimePt;
    }
  }
  if (DEBUG_TIME && isActive(Diag::TIME_STEP))
  {
    Xyce::dout() << Xyce::section_divider << std::endl;
  }

// 11/02/04 tscoffe:  This should be done at the beginning of an integration
//                    stop rather than at the end, so its been moved into
//                    ControlAlgorithm::transientLoop_
  // Update next stop time in StepErrorControl:
  // sec.updateStopTime();
}

//-----------------------------------------------------------------------------
// Function      : BackwardDifferentiation15::updateStateDeriv
// Purpose       :
// Special Notes :
// Scope         : public
// Creator       : Todd Coffey, SNL
// Creation Date : 11/17/05
//-----------------------------------------------------------------------------
void BackwardDifferentiation15::updateStateDeriv ()
{
  // dS/dt = spn0 - (sec.alpha_/hn)(S(x)-sn0)
  ds.nextStateDerivPtr->linearCombo(1.0,*ds.nextStatePtr,-1.0,*sn0Ptr);
  ds.nextStateDerivPtr->update(1.0,*spn0Ptr,-sec.alphas_/sec.currentTimeStep);
}


//-----------------------------------------------------------------------------
// Function      : BackwardDifferentiation15::updateLeadCurrentVec
// Purpose       : calculates lead currents in lead current vector with
//                 the ladCurrQVec.
// Special Notes :
// Scope         : public
// Creator       : Richard Schiek, Electrical Systems Modeling, SNL
// Creation Date : 03/22/2013
//-----------------------------------------------------------------------------
void BackwardDifferentiation15::updateLeadCurrentVec ()
{
  // dStoreQ/dt = spn0 - (sec.alpha_/hn)(S(x)-sn0)
  ds.nextLeadCurrentQDerivPtr->
    linearCombo(1.0,*ds.nextLeadCurrentQPtr,-1.0,*leadCurrentQn0Ptr);
  ds.nextLeadCurrentQDerivPtr->
    update(1.0,*leadCurrentQpn0Ptr,-sec.alphas_/sec.currentTimeStep);
  ds.nextLeadCurrentPtr->addVec(1.0,*ds.nextLeadCurrentQDerivPtr);
}


//-----------------------------------------------------------------------------
// Function      : BackwardDifferentiation15::getInitialQnorm
// Purpose       : Needed by 2-level solves.
// Special Notes :
// Scope         : public
// Creator       : Eric Keiter, SNL, Parallel Computational Sciences
// Creation Date : 03/18/07
//-----------------------------------------------------------------------------
void BackwardDifferentiation15::getInitialQnorm(TwoLevelError & tle) const
{
  tle.q1HistorySum = ds.partialSum_q1();
}

//-----------------------------------------------------------------------------
// Function      : BackwardDifferentiation15::setupTwoLevelError
// Purpose       : Needed by 2-level solves.
// Special Notes :
// Scope         : public
// Creator       : Eric Keiter, SNL, Parallel Computational Sciences
// Creation Date : 03/15/07
//-----------------------------------------------------------------------------
void BackwardDifferentiation15::getTwoLevelError(TwoLevelError & tle) const
{
  tle.xErrorSum    = ds.partialErrorNormSum ();
  tle.qErrorSum    = ds.partialQErrorNormSum ();
  tle.xErrorSum_m1 = ds.partialSum_m1 (sec.currentOrder_);
  tle.xErrorSum_m2 = ds.partialSum_m2 (sec.currentOrder_);
  tle.xErrorSum_p1 = ds.partialSum_p1 (sec.currentOrder_, sec.maxOrder_);
  tle.innerSize    = ds.newtonCorrectionPtr->globalLength();

  if (DEBUG_TIME && isActive(Diag::TIME_ERROR))
    Xyce::dout() << tle;
}

//-----------------------------------------------------------------------------
// Function      : TimeIntegrationMethod::partialTimeDeriv
// Purpose       :
// Special Notes :
// Scope         : public
// Creator       :
// Creation Date : 1/20/07
//-----------------------------------------------------------------------------
double BackwardDifferentiation15::partialTimeDeriv() const
{
  if (sec.currentTimeStep < 1e-30)
  {
    Xyce::Report::UserWarning() << "Excessively small current time step, incorrectly returning with large value";

    return leadingCoeff * 1.e+30;
  }

  return leadingCoeff / sec.currentTimeStep;
}

// Add titles here.
bool BackwardDifferentiation15::getSolnVarData( const int & gid, std::vector<double> & varData )
{
  // Dump data store information.
  int num = ds.getNumSolnVarData();
  bool ret = ds.getSolnVarData( gid, varData );

  // Dump BDF-specific vectors.
  if (ret)
  {
    varData.resize( num + 3 + 2*(sec.currentOrder_+1) );
    varData[num++] = qpn0Ptr->getElementByGlobalIndex ( gid );
    varData[num++] = ds.newtonCorrectionPtr->getElementByGlobalIndex ( gid );
    varData[num++] = ds.qNewtonCorrectionPtr->getElementByGlobalIndex ( gid );
    for (int i=0; i<= sec.currentOrder_; ++i)
    {
      varData[num++] = ds.xHistory[i]->getElementByGlobalIndex ( gid );
      varData[num++] = ds.qHistory[i]->getElementByGlobalIndex ( gid );
    }
  }
  return ret;
}

bool BackwardDifferentiation15::setSolnVarData( const int & gid, const std::vector<double> & varData )
{
  int num = ds.getNumSolnVarData();
  bool ret = ds.setSolnVarData( gid, varData );
  if (ret)
  {
    qpn0Ptr->setElementByGlobalIndex( gid, varData[num++] );
    ds.newtonCorrectionPtr->setElementByGlobalIndex( gid, varData[num++] );
    ds.qNewtonCorrectionPtr->setElementByGlobalIndex( gid, varData[num++] );
    for (int i=0; i<= sec.currentOrder_; ++i)
    {
      ds.xHistory[i]->setElementByGlobalIndex( gid, varData[num++] );
      ds.qHistory[i]->setElementByGlobalIndex( gid, varData[num++] );
    }
  }
  return ret;
}

bool BackwardDifferentiation15::getStateVarData( const int & gid, std::vector<double> & varData )
{
  int num = ds.getNumStateVarData();
  bool ret = ds.getStateVarData( gid, varData );
  if (ret)
  {
    varData.resize( num + 2 + (sec.currentOrder_+1) );
    varData[num++] = sn0Ptr->getElementByGlobalIndex( gid );
    varData[num++] = spn0Ptr->getElementByGlobalIndex( gid );
    for (int i=0; i<= sec.currentOrder_; ++i)
    {
      varData[num++] = ds.sHistory[i]->getElementByGlobalIndex ( gid );
    }
  }
  return ret;
}

bool BackwardDifferentiation15::setStateVarData( const int & gid, const std::vector<double> & varData )
{
  int num = ds.getNumStateVarData();
  bool ret = ds.setStateVarData( gid, varData );
  if (ret)
  {
    sn0Ptr->setElementByGlobalIndex( gid, varData[num++] );
    spn0Ptr->setElementByGlobalIndex( gid, varData[num++] );
    for (int i=0; i<= sec.currentOrder_; ++i)
    {
      ds.sHistory[i]->setElementByGlobalIndex( gid, varData[num++] );
    }
  }
  return ret;
}

bool BackwardDifferentiation15::getStoreVarData( const int & gid, std::vector<double> & varData )
{
  int num = ds.getNumStoreVarData();
  bool ret = ds.getStoreVarData( gid, varData );
  if (ret)
  {
    varData.resize( num + 1 + (sec.currentOrder_+1) );
    varData[num++] = ston0Ptr->getElementByGlobalIndex( gid );
    for (int i=0; i<= sec.currentOrder_; ++i)
    {
      varData[num++] = ds.stoHistory[i]->getElementByGlobalIndex ( gid );
    }
  }
  return ret;
}

bool BackwardDifferentiation15::setStoreVarData( const int & gid, const std::vector<double> & varData )
{
  int num = ds.getNumStoreVarData();
  bool ret = ds.setStoreVarData( gid, varData );
  if (ret)
  {
    ston0Ptr->setElementByGlobalIndex( gid, varData[num++] );
    for (int i=0; i<= sec.currentOrder_; ++i)
    {
      ds.stoHistory[i]->setElementByGlobalIndex( gid, varData[num++] );
    }
  }
  return ret;
}


} // namespace TimeIntg
} // namespace Xyce

