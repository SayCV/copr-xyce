//-----------------------------------------------------------------------------
// Copyright Notice
//
//   Copyright 2002 Sandia Corporation. Under the terms
//   of Contract DE-AC04-94AL85000 with Sandia Corporation, the U.S.
//   Government retains certain rights in this software.
//
//    Xyce(TM) Parallel Electrical Simulator
//    Copyright (C) 2002-2017 Sandia Corporation
//
//    This program is free software: you can redistribute it and/or modify
//    it under the terms of the GNU General Public License as published by
//    the Free Software Foundation, either version 3 of the License, or
//    (at your option) any later version.
//
//    This program is distributed in the hope that it will be useful,
//    but WITHOUT ANY WARRANTY; without even the implied warranty of
//    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//    GNU General Public License for more details.
//
//    You should have received a copy of the GNU General Public License
//    along with this program.  If not, see <http://www.gnu.org/licenses/>.
//-----------------------------------------------------------------------------

//-------------------------------------------------------------------------
//
// Purpose        : Status test.
//
// Special Notes  :
//
// Creator        : Roger Pawlowski, SNL 9233
//
// Creation Date  : 04/15/03
//
//
//
//
//-------------------------------------------------------------------------

#include <Xyce_config.h>


// ---------- Standard Includes ----------

// ----------   Xyce Includes   ----------
#include "N_NLS_NOX_Group.h"
#include "N_NLS_NOX_XyceTests.h"
#include "N_NLS_NOX_Vector.h"
#include "N_LAS_Vector.h"
#include "N_LOA_NonlinearEquationLoader.h"
#include "NOX.H"
#include "NOX_Solver_LineSearchBased.H"

#include <N_UTL_MachDepParams.h>

// ----------   Namespaces   ----------

namespace Xyce {
namespace Nonlinear {
namespace N_NLS_NOX {

// ----------   Code   ----------

//-----------------------------------------------------------------------------
// Function      : XyceTests::XyceTests
// Purpose       : constructor
// Special Notes :
// Scope         : public
// Creator       : 
// Creation Date : 
//-----------------------------------------------------------------------------
XyceTests::XyceTests(
  Parallel::Machine                     comm,
  bool                                  isTransient,
  double                                normF,
  double                                machPrec,
  TimeIntg::DataStore*                  data_store,
  double                                epsilon_a, 
  double                                epsilon_r, 
  double                                tol,
  int                                   maxIters,
  double                                convRate,
  double                                relConvRate,
  double                                maxConvRate,
  double                                stagnationTol,
  int                                   maxBadSteps,
  int                                   checkDeviceConvergence,
  double                                smallUpdateTol,
  Loader::NonlinearEquationLoader *     loader, 
  bool                                  maskingFlag,
  Linear::Vector *                      maskVectorPtr)
  : comm_(comm),
    status_(NOX::StatusTest::Unconverged),
    returnTest_(0),
    isTransient_(isTransient),
    niters_(-1),
    maxNormFindex_(-1),
    maxNormF_(0.0),
    requestedMaxNormF_(normF),
    requestedMachPrecTol_(machPrec),
    dsPtr_(data_store),
    weightsVectorPtr_(0),
    updateVectorPtr_(0),
    epsilon_a_(epsilon_a),
    epsilon_r_(epsilon_r),
    tol_(tol),
    weightedUpdate_(0.0),
    maxIters_(maxIters),
    requestedConvRate_(convRate),
    currentConvRate_(1.0),
    requestedRelativeConvRate_(relConvRate),
    currentRelativeConvRate_(1.0),
    normResidualInit_(1.0),
    smallUpdateTol_(smallUpdateTol),
    maxConvRate_(maxConvRate),
    lastIteration_(-1),
    badStepCount_(0),
    maxBadSteps_(maxBadSteps),
    minConvRate_(1.0),
    stagnationTol_(stagnationTol),
    xyceReturnCode_(0),
    checkDeviceConvergence_(checkDeviceConvergence),
    loaderPtr_(loader),
    maskingFlag_( maskingFlag ),
    weightMaskVectorPtr_( maskVectorPtr),
    allDevicesConverged_(false),
    innerDevicesConverged_(false)
{

}

//-----------------------------------------------------------------------------
// Function      : XyceTests::XyceTests
// Purpose       : destructor
// Special Notes :
// Scope         : public
// Creator       : 
// Creation Date : 
//-----------------------------------------------------------------------------
XyceTests::~XyceTests()
{
  if( weightsVectorPtr_ != 0 )
  {
    delete weightsVectorPtr_;
    delete updateVectorPtr_;
  }
}


//-----------------------------------------------------------------------------
// Function      : XyceTests::checkStatus
// Purpose       : main testing function for this class
// Special Notes :
// Scope         : public
// Creator       : 
// Creation Date : 
//-----------------------------------------------------------------------------
NOX::StatusTest::StatusType
XyceTests::checkStatus(
  const NOX::Solver::Generic&   problem,
  NOX::StatusTest::CheckType    checkType)
{
  status_ = NOX::StatusTest::Unconverged;
  xyceReturnCode_ = 0;
  niters_ = problem.getNumIterations();

  returnTest_ = 0;

  // Get the current and previous solutions
  const Linear::Vector& x = (dynamic_cast<const Vector&>
    (problem.getSolutionGroup().getX())).getNativeVectorRef();
  const Linear::Vector& oldX = (dynamic_cast<const Vector&>
    (problem.getPreviousSolutionGroup().getX())).getNativeVectorRef();

  // Test0 - NaN/Inf checker
  NOX::StatusTest::StatusType check = finiteTest_.checkStatus(problem, checkType);
  if (check == NOX::StatusTest::Failed) 
  {
    status_ = check;
    returnTest_ = 0;
    xyceReturnCode_ = retCodes_.nanFail; // default: -6
    return status_;
  }

  // This test is for 2-level solves only.  
  // If the inner solve failed, then the whole thing needs to fail.
  // If 2-level is not being used, this test doesn't do anything.
  innerDevicesConverged_ = loaderPtr_->innerDevicesConverged(comm_);
  if (!innerDevicesConverged_)
  {
    status_ = NOX::StatusTest::Failed;
    returnTest_ = 9;
    xyceReturnCode_ = retCodes_.innerSolveFailed; // default: -5
    return status_;
  }

  // Test #9 (-9):  if linear solver failed, reject.
  const N_NLS_NOX::Group & grp = 
      (dynamic_cast<const N_NLS_NOX::Group &>(problem.getSolutionGroup()));

  bool linearSolverStatus = grp.linearSolverStatus();
  if (!linearSolverStatus)
  {
    status_ = NOX::StatusTest::Failed;
    returnTest_ = 9;
    xyceReturnCode_ = retCodes_.linearSolverFailed; // default: -9
    return status_;
  }

  // Test 8 - Devices need to satisfy their own convergence criteria
  if (checkDeviceConvergence_) 
  {
    allDevicesConverged_ = loaderPtr_->allDevicesConverged(comm_);
    if (!allDevicesConverged_ && (niters_ < maxIters_)) 
    {
      status_ = NOX::StatusTest::Unconverged;
      returnTest_ = 8;
      xyceReturnCode_ = 0;
      return status_;
    }
  }

  // Compute a few norms needed by various tests.
  maxNormF_ = problem.getSolutionGroup().getF()
    .norm(NOX::Abstract::Vector::MaxNorm);

  const Linear::Vector& F = (dynamic_cast<const Vector&>
    (problem.getSolutionGroup().getF())).getNativeVectorRef();

  std::vector<int> index(1, -1);
  F.infNormIndex( &index[0] );
  maxNormFindex_ = index[0];

#if 0
  // ERK.  This has been removed as part of bug #414 (SON).  If its removal
  // causes problems then it could (maybe) be restored).  But it would need
  // to be restored to a point prior to the linear solver failure test, above.
  //
  //Test 1 - Make sure the residual isn't too small, hardwired tolerances
  if ((maxNormF_ < requestedMaxNormF_) && 
      (maxNormF_ < requestedMachPrecTol_)) 
  {
    status_ = NOX::StatusTest::Converged;
    returnTest_ = 1;
    xyceReturnCode_ = retCodes_.normTooSmall; // default: 1
    return status_;
  }
#endif

  // Test 2 - Normal convergence based on rhs residual (2a) and 
  // update norm (2b).

  // Allocate space if necessary
  if (weightsVectorPtr_ == 0) 
  {
    weightsVectorPtr_ = new Linear::Vector(x);
    // when we create weightsVectorPtr_ from the latest solution, there
    // is a chance that one of the values will be zero.  If this isn't 
    // the DC op step or the first iteration of a time step, then
    // we'll end up dividing by zero in the wMaxNorm function below.
    // So to be safe we'll just add epsilon_a_ on the when we create 
    // this vector.
    for (int i=0; i< x.localLength() ; ++i ) 
    {
      (*weightsVectorPtr_)[i] += epsilon_a_;
    }    
    updateVectorPtr_ = new Linear::Vector(x);
  }

  // Local references
  Linear::Vector& weights = *weightsVectorPtr_;

  // Compute local portion of weights vector
  // Weights are recomputed at each nonlinear iteration of a DC Op calc
  // but only at the beginning of a transient nonlinear solve.
  if ((!isTransient_) || (niters_ == 0)) 
  {
    int length = x.localLength();
    for (int i = 0; i < length; ++i ) 
    {
      //update[i] = x[i] - oldX[i];
      weights[i] =
        epsilon_r_ * std::max(fabs(x[i]), fabs((*dsPtr_->currSolutionPtr)[i])) + epsilon_a_;
      if (maskingFlag_ && ((*weightMaskVectorPtr_)[i] == 0.0) )
      {
        weights[i] = Util::MachineDependentParams::MachineBig();
      }
    }
  }

  if (niters_ < 1) 
  {
    weightedUpdate_ = 1.0;
  }
  else 
  {
    // Next compute the update
    updateVectorPtr_->update(1.0, x, -1.0, oldX, 0.0);

    // Compute final result
#ifdef Xyce_SPICE_NORMS
    updateVectorPtr_->wMaxNorm(weights,&weightedUpdate_);
#else
    updateVectorPtr_->wRMSNorm(weights,&weightedUpdate_);
#endif

    // RPP: If a line search is being used, we must account for any 
    // damping of the step length.  Otherwise delta X could be small due 
    // the line search and not due to being close to a solution.
    const NOX::Solver::LineSearchBased* test = 0;
    test = dynamic_cast<const NOX::Solver::LineSearchBased*>(&problem);
    if (test != 0) 
    {
      weightedUpdate_ = weightedUpdate_/(test->getStepSize());
    }

    if ((weightedUpdate_ < tol_) &&(maxNormF_ < requestedMaxNormF_)) 
    {
      status_ = NOX::StatusTest::Converged;
      returnTest_ = 2;
      xyceReturnCode_ = retCodes_.normalConvergence; // default: 2
      return status_;
    }
  }
 
  // Test 3 - Near Convergence - Hit max iterations but residual 
  // and convergence rate indicate we may be near a converged solution.  
  // Therefore, let the time stepper decide whether or  not the step is ok.
  // Transient mode ONLY!
  // NOTE: Convergence rates are based on the 2-Norm, not max norm!
  if (niters_ > 0) 
  {
    // ||F(x_current)|| / ||F(x_previous)||
    currentConvRate_ = (problem.getSolutionGroup().getNormF()) / 
      (problem.getPreviousSolutionGroup().getNormF());

    //  ||F(x)|| / ||F(x_init)||
    currentRelativeConvRate_ = (problem.getSolutionGroup().getNormF()) / 
    normResidualInit_;
  }    
  else 
  {
    currentConvRate_ = 1.0;
    currentRelativeConvRate_ = 1.0;
  }

  if (isTransient_) 
  {
    if (niters_ == 0) 
    {
      normResidualInit_ = problem.getSolutionGroup().getNormF();
    }
 
    // Test only if we hit the max number of iterations
    if (niters_ >= maxIters_) 
    {
      if ((currentConvRate_ <= requestedConvRate_) && 
          (currentRelativeConvRate_ <= requestedRelativeConvRate_)) 
      {
        status_ = NOX::StatusTest::Converged;
        xyceReturnCode_ = retCodes_.nearConvergence; // default: 3

        if (xyceReturnCode_ < 0)
          status_ = NOX::StatusTest::Failed;
        else
          status_ = NOX::StatusTest::Converged;
      }
      else
      {
        status_ = NOX::StatusTest::Failed;
        xyceReturnCode_ = retCodes_.tooManySteps; // default: -1
      }
      
      returnTest_ = 3;
      return status_;
    }
  } // end test 3

  // Test 4 - Update is too small
  if ((niters_ > 0) && (weightedUpdate_ < smallUpdateTol_) && (niters_ < maxIters_)) 
  {
    if (isTransient_) // Let the time integrator determine convergence (+4)
    {
      xyceReturnCode_ = retCodes_.smallUpdate; // default: 4
      status_ = NOX::StatusTest::Failed;
    }
    else
    {
      xyceReturnCode_ = 0; // neither pass nor fail.
      status_ = NOX::StatusTest::Unconverged;
    }

    returnTest_ = 4;

    return status_;
  }

  // Test 5 - Max nonlinear iterations (if transient, this will be checked 
  // in the NearConvergence test (#3)
  if ((!isTransient_) && (niters_ >= maxIters_)) 
  {
    status_ = NOX::StatusTest::Failed;
    returnTest_ = 5;
    xyceReturnCode_ = retCodes_.tooManySteps; // default: -1
    return status_;
  }

  // Test 6 - update is too big
  if (currentConvRate_ > maxConvRate_) 
  {
    status_ = NOX::StatusTest::Failed;
    returnTest_ = 6;
    xyceReturnCode_ = retCodes_.updateTooBig; // default: -2
    return status_;
  }

  // Test 7 - Stall in the convergence rate. Transient mode ONLY! 
  if (isTransient_) 
  {  
    // First time through we don't do anything but reset the counters
    if (niters_ == 0) 
    {
      badStepCount_ = 0;
      lastIteration_ = 0;
      //minConvRate = 1.0;  // Don't reset this.  Xyce solver never does.
    } 

    // Make sure we have not already counted the last nonlinear iteration.
    // This protects against multiple calls to checkStatus() in between 
    // nonlinear iterations.
    bool isCounted = false;
    if (niters_ == lastIteration_) 
    {
      isCounted = true;
    }
    else
    {
      lastIteration_ = niters_;
    }
    
    // Set counter appropriately
    if (!isCounted) 
    {
      if (fabs(currentConvRate_ - 1.0) <= stagnationTol_) 
      {
        if ((badStepCount_ == 0) || (currentConvRate_ < minConvRate_)) 
        {
          minConvRate_ = currentConvRate_;
        }
        ++badStepCount_ ;
      }
      else
      {
        badStepCount_ = 0;
      }
    }

    if (badStepCount_ >= maxBadSteps_) 
    {
      if ((currentRelativeConvRate_ <= 0.9) && (minConvRate_ <= 1.0)) 
      {
        status_ = NOX::StatusTest::Converged;
        returnTest_ = 7;
        xyceReturnCode_ = retCodes_.nearConvergence;   // default: 3
                // note - I'm not sure if this is 
               // really a near convergece test - but 3 is the code for it...

        if (xyceReturnCode_ < 0)
          status_ = NOX::StatusTest::Failed;
        else
          status_ = NOX::StatusTest::Converged;
      }
      else 
      {
        status_ = NOX::StatusTest::Failed;
        returnTest_ = 7;
        xyceReturnCode_ = retCodes_.stalled; // default: -3
      }
    }
  }

  return status_;
}

//-----------------------------------------------------------------------------
// Function      : XyceTests::print
// Purpose       : verbose output
// Special Notes :
// Scope         : public
// Creator       : 
// Creation Date : 
//-----------------------------------------------------------------------------
std::ostream& XyceTests::print(std::ostream& stream, int indent) const
{
  // precision
  int p = 5;

  for (int j = 0; j < indent; ++j )
    stream << ' ';
  stream << status_ << "by Test #" << returnTest_ << "\n";

  indent += 4;

  //for (int j = 0; j < indent; ++j )
  // stream << ' ';
  finiteTest_.print(stream, indent);

  if (checkDeviceConvergence_) {
    for (int j = 0; j < indent; ++j )
      stream << ' ';
    stream << "8. Devices are Converged: ";
    if (allDevicesConverged_)
      stream << "true" << "\n";
    else
      stream << "false" << "\n";
  }

  for (int j = 0; j < indent; ++j )
    stream << ' ';
  stream << "1. Inf-Norm F too small" << "\n";

  for (int j = 0; j < indent; ++j )
    stream << ' ';
  stream << "   Machine Precision: " << NOX::Utils::sciformat(maxNormF_, p)
	 << " < " << NOX::Utils::sciformat(requestedMachPrecTol_, p) << "\n";

  for (int j = 0; j < indent; ++j )
    stream << ' ';
  stream << "   Requested Tolerance: " << NOX::Utils::sciformat(maxNormF_, p)
	 << " < " << NOX::Utils::sciformat(requestedMaxNormF_, p) << "\n";

  for (int j = 0; j < indent; ++j )
    stream << ' ';
  stream << "2. Normal Convergence" << "\n";

  for (int j = 0; j < indent; ++j )
    stream << ' ';
  stream << "   Inf-Norm F: " << NOX::Utils::sciformat(maxNormF_, p)
	 << " < " << NOX::Utils::sciformat(requestedMaxNormF_, p) << "\n";

  for (int j = 0; j < indent; ++j )
    stream << ' ';
  stream << "   Weighted Update: " << NOX::Utils::sciformat(weightedUpdate_, p)
	 << " < " << NOX::Utils::sciformat(tol_, p) << "\n";

  for (int j = 0; j < indent; ++j )
    stream << ' ';
  stream << "3. Near Convergence" << "\n";

  for (int j = 0; j < indent; ++j )
    stream << ' ';
  stream << "   Max Iters: " << niters_
	 << " < " << maxIters_ << "\n";

  for (int j = 0; j < indent; ++j )
    stream << ' ';
  stream << "   Convergence Rate: " 
	 << NOX::Utils::sciformat(currentConvRate_, p)
	 << " < " << NOX::Utils::sciformat(requestedConvRate_, p) << "\n";

  for (int j = 0; j < indent; ++j )
    stream << ' ';
  stream << "   Relative Convergence Rate: " 
	 << NOX::Utils::sciformat(currentRelativeConvRate_, p)
	 << " < " << NOX::Utils::sciformat(requestedRelativeConvRate_, p) 
	 << "\n";

  for (int j = 0; j < indent; ++j )
    stream << ' ';
  stream << "4. Small Weighted Update: " 
	 << NOX::Utils::sciformat(weightedUpdate_, p)
	 << " < " << NOX::Utils::sciformat(smallUpdateTol_, p) << "\n";

  if (!isTransient_) {

    for (int j = 0; j < indent; ++j )
      stream << ' ';
    stream << "5. Maximum Iterations: " 
	   << niters_
	   << " < " << maxIters_ << "\n";
    
    for (int j = 0; j < indent; ++j )
      stream << ' ';
    stream << "6. Large Conv Rate: " 
	   << NOX::Utils::sciformat(currentConvRate_, p)
	   << " < " << NOX::Utils::sciformat(maxConvRate_, p) << "\n";
  }

  for (int j = 0; j < indent; ++j )
    stream << ' ';
  stream << "7. Stagnation " << "\n";

  for (int j = 0; j < indent; ++j )
    stream << ' ';
  stream << "   Bad Step Count: " 
	 << badStepCount_ << " < " << maxBadSteps_ << "\n";

  for (int j = 0; j < indent; ++j )
    stream << ' ';
  stream << "   Stagnation Tolerance: " 
	 << NOX::Utils::sciformat(fabs(currentConvRate_ - 1.0), p)
	 << " < " << NOX::Utils::sciformat(stagnationTol_, p) << "\n";

  for (int j = 0; j < indent; ++j )
    stream << ' ';
  stream << "9. Linear solver failed." << "\n";

  stream << std::endl;
  return stream;
}

//-----------------------------------------------------------------------------
// Function      : XyceTests::getXyceReturnCode
// Purpose       : verbose output
// Special Notes :
// Scope         : public
// Creator       : 
// Creation Date : 
//-----------------------------------------------------------------------------
int XyceTests::getXyceReturnCode() const
{
  return xyceReturnCode_;
}

//-----------------------------------------------------------------------------
// Function      : XyceTests::getMaxNormF
// Purpose       : verbose output
// Special Notes :
// Scope         : public
// Creator       : 
// Creation Date : 
//-----------------------------------------------------------------------------
double XyceTests::getMaxNormF() const
{
  return maxNormF_;
}

//-----------------------------------------------------------------------------
// Function      : XyceTests::getMaxNormFindex
// Purpose       : verbose output
// Special Notes :
// Scope         : public
// Creator       : 
// Creation Date : 
//-----------------------------------------------------------------------------
int XyceTests::getMaxNormFindex() const
{
  return maxNormFindex_;
}

}}}
