//-----------------------------------------------------------------------------
// Copyright Notice
//
//   Copyright 2002 Sandia Corporation. Under the terms
//   of Contract DE-AC04-94AL85000 with Sandia Corporation, the U.S.
//   Government retains certain rights in this software.
//
//    Xyce(TM) Parallel Electrical Simulator
//    Copyright (C) 2002-2017 Sandia Corporation
//
//    This program is free software: you can redistribute it and/or modify
//    it under the terms of the GNU General Public License as published by
//    the Free Software Foundation, either version 3 of the License, or
//    (at your option) any later version.
//
//    This program is distributed in the hope that it will be useful,
//    but WITHOUT ANY WARRANTY; without even the implied warranty of
//    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//    GNU General Public License for more details.
//
//    You should have received a copy of the GNU General Public License
//    along with this program.  If not, see <http://www.gnu.org/licenses/>.
//-----------------------------------------------------------------------------

//-------------------------------------------------------------------------
//
// Purpose        : 
//
// Special Notes  :
//
// Creator        : Eric R. Keiter, SNL
//
// Creation Date  : 2015-07-11
//
//-------------------------------------------------------------------------

#include <Xyce_config.h>


// ----------   Standard Includes   ----------

#include <algorithm>
#include <sstream>
#include <stdexcept>

// ----------   Xyce Includes   ----------

#include <N_ANP_AnalysisManager.h>
#include <N_NLS_SensitivityResiduals.h>
#include <N_ERH_ErrorMgr.h>

#include <N_LAS_Vector.h>
#include <N_LOA_NonlinearEquationLoader.h>

#include <N_PDS_Comm.h>
#include <N_PDS_ParMap.h>
#include <N_PDS_MPI.h>
#include <N_PDS_Manager.h>
#include <N_PDS_Serial.h>

#include <N_TIA_DataStore.h>

#include <N_UTL_Algorithm.h>
#include <N_UTL_Diagnostic.h>
#include <N_UTL_Expression.h>
#include <N_UTL_ExtendedString.h>
#include <N_UTL_FeatureTest.h>
#include <N_UTL_OptionBlock.h>

// ----------   Static Declarations ----------

namespace Xyce {
namespace Nonlinear {

//-----------------------------------------------------------------------------
// Function      : setupOriginalParams
//
// Special Notes : 
// Scope         : public
// Creator       : Eric Keiter, SNL
// Creation Date : 2/29/2016
//-----------------------------------------------------------------------------
bool setupOriginalParams ( TimeIntg::DataStore & ds,
  Loader::NonlinearEquationLoader & nonlinearEquationLoader_,
  const std::vector<std::string> & paramNameVec_,
  const Analysis::AnalysisManager & analysisManager_
    )
{
  ds.paramOrigVals_.clear();

  std::vector<std::string>::const_iterator firstParam = paramNameVec_.begin ();
  std::vector<std::string>::const_iterator lastParam  = paramNameVec_.end ();
  std::vector<std::string>::const_iterator iterParam;

  for (iterParam=firstParam; iterParam!=lastParam; ++iterParam)
  {
    std::string paramName(*iterParam);

    // get the original value of this parameter, to be used for scaling and/or 
    // numerical derivatives later.
    double paramOrig = 0.0;
    bool found = nonlinearEquationLoader_.getParamAndReduce(
        analysisManager_.getPDSManager()->getPDSComm()->comm(),paramName, paramOrig);

    if (!found)
    {
      Report::DevelFatal().in("Sensitivity::setupOriginalParams")
        << "cannot find parameter "
        << paramName;
    }
    ds.paramOrigVals_.push_back(paramOrig);
  }

  return true;
}

//-----------------------------------------------------------------------------
// Function      : loadSensitivityResiduals
//
// Purpose       : This function is to be called after a calculation has
//                 converged.  It computes the sensitivies of different components
//                 of the residual.  Recall the DAE form of the residual:
//                
//                 F = dq/dt + f - b
//
//                 This function sets up the following derivatives:  
//
//                 df/dp, dq/dp, db/dp where p is the parameter.
//
//                 Which can ultimately be assembled to give dF/dp:
//
//                         d(dq/dp)    
//                 dF/dp = ------- +  df/dp - db/dp
//                           dt
//
// Special Notes : 
// Scope         : public
// Creator       : Eric Keiter, SNL, Parallel Computational Sciences
// Creation Date : 7/15/02
//-----------------------------------------------------------------------------
bool loadSensitivityResiduals (
  int difference, bool forceFD_, double sqrtEta_, std::string & netlistFilename_,
  TimeIntg::DataStore & ds,
  Loader::NonlinearEquationLoader & nonlinearEquationLoader_,
  const std::vector<std::string> & paramNameVec_,
  const Analysis::AnalysisManager & analysisManager_
    )
{
  Stats::StatTop _solveTransientAdjointStat("loadSensitivityResiduals");
  Stats::TimeBlock _solveTransientAdjointTimer(_solveTransientAdjointStat);

  int iparam=0;
  std::string msg;

  Linear::MultiVector * dfdpPtrVector = ds.nextDfdpPtrVector;
  Linear::MultiVector * dqdpPtrVector = ds.nextDqdpPtrVector;
  Linear::MultiVector * dbdpPtrVector = ds.nextDbdpPtrVector;

  //ds.paramOrigVals_.clear();

  // it is necessary to load the Jacobian here to make sure we have the most
  // up-to-date matrix.  The Jacobian is not loaded for the final 
  // evaluation of the residual in the Newton solve.
  nonlinearEquationLoader_.loadJacobian ();

  // Loop over the vector of parameters.  For each parameter, find the
  // device entity (a model or an instance) which corresponds to it, and
  // perform the finite difference calculation.
  std::vector<std::string>::const_iterator firstParam = paramNameVec_.begin ();
  std::vector<std::string>::const_iterator lastParam  = paramNameVec_.end ();
  std::vector<std::string>::const_iterator iterParam;

  int maxParamStringSize_=0;
  if (DEBUG_NONLINEAR && isActive(Diag::SENS_SOLVER))
  {
    for ( iterParam=firstParam, iparam=0;
          iterParam!=lastParam; ++iterParam, ++iparam )
    {
      int sz = paramNameVec_[iparam].size();
      if (sz > maxParamStringSize_)
      {
        maxParamStringSize_ = sz;
      }
    }
  }

  setupOriginalParams (ds, nonlinearEquationLoader_, paramNameVec_, analysisManager_);

  dfdpPtrVector->putScalar(0.0);
  dqdpPtrVector->putScalar(0.0);
  dbdpPtrVector->putScalar(0.0);

  for ( iterParam=firstParam, iparam=0;
        iterParam!=lastParam; ++iterParam, ++iparam )
  {
    std::string paramName(*iterParam);

#if 0
    // get the original value of this parameter, to be used for scaling and/or 
    // numerical derivatives later.
    double paramOrig = 0.0;
    bool found = nonlinearEquationLoader_.getParamAndReduce(
        analysisManager_.getPDSManager()->getPDSComm()->comm(),paramName, paramOrig);

    if (!found)
    {
      Report::DevelFatal().in("Sensitivity::loadSensitivityResiduals")
        << "cannot find parameter "
        << paramName;
    }
    ds.paramOrigVals_.push_back(paramOrig);
#else
    double paramOrig = ds.paramOrigVals_[iparam];
#endif

    // check if derivative is available analytically.  If not, take FD.
    bool analyticAvailable = false;
    if (!forceFD_)
    {
      analyticAvailable = nonlinearEquationLoader_.analyticSensitivitiesAvailable (paramName);
    }
    if (analyticAvailable)
    {
      std::vector<double> dfdpVec;
      std::vector<double> dqdpVec;
      std::vector<double> dbdpVec;

      std::vector<int> FindicesVec;
      std::vector<int> QindicesVec;
      std::vector<int> BindicesVec;

      nonlinearEquationLoader_.getAnalyticSensitivities(paramName,
          dfdpVec,dqdpVec,dbdpVec,
          FindicesVec, QindicesVec, BindicesVec);

      Teuchos::RCP<Linear::Vector> dfdpPtr = dfdpPtrVector->getNonConstVectorView(iparam);
      Teuchos::RCP<Linear::Vector> dqdpPtr = dqdpPtrVector->getNonConstVectorView(iparam);
      Teuchos::RCP<Linear::Vector> dbdpPtr = dbdpPtrVector->getNonConstVectorView(iparam);

      int Fsize=FindicesVec.size();
      for (int i=0;i<Fsize;++i)
      {
        // ADMS devices with nodes that collapse to ground can have "-1"
        // as their LIDs, meaning the node doesn't really exist
        if (FindicesVec[i] != -1)
          (*dfdpPtr)[FindicesVec[i]]  += dfdpVec[i];
      }

      int Qsize=QindicesVec.size();
      for (int i=0;i<Qsize;++i)
      {
        // ADMS devices with nodes that collapse to ground can have "-1"
        // as their LIDs, meaning the node doesn't really exist
        if (QindicesVec[i] != -1)
          (*dqdpPtr)[QindicesVec[i]]  += dqdpVec[i];
      }

      int Bsize=BindicesVec.size();
      for (int i=0;i<Bsize;++i)
      {
        // ADMS devices with nodes that collapse to ground can have "-1"
        // as their LIDs, meaning the node doesn't really exist
        if (BindicesVec[i] != -1)
          (*dbdpPtr)[BindicesVec[i]]  += dbdpVec[i];
      }

      dfdpPtr->fillComplete();
      dqdpPtr->fillComplete();
      dbdpPtr->fillComplete();

      if (!ds.masterIndexVectorSize[iparam])
      {
        computeSparseIndices( iparam, ds, FindicesVec, QindicesVec, BindicesVec );
      }

      if (DEBUG_NONLINEAR && isActive(Diag::SENS_SOLVER))
      {
        Xyce::dout() << *iterParam << ": ";
        Xyce::dout().setf(std::ios::scientific);
        Xyce::dout() << std::endl;

        int solutionSize_ = dfdpPtrVector->localLength();

        for (int k1 = 0; k1 < solutionSize_; ++k1)
        {
          Xyce::dout() 
            <<"dfdp["<<std::setw(3)<<k1<<"]= "<<std::setw(15)<<std::scientific<<std::setprecision(8)<<(*dfdpPtr)[k1]
            <<" dqdp["<<std::setw(3)<<k1<<"]= "<<std::setw(15)<<std::scientific<<std::setprecision(8)<<(*dqdpPtr)[k1]
            <<" dbdp["<<std::setw(3)<<k1<<"]= "<<std::setw(15)<<std::scientific<<std::setprecision(8)<<(*dbdpPtr)[k1]
            <<std::endl;
        }
      }
    }
    else
    {
      if (DEBUG_NONLINEAR && isActive(Diag::SENS_SOLVER))
      {
        Xyce::dout() << std::endl << "  Calculating numerical df/dp, dq/dp and db/dp for: ";
        Xyce::dout() << *iterParam << std::endl;
      }

      // save a copy of the DAE vectors
      Linear::Vector origFVector( *(ds.daeFVectorPtr) );
      Linear::Vector origQVector( *(ds.daeQVectorPtr) );
      Linear::Vector origBVector( *(ds.daeBVectorPtr) );

      // now perturb the value of this parameter.
      double dp = sqrtEta_ * (1.0 + fabs(paramOrig));
      double paramPerturbed = paramOrig;

      if (difference==SENS_FWD)
      {
        paramPerturbed += dp;
      }
      else if (difference==SENS_REV)
      {
        paramPerturbed -= dp;
      }
      else if (difference==SENS_CNT)
      {
        Report::UserFatal0() << "difference=central not supported.";
      }
      else
      {
        Report::UserFatal0() << "difference not recognized!";
      }

      if (DEBUG_NONLINEAR && isActive(Diag::SENS_SOLVER))
      {
        Xyce::dout() << std::setw(maxParamStringSize_)<< *iterParam
          << " dp = " << std::setw(11)<< std::scientific<< std::setprecision(4) << dp 
          << " original value = " << std::setw(16)<< std::scientific<< std::setprecision(9) << paramOrig 
          << " modified value = " << std::setw(16)<< std::scientific<< std::setprecision(9) << paramPerturbed 
          <<std::endl;
      }

      nonlinearEquationLoader_.setParam (paramName, paramPerturbed);

      // Now that the parameter has been perturbed,
      // calculate the numerical derivative.

      // Load F,Q and B.
      nonlinearEquationLoader_.loadRHS();

      // save the perturbed DAE vectors
      Linear::Vector pertFVector( *(ds.daeFVectorPtr) );
      Linear::Vector pertQVector( *(ds.daeQVectorPtr) );
      Linear::Vector pertBVector( *(ds.daeBVectorPtr) );

      // calculate the df/dp vector.  
      double rdp=1/dp;
      Teuchos::RCP<Linear::Vector> dfdpPtr = dfdpPtrVector->getNonConstVectorView(iparam);
      dfdpPtr->linearCombo( 1.0, pertFVector, -1.0, origFVector );
      dfdpPtr->scale(rdp);

      // calculate the dq/dp vector.  
      Teuchos::RCP<Linear::Vector> dqdpPtr = dqdpPtrVector->getNonConstVectorView(iparam);
      dqdpPtr->linearCombo( 1.0, pertQVector, -1.0, origQVector );
      dqdpPtr->scale(rdp);

      // calculate the db/dp vector.  
      Teuchos::RCP<Linear::Vector> dbdpPtr = dbdpPtrVector->getNonConstVectorView(iparam);
      dbdpPtr->linearCombo( 1.0, pertBVector, -1.0, origBVector );
      dbdpPtr->scale(rdp);

      if (DEBUG_NONLINEAR && isActive(Diag::SENS_SOLVER))
      {
        Xyce::dout() << *iterParam << ": ";
        Xyce::dout().width(15); Xyce::dout().precision(7); Xyce::dout().setf(std::ios::scientific);
        Xyce::dout() << "deviceSens_dp = " << dp << std::endl;

        int solutionSize_ = pertFVector.localLength();

        for (int k1 = 0; k1 < solutionSize_; ++k1)
        {

          Xyce::dout() 
            <<"fpert["<<std::setw(3)<<k1<<"]= "<<std::setw(15)<<std::scientific<<std::setprecision(8)<<(pertFVector)[k1]
            <<" forig["<<std::setw(3)<<k1<<"]= "<<std::setw(15)<<std::scientific<<std::setprecision(8)<<(origFVector)[k1]
            <<" dfdp ["<<std::setw(3)<<k1<<"]= "<<std::setw(15)<<std::scientific<<std::setprecision(8)<<(*dfdpPtr)[k1]
            <<std::endl;
        }

        Xyce::dout() << std::endl;
        for (int k1 = 0; k1 < solutionSize_; ++k1)
        {
          Xyce::dout() 
            <<"qpert["<<std::setw(3)<<k1<<"]= "<<std::setw(15)<<std::scientific<<std::setprecision(8)<<(pertQVector)[k1]
            <<" qorig["<<std::setw(3)<<k1<<"]= "<<std::setw(15)<<std::scientific<<std::setprecision(8)<<(origQVector)[k1]
            <<" dqdp ["<<std::setw(3)<<k1<<"]= "<<std::setw(15)<<std::scientific<<std::setprecision(8)<<(*dqdpPtr)[k1]
            <<std::endl;
        }

        Xyce::dout() << std::endl ;
        for (int k1 = 0; k1 < solutionSize_; ++k1)
        {
          Xyce::dout() 
            <<"bpert["<<std::setw(3)<<k1<<"]= "<<std::setw(15)<<std::scientific<<std::setprecision(8)<<(pertBVector)[k1]
            <<" borig["<<std::setw(3)<<k1<<"]= "<<std::setw(15)<<std::scientific<<std::setprecision(8)<<(origBVector)[k1]
            <<" dbdp ["<<std::setw(3)<<k1<<"]= "<<std::setw(15)<<std::scientific<<std::setprecision(8)<<(*dbdpPtr)[k1]
            <<std::endl;

        }

        std::ostringstream filename; 
        filename << netlistFilename_ << "_dfdp";
        filename << std::setw(3) << std::setfill('0') << iparam;
        filename << ".txt";
        dfdpPtr->writeToFile(const_cast<char *>(filename.str().c_str()));

        filename.str("");
        filename << netlistFilename_ << "_fpert";
        filename << std::setw(3) << std::setfill('0') << iparam;
        filename << ".txt";
        pertFVector.writeToFile(const_cast<char *>(filename.str().c_str()));

        filename.str("");
        filename << netlistFilename_ << "_dqdp";
        filename << std::setw(3) << std::setfill('0') << iparam;
        filename << ".txt";
        dqdpPtr->writeToFile(const_cast<char *>(filename.str().c_str()));

        filename.str("");
        filename << netlistFilename_ << "_qpert";
        filename << std::setw(3) << std::setfill('0') << iparam;
        filename << ".txt";
        pertQVector.writeToFile(const_cast<char *>(filename.str().c_str()));

        filename.str("");
        filename << netlistFilename_ << "_dbdp";
        filename << std::setw(3) << std::setfill('0') << iparam;
        filename << ".txt";
        dbdpPtr->writeToFile(const_cast<char *>(filename.str().c_str()));

        filename.str("");
        filename << netlistFilename_ << "_bpert";
        filename << std::setw(3) << std::setfill('0') << iparam;
        filename << ".txt";
        pertBVector.writeToFile(const_cast<char *>(filename.str().c_str()));
      }

      // now reset the parameter and rhs to previous values.
      nonlinearEquationLoader_.setParam (paramName, paramOrig);

      *(ds.daeFVectorPtr) = origFVector;
      *(ds.daeQVectorPtr) = origQVector;
      *(ds.daeBVectorPtr) = origBVector;
    }
  }

  return true;
}


//-----------------------------------------------------------------------------
// Function      : computeSparseIndices
//
// Special Notes :
// Scope         : public
// Creator       : Heidi Thornquist, SNL
// Creation Date : 2/2/2017
//-----------------------------------------------------------------------------
bool computeSparseIndices ( const int iparam, 
  TimeIntg::DataStore & ds,     
  const std::vector<int>& FindicesVec,
  const std::vector<int>& QindicesVec,
  const std::vector<int>& BindicesVec
    )
{
  std::vector<int> & masterRef = (ds.masterIndexVector [iparam]);

  int Fsize = FindicesVec.size();
  int Qsize = QindicesVec.size();
  int Bsize = BindicesVec.size();
  int size = std::max(Bsize,std::max(Fsize,Qsize));

  Linear::MultiVector * dfdpPtrVector = ds.nextDfdpPtrVector;
  int solutionSize = dfdpPtrVector->localLength();
  int gndNode = dfdpPtrVector->omap()->numLocalEntities() - 1;

  // Get parallel information.     
  int numProc =  dfdpPtrVector->pdsComm()->numProc();
  int myPID = dfdpPtrVector->pdsComm()->procID();

  if (Fsize >0 && Fsize != size)
  {
    std::cout << "THIS IS BROKEN  Fsize != size !!!!!" <<std::endl;
    exit(0);
  }

  if (Qsize >0 && Qsize != size)
  {
    std::cout << "THIS IS BROKEN  Qsize != size !!!!!" <<std::endl;
    exit(0);
  }

  if (Bsize >0 && Bsize != size)
  {
    std::cout << "THIS IS BROKEN  Bsize != size !!!!!" <<std::endl;
    exit(0);
  }

  std::vector<int> ghostNodes;
  for (int i=0;i<Fsize;++i)
  {
    int currIdx = FindicesVec[i];
    if (currIdx != -1 && currIdx != gndNode)
    {
      if (currIdx < solutionSize)
      {
        masterRef.push_back( currIdx );
      }
      else
      { 
        ghostNodes.push_back( dfdpPtrVector->omap()->localToGlobalIndex( currIdx ) );
      }
    }
  }

  for (int i=0;i<Qsize;++i)
  {
    int currIdx = QindicesVec[i];
    if (currIdx != -1 && currIdx != gndNode)
    {
      if (currIdx < solutionSize)
      {
        masterRef.push_back( currIdx );
      }
      else
      {
        ghostNodes.push_back( dfdpPtrVector->omap()->localToGlobalIndex( currIdx ) );
      }
    }
  }

  for (int i=0;i<Bsize;++i)
  {
    int currIdx = BindicesVec[i];
    if (currIdx != -1 && currIdx != gndNode)
    {
      if (currIdx < solutionSize)
      {
        masterRef.push_back( currIdx );
      }
      else
      {
        ghostNodes.push_back( dfdpPtrVector->omap()->localToGlobalIndex( currIdx ) );
      }
    }
  }

  // Create unique list of masterRef indices. 
  std::sort( masterRef.begin(), masterRef.end() ); 
  masterRef.erase( std::unique( masterRef.begin(), masterRef.end() ), masterRef.end() );

  // Process ghost nodes, if there are any.
  if (numProc > 1)
  {
    // Create unique list of ghost nodes.
    std::sort( ghostNodes.begin(), ghostNodes.end() );
    ghostNodes.erase( std::unique( ghostNodes.begin(), ghostNodes.end() ), ghostNodes.end() );

    // First communicate number of ghost nodes to all processors.
    std::vector<int> myGhostNodes( numProc, 0 ), totalGhostNodes( numProc, 0 );
    myGhostNodes[ myPID ] = ghostNodes.size();
    dfdpPtrVector->pdsComm()->sumAll( &myGhostNodes[0], &totalGhostNodes[0], numProc );

    // Communicate list of ghost nodes.
    int myStartIdx = 0, totalIdx = 0;
    for (int i=0; i<numProc; ++i)
    {
      if (i < myPID)
      {
        myStartIdx += totalGhostNodes[i];
      }
      totalIdx += totalGhostNodes[i];
    }
    std::vector<int> myGhostNodesGIDs( totalIdx, 0 ), totalGhostNodesGIDs( totalIdx, 0 );

    for (unsigned int i=0; i<ghostNodes.size(); ++i)
    {
      myGhostNodesGIDs[ myStartIdx + i ] = ghostNodes[i];
    }
    dfdpPtrVector->pdsComm()->sumAll( &myGhostNodesGIDs[0], &totalGhostNodesGIDs[0], totalIdx );
    std::sort( totalGhostNodesGIDs.begin(), totalGhostNodesGIDs.end() );
    totalGhostNodesGIDs.erase( std::unique( totalGhostNodesGIDs.begin(), totalGhostNodesGIDs.end() ), totalGhostNodesGIDs.end() );

    // Determine if masterRef should be ammended.
    for (unsigned int i=0; i< totalGhostNodesGIDs.size(); ++i)
    {
      int lid = dfdpPtrVector->pmap()->globalToLocalIndex( totalGhostNodesGIDs[i] ); 
      if (lid > -1)
      {
        std::vector<int>::iterator iter = std::find( masterRef.begin(), masterRef.end(), lid );
        if (iter == masterRef.end())
        {
          masterRef.push_back( lid );
        }
      }
    }

    // Collect the global master ref size.
    int tmpMRSize = masterRef.size(), mrSize = 0;
    dfdpPtrVector->pdsComm()->sumAll( &tmpMRSize, &mrSize, 1 );
    ds.masterIndexVectorSize[iparam] = mrSize;
  }
  else
  {
    ds.masterIndexVectorSize[iparam] = masterRef.size();
  } 

  return true;
}

} // namespace Nonlinear
} // namespace Xyce
