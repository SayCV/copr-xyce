//-----------------------------------------------------------------------------
// Copyright Notice
//
//   Copyright 2002 Sandia Corporation. Under the terms
//   of Contract DE-AC04-94AL85000 with Sandia Corporation, the U.S.
//   Government retains certain rights in this software.
//
//    Xyce(TM) Parallel Electrical Simulator
//    Copyright (C) 2002-2017 Sandia Corporation
//
//    This program is free software: you can redistribute it and/or modify
//    it under the terms of the GNU General Public License as published by
//    the Free Software Foundation, either version 3 of the License, or
//    (at your option) any later version.
//
//    This program is distributed in the hope that it will be useful,
//    but WITHOUT ANY WARRANTY; without even the implied warranty of
//    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//    GNU General Public License for more details.
//
//    You should have received a copy of the GNU General Public License
//    along with this program.  If not, see <http://www.gnu.org/licenses/>.
//-----------------------------------------------------------------------------

//-----------------------------------------------------------------------------
//
// Purpose        :
//
// Creator        : Todd Coffey, 1414
//
// Creation Date  : 09/04/08
//
//
//
//
//-------------------------------------------------------------------------

#include <Xyce_config.h>


// ---------- Standard Includes ----------

// ----------   Xyce Includes   ----------

#include <N_ERH_ErrorMgr.h>
#include <N_NLS_NonLinearSolver.h>
#include <N_NLS_MatrixFreeEpetraOperator.h>
#include <N_LAS_Vector.h>
#include <N_PDS_ParMap.h>

namespace Xyce {
namespace Nonlinear {

//-----------------------------------------------------------------------------
// Function      : matrixFreeEpetraOperator
// Purpose       : non-member constructor
// Special Notes :
// Scope         : public
// Creator       : Todd Coffey, 1414
// Creation Date : 9/4/08
//-----------------------------------------------------------------------------
RCP<MatrixFreeEpetraOperator> matrixFreeEpetraOperator(
    RCP<NonLinearSolver> nonlinearSolver,
    RCP<Linear::Vector> solVector,
    RCP<Linear::Vector> rhsVector,
    RCP<const Epetra_Map> solutionMap
    )
{
  RCP<MatrixFreeEpetraOperator> epetraOperator =
    rcp(new MatrixFreeEpetraOperator);
  epetraOperator->initialize(nonlinearSolver,
      solVector,
      rhsVector,
      solutionMap
      );
  return epetraOperator;
}


//-----------------------------------------------------------------------------
// Function      : MatrixFreeEpetraOperator::MatrixFreeEpetraOperator
// Purpose       : Constructor
// Special Notes :
// Scope         : public
// Creator       : Todd Coffey, 1414
// Creation Date : 9/4/08
//-----------------------------------------------------------------------------
MatrixFreeEpetraOperator::MatrixFreeEpetraOperator()
{
  isInitialized_ = false;
}

//-----------------------------------------------------------------------------
// Function      : MatrixFreeEpetraOperator::MatrixFreeEpetraOperator
// Purpose       : Destructor
// Special Notes :
// Scope         : public
// Creator       : Todd Coffey, 1414
// Creation Date : 9/4/08
//-----------------------------------------------------------------------------
MatrixFreeEpetraOperator::~MatrixFreeEpetraOperator()
{
}

//-----------------------------------------------------------------------------
// Function      : MatrixFreeEpetraOperator::initialize
// Purpose       : Initialization
// Special Notes :
// Scope         : public
// Creator       : Todd Coffey, 1414
// Creation Date : 9/4/08
//-----------------------------------------------------------------------------
void MatrixFreeEpetraOperator::initialize(
      RCP<NonLinearSolver> nonlinearSolver,
      RCP<Linear::Vector> solVector,
      RCP<Linear::Vector> rhsVector,
      RCP<const Epetra_Map> solutionMap
    )
{
  nonlinearSolverRCPtr_ = nonlinearSolver;
  solVectorRCPtr_ = solVector;
  rhsVectorRCPtr_ = rhsVector;
  solutionMap_ = solutionMap;
  isInitialized_ = true;
}

//-----------------------------------------------------------------------------
// Function      : MatrixFreeEpetraOperator::SetUseTranspose
// Purpose       : Define if transpose Apply and ApplyInverse is to be used.
// Special Notes :
// Scope         : public
// Creator       : Todd Coffey, 1414
// Creation Date : 9/4/08
//-----------------------------------------------------------------------------
int MatrixFreeEpetraOperator::SetUseTranspose(bool UseTranspose)
{
  // This is not supported for the HB load layers.
  return -1;
}

//-----------------------------------------------------------------------------
// Function      : MatrixFreeEpetraOperator::Apply
// Purpose       : Apply matrix free operator with Epetra_MultiVectors
// Special Notes :
// Scope         : public
// Creator       : Todd Coffey, 1414
// Creation Date : 9/4/08
//-----------------------------------------------------------------------------
int MatrixFreeEpetraOperator::Apply(
  const Epetra_MultiVector& X,
  Epetra_MultiVector& Y
  ) const
{
  // Convert these to Linear::MultiVectors and call the other Apply

  // COPY the multi-vector data into new objects on the stack.
  Epetra_MultiVector* Xcopy = new Epetra_MultiVector(X); // This gets deleted by the Linear::MultiVector below
  Epetra_MultiVector* Ycopy = new Epetra_MultiVector(Y); // This gets deleted by the Linear::MultiVector below
  Linear::MultiVector las_X(Xcopy, true); // this co-ops the Epetra_MultiVector and uses (and owns) its memory
  Linear::MultiVector las_Y(Ycopy, true); // this co-ops the Epetra_MultiVector and uses (and owns) its memory
  int status = Apply(las_X,las_Y);
  // COPY the Ycopy data back into Y
  Y = las_Y.epetraObj();
  return(status);
}

//-----------------------------------------------------------------------------
// Function      : MatrixFreeEpetraOperator::Apply
// Purpose       : Apply matrix free operator with Linear::MultiVectors
// Special Notes :
// Scope         : public
// Creator       : Todd Coffey, 1414
// Creation Date : 9/4/08
//-----------------------------------------------------------------------------
int MatrixFreeEpetraOperator::Apply(
  const Linear::MultiVector& X,
  Linear::MultiVector& Y
  ) const
{
  if (!isInitialized_)
  {
    Report::DevelFatal0().in("MatrixFreeEpetraOperator::Apply")
      << "I'm not initialized!";
  }
  bool status = true;
  for (int i=0 ; i<X.numVectors() ; ++i)
  {
    const Linear::Vector x(X.epetraVector(i), true);
    Linear::Vector y(Y.epetraVector(i), true);
    bool localStatus = nonlinearSolverRCPtr_->applyJacobian(x,y);
    status = status && localStatus;
  }
  if (status)
  {
    return 0;
  }
  else
  {
    return -1;
  }
}
//-----------------------------------------------------------------------------
// Function      : MatrixFreeEpetraOperator::ApplyInverse
// Purpose       : Apply inverse of matrix free operator with Epetra_MultiVectors
// Special Notes :
// Scope         : public
// Creator       : Todd Coffey, 1414
// Creation Date : 9/4/08
//-----------------------------------------------------------------------------
int MatrixFreeEpetraOperator::ApplyInverse(
  const Epetra_MultiVector& X,
  Epetra_MultiVector& Y
  ) const
{
  Report::DevelFatal0().in("MatrixFreeEpetraOperator::ApplyInverse")
    << "is not supported!";
  return -1;
}

//-----------------------------------------------------------------------------
// Function      : MatrixFreeEpetraOperator::ApplyInverse
// Purpose       : Apply inverse of matrix free operator with Linear::MultiVectors
// Special Notes :
// Scope         : public
// Creator       : Todd Coffey, 1414
// Creation Date : 9/4/08
//-----------------------------------------------------------------------------
int MatrixFreeEpetraOperator::ApplyInverse(
  const Linear::MultiVector& X,
  Linear::MultiVector& Y
  ) const
{
  Report::DevelFatal0().in("MatrixFreeEpetraOperator::ApplyInverse")
    << "is not supported!";
  return -1;
}

//-----------------------------------------------------------------------------
// Function      : MatrixFreeEpetraOperator::NormInf
// Purpose       : Norm Inf of matrix
// Special Notes :
// Scope         : public
// Creator       : Todd Coffey, 1414
// Creation Date : 9/4/08
//-----------------------------------------------------------------------------
double MatrixFreeEpetraOperator::NormInf() const
{
  Report::DevelFatal0().in("MatrixFreeEpetraOperator::NormInf")
    << "is not supported!";
  return -1.0;
}

//-----------------------------------------------------------------------------
// Function      : MatrixFreeEpetraOperator::Label
// Purpose       : Label for operator
// Special Notes :
// Scope         : public
// Creator       : Todd Coffey, 1414
// Creation Date : 9/4/08
//-----------------------------------------------------------------------------
const char * MatrixFreeEpetraOperator::Label() const
{
  return "Matrix Free Harmonic Balance Epetra Operator";
}

//-----------------------------------------------------------------------------
// Function      : MatrixFreeEpetraOperator::UseTranspose
// Purpose       : Query for useTranspose setting
// Special Notes :
// Scope         : public
// Creator       : Todd Coffey, 1414
// Creation Date : 9/4/08
//-----------------------------------------------------------------------------
bool MatrixFreeEpetraOperator::UseTranspose() const
{
  // Use Transpose is not supported, so always return false.
  return false;
}

//-----------------------------------------------------------------------------
// Function      : MatrixFreeEpetraOperator::HasNormInf
// Purpose       : Query for normInf support
// Special Notes :
// Scope         : public
// Creator       : Todd Coffey, 1414
// Creation Date : 9/4/08
//-----------------------------------------------------------------------------
bool MatrixFreeEpetraOperator::HasNormInf() const
{
  // Norm Inf is not supported, so always return false.
  return false;
}

//-----------------------------------------------------------------------------
// Function      : MatrixFreeEpetraOperator::Comm
// Purpose       : Return Epetra_Comm object
// Special Notes :
// Scope         : public
// Creator       : Todd Coffey, 1414
// Creation Date : 9/4/08
//-----------------------------------------------------------------------------
const Epetra_Comm & MatrixFreeEpetraOperator::Comm() const
{
  if (!isInitialized_)
  {
    Report::DevelFatal0().in("MatrixFreeEpetraOperator::Comm")
      << "I'm not initialized!";
  }
  return(rhsVectorRCPtr_->epetraObj().Comm());
}

//-----------------------------------------------------------------------------
// Function      : MatrixFreeEpetraOperator::OperatorDomainMap
// Purpose       : Return Epetra_Map corresponding to domain of operator
// Special Notes :
// Scope         : public
// Creator       : Todd Coffey, 1414
// Creation Date : 9/4/08
//-----------------------------------------------------------------------------
const Epetra_Map & MatrixFreeEpetraOperator::OperatorDomainMap() const
{
  if (!isInitialized_)
  {
    Report::DevelFatal0().in("MatrixFreeEpetraOperator::OperatorDomainMap")
      << "I'm not initialized!";
  }
  return(*solutionMap_);
}

//-----------------------------------------------------------------------------
// Function      : MatrixFreeEpetraOperator::OperatorRangeMap
// Purpose       : Return Epetra_Map corresponding to range of operator
// Special Notes :
// Scope         : public
// Creator       : Todd Coffey, 1414
// Creation Date : 9/4/08
//-----------------------------------------------------------------------------
const Epetra_Map & MatrixFreeEpetraOperator::OperatorRangeMap() const
{
  if (!isInitialized_)
  {
    Report::DevelFatal0().in("MatrixFreeEpetraOperator::OperatorRangeMap")
      << "I'm not initialized!";
  }
  const Epetra_Map* emap = dynamic_cast<const Epetra_Map*>(&rhsVectorRCPtr_->epetraObj().Map());
  return(*solutionMap_);
}

} // namespace Nonlinear
} // namespace Xyce
