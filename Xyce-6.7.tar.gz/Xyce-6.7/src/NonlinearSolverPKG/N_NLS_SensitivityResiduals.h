//-----------------------------------------------------------------------------
// Copyright Notice
//
//   Copyright 2002 Sandia Corporation. Under the terms
//   of Contract DE-AC04-94AL85000 with Sandia Corporation, the U.S.
//   Government retains certain rights in this software.
//
//    Xyce(TM) Parallel Electrical Simulator
//    Copyright (C) 2002-2017 Sandia Corporation
//
//    This program is free software: you can redistribute it and/or modify
//    it under the terms of the GNU General Public License as published by
//    the Free Software Foundation, either version 3 of the License, or
//    (at your option) any later version.
//
//    This program is distributed in the hope that it will be useful,
//    but WITHOUT ANY WARRANTY; without even the implied warranty of
//    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//    GNU General Public License for more details.
//
//    You should have received a copy of the GNU General Public License
//    along with this program.  If not, see <http://www.gnu.org/licenses/>.
//-----------------------------------------------------------------------------

//-------------------------------------------------------------------------
//
// Purpose        : This file contains the sensitivity class.   It mostly
//                  manages the calculations of direct (and possibly later,
//                  adjoint) sensitivities.
//
// Special Notes  : The main reason that this class is derived from
//                  N_NLS_NonLinearSolver is that this class needs to
//                  do a series of linear solves, using the jacobian
//                  matrix.  This seemed similar enough to the requirements
//                  of a nonlinear solver to have one derived off the other.
//
// Creator        : Eric Keiter, SNL, Parallel Computational Sciences
//
// Creation Date  : 06/15/2015
//
//
//
//
//-------------------------------------------------------------------------

#ifndef Xyce_N_NLS_SensitivityResiduals_h
#define Xyce_N_NLS_SensitivityResiduals_h

#include<vector>

#include <N_UTL_fwd.h>
#include <N_PDS_fwd.h>
#include <N_TOP_fwd.h>

#include <N_ANP_AnalysisManager.h>
#include <N_TIA_DataStore.h>
#include <N_LOA_NonlinearEquationLoader.h>


namespace Xyce {
namespace Nonlinear {

enum sensDiffMode
{
  SENS_FWD,
  SENS_REV,
  SENS_CNT,
  NUM_DIFF_MODES
};

bool loadSensitivityResiduals(int difference, bool forceFD_, double sqrtEta_,  std::string & netlistFilename_,
  TimeIntg::DataStore & ds,
  Loader::NonlinearEquationLoader & nonlinearEquationLoader_,
  const std::vector<std::string> & paramNameVec_,
  const Analysis::AnalysisManager & analysisManager_
    );

bool setupOriginalParams ( TimeIntg::DataStore & ds,
  Loader::NonlinearEquationLoader & nonlinearEquationLoader_,
  const std::vector<std::string> & paramNameVec_,
  const Analysis::AnalysisManager & analysisManager_
    );

bool computeSparseIndices ( const int iparam,
  TimeIntg::DataStore & ds,
  const std::vector<int>& FindicesVec,
  const std::vector<int>& QindicesVec,
  const std::vector<int>& BindicesVec
    );

} // namespace Nonlinear
} // namespace Xyce

#endif // Xyce_N_NLS_SensitivityResiduals_h

