//-----------------------------------------------------------------------------
// Copyright Notice
//
//   Copyright 2002 Sandia Corporation. Under the terms
//   of Contract DE-AC04-94AL85000 with Sandia Corporation, the U.S.
//   Government retains certain rights in this software.
//
//    Xyce(TM) Parallel Electrical Simulator
//    Copyright (C) 2002-2017 Sandia Corporation
//
//    This program is free software: you can redistribute it and/or modify
//    it under the terms of the GNU General Public License as published by
//    the Free Software Foundation, either version 3 of the License, or
//    (at your option) any later version.
//
//    This program is distributed in the hope that it will be useful,
//    but WITHOUT ANY WARRANTY; without even the implied warranty of
//    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//    GNU General Public License for more details.
//
//    You should have received a copy of the GNU General Public License
//    along with this program.  If not, see <http://www.gnu.org/licenses/>.
//-----------------------------------------------------------------------------

//-----------------------------------------------------------------------------
//
// Purpose        : Misc. typedefs, defines, and structs for Topology
//
// Special Notes  :
//
// Creator        : Rob Hoekstra
//
// Creation Date  : 7/03/01
//
//
//
//
//-----------------------------------------------------------------------------

#ifndef Xyce_N_TOP_Misc_h
#define Xyce_N_TOP_Misc_h

#include <string>
#include <iostream>
#include <utility>
#if defined(HAVE_UNORDERED_MAP)
#include <unordered_map>
using std::unordered_map;
#elif defined(HAVE_TR1_UNORDERED_MAP)
#include <tr1/unordered_map>
using std::tr1::unordered_map;
#else
#error neither unordered_map or tr1/unordered_map found
#endif

namespace Xyce {

class NodeID : public std::pair< std::string, int >
{
public:
  NodeID()
    : std::pair<std::string, int>()
  {}

  NodeID(const std::string &node, int id)
    : std::pair<std::string, int>( node, id )
  {}
};

inline std::ostream& operator<< (std::ostream &os, const NodeID& n)
{
  return os << "( " << n.first << " , " << n.second << " )";
}

} // namespace Xyce

namespace std {

template<>
struct equal_to<Xyce::NodeID> : public std::binary_function<Xyce::NodeID, Xyce::NodeID, bool>
{
  bool operator()(const Xyce::NodeID &lhs, const Xyce::NodeID &rhs) const
  {
    equal_to<std::string> x0;
    equal_to<int> x1;

    return x1(lhs.second, rhs.second) && x0(lhs.first, rhs.first);
  }
};

#if defined(HAVE_TR1_UNORDERED_MAP) && !defined(HAVE_UNORDERED_MAP)
namespace tr1 {
#endif

template<>
struct hash<Xyce::NodeID> : public std::unary_function<Xyce::NodeID, size_t>
{
  size_t operator()(const Xyce::NodeID &node_id) const
  {
    hash<std::string> x0;
    hash<int> x1;

    return x0(node_id.first) ^ x1(node_id.second);
  }
};

#if defined(HAVE_TR1_UNORDERED_MAP) && !defined(HAVE_UNORDERED_MAP)
} // namespace tr1
#endif

} // std namespace

#endif
