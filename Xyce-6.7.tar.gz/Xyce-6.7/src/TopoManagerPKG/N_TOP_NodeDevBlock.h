//-----------------------------------------------------------------------------
// Copyright Notice
//
//   Copyright 2002 Sandia Corporation. Under the terms
//   of Contract DE-AC04-94AL85000 with Sandia Corporation, the U.S.
//   Government retains certain rights in this software.
//
//    Xyce(TM) Parallel Electrical Simulator
//    Copyright (C) 2002-2017 Sandia Corporation
//
//    This program is free software: you can redistribute it and/or modify
//    it under the terms of the GNU General Public License as published by
//    the Free Software Foundation, either version 3 of the License, or
//    (at your option) any later version.
//
//    This program is distributed in the hope that it will be useful,
//    but WITHOUT ANY WARRANTY; without even the implied warranty of
//    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//    GNU General Public License for more details.
//
//    You should have received a copy of the GNU General Public License
//    along with this program.  If not, see <http://www.gnu.org/licenses/>.
//-----------------------------------------------------------------------------

//-----------------------------------------------------------------------------
//
// Purpose        : Block of Node and Dev data for passing between pkgs
//
// Special Notes  :
//
// Creator        : Robert J. Hoekstra, SNL, Parallel Computational Sciences
//
// Creation Date  : 3/3/01
//
//
//
//
//-----------------------------------------------------------------------------

#ifndef N_TOP_NodeDevBlock_h
#define N_TOP_NodeDevBlock_h 1

#include <iosfwd>

#include <N_UTL_Pack.h>
#include <N_DEV_DeviceBlock.h>
#include <N_TOP_Misc.h>

namespace Xyce {
namespace Topo {

//-----------------------------------------------------------------------------
// Class         : NodeDevBlock
// Purpose       :
// Special Notes :
// Creator       : Rob Hoekstra, SNL, Parallel Computational Sciences
// Creation Date : 3/3/01
//-----------------------------------------------------------------------------
class NodeDevBlock
{
  friend class Pack<NodeDevBlock>;
  friend std::ostream &operator<<(std::ostream & os, const NodeDevBlock & ndb);

public:
  NodeDevBlock()
  {}

  NodeDevBlock(
    const Device::InstanceBlock &       ib)
  : devBlock_(ib)
  {}

  NodeDevBlock(const NodeDevBlock & right)
  : devBlock_(right.devBlock_)
  {}

  ~NodeDevBlock()
  {}

private:
  // Assignment operator (autogen)
  NodeDevBlock & operator = (const NodeDevBlock & right);

public:
  // clear data for reuse of this object
  void clear();

  void addNode(const std::string&);
  std::vector<std::string> & get_NodeList();
  const std::vector<std::string> & get_NodeList() const;
  void set_NodeList(const std::vector<std::string> & nList);

  Device::InstanceBlock & getDevBlock() { return devBlock_; }
  const Device::InstanceBlock & getDevBlock() const { return devBlock_; }

  bool isDevice() const { return devBlock_.getInstanceName() != ""; }

protected:
  std::vector<std::string>       nodeList_;
  Device::InstanceBlock         devBlock_;
};

} // namespace Topo
} // namespace Xyce

#endif
