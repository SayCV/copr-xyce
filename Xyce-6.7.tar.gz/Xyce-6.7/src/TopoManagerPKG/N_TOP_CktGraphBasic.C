//-----------------------------------------------------------------------------
// Copyright Notice
//
//   Copyright 2002 Sandia Corporation. Under the terms
//   of Contract DE-AC04-94AL85000 with Sandia Corporation, the U.S.
//   Government retains certain rights in this software.
//
//    Xyce(TM) Parallel Electrical Simulator
//    Copyright (C) 2002-2017 Sandia Corporation
//
//    This program is free software: you can redistribute it and/or modify
//    it under the terms of the GNU General Public License as published by
//    the Free Software Foundation, either version 3 of the License, or
//    (at your option) any later version.
//
//    This program is distributed in the hope that it will be useful,
//    but WITHOUT ANY WARRANTY; without even the implied warranty of
//    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//    GNU General Public License for more details.
//
//    You should have received a copy of the GNU General Public License
//    along with this program.  If not, see <http://www.gnu.org/licenses/>.
//-----------------------------------------------------------------------------

//-------------------------------------------------------------------------
//
// Purpose        :
//
// Special Notes  :
//
// Creator        : Robert J. Hoekstra, SNL, Parallel Computational Sciences
//
// Creation Date  : 08/10/06
//
//
//
//
//-------------------------------------------------------------------------

#include <Xyce_config.h>

#include <iostream>

#include <N_DEV_DeviceBlock.h>
#include <N_ERH_ErrorMgr.h>
#include <N_PDS_Manager.h>
#include <N_TOP_CktGraphBasic.h>
#include <N_TOP_CktNode.h>
#include <N_TOP_CktNode_Dev.h>
#include <N_TOP_Indexor.h>
#include <N_TOP_Misc.h>
#include <N_UTL_FeatureTest.h>
#include <N_UTL_Functors.h>
#include <N_UTL_IndexPair.h>

#include <Teuchos_RCP.hpp>
using Teuchos::RCP;
using Teuchos::rcp;

namespace Xyce {
namespace Topo {

//-----------------------------------------------------------------------------
// Function      : CktGraphBasic::CktGraphBasic
// Purpose       : constructor
// Special Notes :
// Scope         : public
// Creator       : Rob Hoekstra, SNL, Parallel Computational Sciences
// Creation Date : 8/10/06
//-----------------------------------------------------------------------------
CktGraphBasic::CktGraphBasic(const int maxTries)
 : isModified_(true),
   maxTries_(maxTries)
{
}

//-----------------------------------------------------------------------------
// Function      : CktGraphBasic::CktGraphBasic
// Purpose       :
// Special Notes :
// Scope         : public
// Creator       : Rob Hoekstra, SNL, Parallel Computational Sciences
// Creation Date : 8/10/06
//-----------------------------------------------------------------------------
CktGraphBasic::CktGraphBasic(const std::string &cgID, 
   const int maxTries)
 : CktGraph(cgID),
   isModified_(true),
   maxTries_(maxTries)
{
}

//-----------------------------------------------------------------------------
// Function      : CktGraphBasic::~CktGraphBasic()
// Purpose       : destructor
// Special Notes :
// Scope         : public
// Creator       : Rob Hoekstra, SNL, Parallel Computational Sciences
// Creation Date : 8/10/06
//-----------------------------------------------------------------------------
CktGraphBasic::~CktGraphBasic()
{
  CktNodeList::iterator it_nL = BFSNodeList_.begin();
  CktNodeList::iterator it_nL_end = BFSNodeList_.end();
  for( ; it_nL != it_nL_end; ++it_nL )
    delete *it_nL;
}

//-----------------------------------------------------------------------------
// Function      : CktGraphBasic::InsertNode
// Purpose       : Inserts graph node for ckt node if does not exist
// Special Notes :
// Scope         : public
// Creator       : Rob Hoekstra, SNL, Parallel Computational Sciences
// Creation Date : 8/10/06
//-----------------------------------------------------------------------------
void CktGraphBasic::InsertNode(CktNode* cktnode,
                               const std::vector<NodeID> &neighborList)
{
  if (DEBUG_TOPOLOGY)
    Xyce::dout() << "Inserting Node: " << cktnode->get_id() << ", type = " << cktnode->type() << std::endl
                 << *cktnode;

  bool inserted = cktgph_.insertNode( NodeID(cktnode->get_id(),cktnode->type()), 
                                      neighborList, cktnode );
  
  if( !inserted )
  {
    //------- If node already exists, check to see if it should be
    //------- changed to be owned.

    if( cktnode->get_IsOwned() )
    {
      CktNode * cn = cktgph_.getData(NodeID(cktnode->get_id(),cktnode->type()));
      cn->set_IsOwned(true);
      cn->set_ProcNum(cktnode->get_ProcNum());
      cn->set_gID(cktnode->get_gID());
    }

    delete cktnode;
  }

  //------ Graph has been changed so traversals will change
  isModified_ = true;
}

//-----------------------------------------------------------------------------
// Function      : CktGraphBasic::FindCktNode
// Purpose       : Returns ptr to specified ckt node.
// Special Notes :
// Scope         : public
// Creator       : Rob Hoekstra, SNL, Parallel Computational Sciences
// Creation Date : 8/10/06
//-----------------------------------------------------------------------------
CktNode* CktGraphBasic::FindCktNode (const NodeID &cnID)
{
  // If the node type cannot be determined before hand, try to see if there is
  // a unique node associated with the string in cnID.
  if (cnID.second != -1)
  {
    if( cktgph_.checkKey(cnID) )
      return cktgph_.getData(cnID);
  }
  else
  {
    // Loop through all the possible node types to see if this node exists.
    // Only return it if there is one unique node.  Otherwise, this operation
    // is not well defined.
    int numFound       = 0;
    CktNode* foundNode = 0;
    for (int i         = 0; i<_NUM_NODE_TYPES; ++i)
    {
      NodeID tmpID( cnID.first, i );
      if (cktgph_.checkKey(cnID) )
      {
        foundNode      = cktgph_.getData(cnID);
        numFound++;
      }
    }
    if (numFound == 1)
      return foundNode;
  }

  return 0;
}

//-----------------------------------------------------------------------------
// Function      : CktGraphBasic::getBFSNodeList
// Purpose       : Produces list of ckt nodes in breadth first traversal order
// Special Notes :
// Scope         : public
// Creator       : Rob Hoekstra, SNL, Parallel Computational Sciences
// Creation Date : 8/10/06
//-----------------------------------------------------------------------------
CktNodeList *
CktGraphBasic::getBFSNodeList()
{
  //------- Check if list not created or graph modified

  if( BFSNodeList_.empty() || isModified_ )
  {
    //------- Include disconnected parts for graph in traversal
    int numNodes = cktgph_.numNodes();

    if( numNodes )
    {
      // Compute the graph center if the maximum number of tries to find a good
      // start node is > 1, else just generate a traversal with the first node.
      if (maxTries_ > 1)
      {
        NodeID start_node(cktgph_.getCenter( 0.33, maxTries_ ));

        //------- Produce traversal as object in albBFS_
        //------- and extract to BFSNodeList_
        cktgph_.generateBFT( start_node );
      }
      else
      {
        cktgph_.generateBFT();
      }

      const std::vector<NodeID> & bfsVec = cktgph_.getBFT();

      BFSNodeList_.clear();
      BFSNodeList_.reserve( bfsVec.size() );
      std::vector<NodeID>::const_reverse_iterator bfs_rit = bfsVec.rbegin();
      std::vector<NodeID>::const_reverse_iterator bfs_rit_end = bfsVec.rend();
      for( ; bfs_rit != bfs_rit_end; ++bfs_rit )
        BFSNodeList_.push_back( cktgph_.getData(*bfs_rit) );
    }

    isModified_ = false;
  }

  return &BFSNodeList_;
}

//-----------------------------------------------------------------------------
// Function      : CktGraphBasic::returnAdjIDs
// Purpose       : 
// Special Notes :
// Scope         : public
// Creator       : Robert Hoekstra, SNL, Parallel Computational Sciences
// Creation Date : 8/10/06
//-----------------------------------------------------------------------------
void CktGraphBasic::returnAdjIDs( const NodeID & id, std::vector<NodeID> & adj_ids )
{
  adj_ids.clear();

  const std::vector<NodeID> &adjIDs = cktgph_.getAdjacent(id);

  int numAdj = adjIDs.size();
  for( int i = 0; i < numAdj; ++i )
    if( adjIDs[i].first != "0" ) adj_ids.push_back( adjIDs[i] );
}

//-----------------------------------------------------------------------------
// Function      : CktGraphBasic::returnAdjGIDs
// Purpose       : 
// Special Notes :
// Scope         : public
// Creator       : Robert Hoekstra, SNL, Parallel Computational Sciences
// Creation Date : 8/10/06
//-----------------------------------------------------------------------------
void CktGraphBasic::returnAdjGIDs( int gid,
                                   std::vector<int> & adj_gids )
{
  adj_gids.clear();
  
  const std::vector<int>& adjIndices = cktgph_.getAdjacentRow( gIDtoIndex_[ gid ] );

  for( size_t i = 0; i < adjIndices.size(); ++i )
  {
    if( indexToGID_[ adjIndices[i] ] != -1 ) 
      adj_gids.push_back( indexToGID_[ adjIndices[i] ] );
  }
}

//-----------------------------------------------------------------------------
// Function      : CktGraphBasic::returnAdjGIDs
// Purpose       : 
// Special Notes :
// Scope         : public
// Creator       : Robert Hoekstra, SNL, Parallel Computational Sciences
// Creation Date : 8/10/06
//-----------------------------------------------------------------------------
int CktGraphBasic::numAdjNodes( int gid )
{
  int count = 0; 
  const std::vector<int>& adjIndices = cktgph_.getAdjacentRow( gIDtoIndex_[ gid ] );

  for( size_t i = 0; i < adjIndices.size(); ++i )
  {
    if( indexToGID_[ adjIndices[i] ] != -1 ) 
      count++;
  }

  return count;
}

//-----------------------------------------------------------------------------
// Function      : CktGraphBasic::returnAdjNodes
// Purpose       : Loop over adjacent nodes creating ordered lists
//                 of neighboring global id's and owning proc nums
// Special Notes :
// Scope         : public
// Creator       : Robert Hoekstra, SNL, Parallel Computational Sciences
// Creation Date : 8/10/06
//-----------------------------------------------------------------------------
void
CktGraphBasic::returnAdjNodes(
  const NodeID &        id,
  std::vector<int> &    gidList,
  std::vector<int> &    svGIDList,
  std::vector<int> &    procList,
  std::list<NodeID> &   idList )
{
  if( cktgph_.checkKey(id) )
  {
    const std::vector<NodeID> &adjIDs = cktgph_.getAdjacent(id);

    int numAdj = adjIDs.size();
    for( int i = 0; i < numAdj; ++i )
    {
      if ((cktgph_.getData(adjIDs[i]))->get_gID() != -1)
      {
        CktNode * cktnode = cktgph_.getData(adjIDs[i]);
        gidList.push_back( cktnode->get_gID() );
        idList.push_back( NodeID(cktnode->get_id(),cktnode->type()) );

        svGIDList.insert( svGIDList.end(),
        cktnode->get_SolnVarGIDList().begin(),
        cktnode->get_SolnVarGIDList().end() );

        procList.push_back( cktnode->get_ProcNum() );
      }
    }
  }
}

//-----------------------------------------------------------------------------
// Function      : CktGraphBasic::returnAdjNodesWithGround
// Purpose       : Loop over adjacent nodes creating ordered lists
//                 of neighboring global id's
// Special Notes :
// Scope         : public
// Creator       : Robert Hoekstra, SNL, Parallel Computational Sciences
// Creation Date : 8/10/06
//-----------------------------------------------------------------------------
void
CktGraphBasic::returnAdjNodesWithGround(
  const NodeID &        id,
  std::vector<int> &    gidList,
  std::vector<int> &    svGIDList)
{
  if (cktgph_.checkKey(id))
  {
    const std::vector<NodeID> &adjIDs = cktgph_.getAdjacent(id);

    int numAdj = adjIDs.size();
    for (int i = 0; i < numAdj; ++i)
    {
      CktNode * cktnode = cktgph_.getData(adjIDs[i]);
      gidList.push_back( cktnode->get_gID() );
      svGIDList.insert( svGIDList.end(), cktnode->get_SolnVarGIDList().begin(), cktnode->get_SolnVarGIDList().end() );
    }
  }
}

//-----------------------------------------------------------------------------
// Function      : CktGraphBasic::registerGIDswithDevs
// Purpose       : Loop over nodes and register int and ext global ids
//                 with each device
// Special Notes :
// Scope         : public
// Creator       : Robert Hoekstra, SNL, Parallel Computational Sciences
// Creation Date : 8/10/06
//-----------------------------------------------------------------------------
void CktGraphBasic::registerGIDswithDevs()
{
  std::vector<int> gidList, svGIDList, ownedList;
  IndexPairVector internal, external;

  const CktNodeList * tmpNodeList = getBFSNodeList();

  // loop over nodes:
  for (CktNodeList::const_iterator it_nL = tmpNodeList->begin(), it_nL_end = tmpNodeList->end(); it_nL != it_nL_end; ++it_nL)
  {
    int type = (*it_nL)->type();
    if (type == _DNODE)
    {
      //------- Clear lists for each node
      gidList.clear();
      svGIDList.clear();
      ownedList.clear();

      //------  Generate global id list for external variables

      // initialize the local gidList, the svGIDList.
      returnAdjNodesWithGround( NodeID((*it_nL)->get_id(),(*it_nL)->type()), gidList, svGIDList );

      for (std::vector<int>::const_iterator it_iL = gidList.begin(), end_iL = gidList.end(); it_iL != end_iL; ++it_iL )
        if( *it_iL != -1 )
          ownedList.push_back(1);
        else
          ownedList.push_back(0);

      //------- Push list of int. and ext. global id's to ckt node

      // first arg. is internal variable list
      // 2nd   arg. is external variable list
      internal.clear();
      external.clear();

      if ((*it_nL)->get_IsOwned())
        for (std::vector<int>::const_iterator it_iL = (*it_nL)->get_SolnVarGIDList().begin(), end_iL = (*it_nL)->get_SolnVarGIDList().end(); it_iL != end_iL; ++it_iL )
          internal.push_back( IndexPair( *it_iL, 1 ) );
      else
        for (std::vector<int>::const_iterator it_iL = (*it_nL)->get_SolnVarGIDList().begin(), end_iL = (*it_nL)->get_SolnVarGIDList().end(); it_iL != end_iL; ++it_iL )
          internal.push_back( IndexPair( *it_iL, 0 ) );

      int offset = (*it_nL)->get_Offset();
      for (std::vector<int>::const_iterator it_iL = svGIDList.begin(), end_iL = svGIDList.end(), it_iL2 = ownedList.begin(); it_iL != end_iL; ++it_iL )
        if (offset)
          external.push_back( IndexPair( *it_iL, *it_iL2, offset ) );
        else
          external.push_back( IndexPair( *it_iL, *it_iL2 ) );

      (*it_nL)->registerGIDswithDev(internal, external);
      (*it_nL)->set_ExtSolnVarGIDList( svGIDList );
    }
  }
}

//-----------------------------------------------------------------------------
// Function      : CktGraphBasic::registerStateGIDswithDevs
// Purpose       : Loop over nodes and register int and ext global ids
//                 with each device
// Special Notes :
// Scope         : public
// Creator       : Robert Hoekstra, SNL, Parallel Computational Sciences
// Creation Date : 8/10/06
//-----------------------------------------------------------------------------
void CktGraphBasic::registerStateGIDswithDevs()
{
  std::vector<int>::const_iterator it_iL, end_iL;
  IndexPairVector tmpIPList1;

  CktNodeList * tmpNodeList = getBFSNodeList();

  CktNodeList::const_iterator it_nL = tmpNodeList->begin();
  CktNodeList::const_iterator it_nL_end = tmpNodeList->end();

  // loop over nodes:
  for( ; it_nL != it_nL_end; ++it_nL )
  {
    int type = (*it_nL)->type();
    if (type == _DNODE)
    {
      tmpIPList1.clear();

      it_iL = (*it_nL)->get_StateVarGIDList().begin();
      end_iL = (*it_nL)->get_StateVarGIDList().end();
      if( (*it_nL)->get_IsOwned() )
      {
        for( ; it_iL != end_iL; ++it_iL )
          tmpIPList1.push_back( IndexPair( *it_iL, 1 ) );
      }
      else
      {
        for( ; it_iL != end_iL; ++it_iL )
          tmpIPList1.push_back( IndexPair( *it_iL, 0 ) );
      }

      //------- Push list of state global id's to ckt node
      (*it_nL)->registerStateGIDswithDev( tmpIPList1 );
    }
  }
}

//-----------------------------------------------------------------------------
// Function      : CktGraphBasic::registerStoreGIDswithDevs
// Purpose       : Loop over nodes and register int and ext global ids
//                 with each device
// Special Notes :
// Scope         : public
// Creator       : Eric Keiter, SNL
// Creation Date : 
//-----------------------------------------------------------------------------
void CktGraphBasic::registerStoreGIDswithDevs()
{
  std::vector<int>::const_iterator it_iL, end_iL;
  IndexPairVector tmpIPList1;

  CktNodeList * tmpNodeList = getBFSNodeList();

  CktNodeList::const_iterator it_nL = tmpNodeList->begin();
  CktNodeList::const_iterator it_nL_end = tmpNodeList->end();

  // loop over nodes:
  for( ; it_nL != it_nL_end; ++it_nL )
  {
    int type = (*it_nL)->type();
    if (type == _DNODE)
    {
      tmpIPList1.clear();

      it_iL = (*it_nL)->get_StoreVarGIDList().begin();
      end_iL = (*it_nL)->get_StoreVarGIDList().end();
      if( (*it_nL)->get_IsOwned() )
      {
        for( ; it_iL != end_iL; ++it_iL )
        tmpIPList1.push_back( IndexPair( *it_iL, 1 ) );
      }
      else
      {
        for( ; it_iL != end_iL; ++it_iL )
          tmpIPList1.push_back( IndexPair( *it_iL, 0 ) );
      }

      //------- Push list of store global id's to ckt node
      (*it_nL)->registerStoreGIDswithDev( tmpIPList1 );
    }
  }
}

//-----------------------------------------------------------------------------
// Function      : CktGraphBasic::registerLIDswithDevs
// Purpose       : Loop over nodes and register int and ext local ids
//                 with each device
// Special Notes :
// Scope         : public
// Creator       : Robert Hoekstra, SNL, Parallel Computational Sciences
// Creation Date : 8/10/06
//-----------------------------------------------------------------------------
void CktGraphBasic::registerLIDswithDevs( Indexor & indexor )
{
  std::vector<int> gidList, svGIDList, ownedList;
  std::vector<int>::const_iterator it_iL, end_iL, it_iL2, it_iL3;
  std::vector<int> intVec, extVec;

  CktNodeList * tmpNodeList = getBFSNodeList();

  CktNodeList::const_iterator it_nL = tmpNodeList->begin();
  CktNodeList::const_iterator it_nL_end = tmpNodeList->end();

  // loop over nodes:
  for( ; it_nL != it_nL_end; ++it_nL )
  {
    int type = (*it_nL)->type();
    if (type == _DNODE)
    {
      //------- Clear lists for each node
      gidList.clear();
      svGIDList.clear();
      ownedList.clear();

      //------  Generate global id list for external variables

      // initialize the local gidList, the svGIDList and the procList.
      returnAdjNodesWithGround( NodeID((*it_nL)->get_id(),(*it_nL)->type()), gidList, svGIDList );

      for( it_iL=gidList.begin(),end_iL=gidList.end(); it_iL!=end_iL; ++it_iL )
      {
        if( *it_iL != -1 ) ownedList.push_back(1);
        else               ownedList.push_back(0);
      }

      //------- Push list of int. and ext. local id's to ckt node

      // first arg. is internal variable list
      // 2nd   arg. is external variable list

      it_iL = (*it_nL)->get_SolnVarGIDList().begin();
      end_iL = (*it_nL)->get_SolnVarGIDList().end();

      intVec.assign( it_iL, end_iL );

      bool success = indexor.globalToLocal(Parallel::SOLUTION_OVERLAP_GND, intVec);

      it_iL = svGIDList.begin();
      end_iL = svGIDList.end();

      extVec.assign( it_iL, end_iL );

      success = success && indexor.globalToLocal(Parallel::SOLUTION_OVERLAP_GND, extVec);

      (*it_nL)->registerLIDswithDev( intVec, extVec );
    }
  }
}

//-----------------------------------------------------------------------------
// Function      : CktGraphBasic::registerStateLIDswithDevs
// Purpose       : Loop over nodes and register int and ext global ids
//                 with each device
// Special Notes :
// Scope         : public
// Creator       : Robert Hoekstra, SNL, Parallel Computational Sciences
// Creation Date : 8/10/06
//-----------------------------------------------------------------------------
void CktGraphBasic::registerStateLIDswithDevs( Indexor & indexor )
{
  std::vector<int>::const_iterator it_iL, end_iL;
  std::vector<int> stateVec;

  CktNodeList * tmpNodeList = getBFSNodeList();

  CktNodeList::const_iterator it_nL = tmpNodeList->begin();
  CktNodeList::const_iterator it_nL_end = tmpNodeList->end();

  // loop over nodes:
  for( ; it_nL != it_nL_end; ++it_nL )
  {
    int type = (*it_nL)->type();
    if (type == _DNODE)
    {
      it_iL = (*it_nL)->get_StateVarGIDList().begin();
      end_iL = (*it_nL)->get_StateVarGIDList().end();

      stateVec.assign( it_iL, end_iL );

      indexor.globalToLocal( Parallel::STATE_OVERLAP, stateVec );

      //------- Push list of state global id's to ckt node
      (*it_nL)->registerStateLIDswithDev( stateVec );
    }
  }
}

//-----------------------------------------------------------------------------
// Function      : CktGraphBasic::registerStoreLIDswithDevs
// Purpose       : Loop over nodes and register int and ext global ids
//                 with each device
// Special Notes :
// Scope         : public
// Creator       : Eric Keiter, SNL
// Creation Date : 
//-----------------------------------------------------------------------------
void CktGraphBasic::registerStoreLIDswithDevs( Indexor & indexor )
{
  std::vector<int>::const_iterator it_iL, end_iL;
  std::vector<int> storeVec;

  CktNodeList * tmpNodeList = getBFSNodeList();

  CktNodeList::const_iterator it_nL = tmpNodeList->begin();
  CktNodeList::const_iterator it_nL_end = tmpNodeList->end();

  // loop over nodes:
  for( ; it_nL != it_nL_end; ++it_nL )
  {
    int type = (*it_nL)->type();
    if (type == _DNODE)
    {

      it_iL = (*it_nL)->get_StoreVarGIDList().begin();
      end_iL = (*it_nL)->get_StoreVarGIDList().end();

      storeVec.assign( it_iL, end_iL );

      indexor.globalToLocal(Parallel::STORE_OVERLAP, storeVec);

      //------- Push list of store global id's to ckt node
      (*it_nL)->registerStoreLIDswithDev( storeVec );
    }
  }
}

//-----------------------------------------------------------------------------
// Function      : CktGraphBasic::registerBranchDataLIDswithDevs
// Purpose       : Loop over nodes and register lids for branch data vec.
// Special Notes :
// Scope         : public
// Creator       : Eric Keiter, SNL
// Creation Date : 
//-----------------------------------------------------------------------------
void CktGraphBasic::registerBranchDataLIDswithDevs( Indexor & indexor )
{
  std::vector<int>::const_iterator it_iL, end_iL;
  std::vector<int> branchDataVec;

  CktNodeList * tmpNodeList = getBFSNodeList();

  CktNodeList::const_iterator it_nL = tmpNodeList->begin();
  CktNodeList::const_iterator it_nL_end = tmpNodeList->end();

  // loop over nodes:
  for( ; it_nL != it_nL_end; ++it_nL )
  {
    int type = (*it_nL)->type();
    if (type == _DNODE)
    {

      it_iL = (*it_nL)->get_LeadCurrentVarGIDList().begin();
      end_iL = (*it_nL)->get_LeadCurrentVarGIDList().end();

      branchDataVec.assign( it_iL, end_iL );

      indexor.globalToLocal(Parallel::LEADCURRENT_OVERLAP, branchDataVec);

      //------- Push list of store global id's to ckt node
      (*it_nL)->registerLeadCurrentLIDswithDev( branchDataVec );
    }
  }
}



//-----------------------------------------------------------------------------
// Function      : CktGraphBasic::registerDepLIDswithDevs
// Purpose       : Loop over nodes and register dep local ids
//                 with each device
// Special Notes :
// Scope         : public
// Creator       : Robert Hoekstra, SNL, Parallel Computational Sciences
// Creation Date : 8/10/06
//-----------------------------------------------------------------------------
void CktGraphBasic::registerDepLIDswithDevs( Indexor & indexor )
{
  std::vector< std::vector<int> > indexVec;

  CktNodeList * tmpNodeList = getBFSNodeList();

  CktNodeList::iterator it_nL = tmpNodeList->begin();
  CktNodeList::iterator it_nL_end = tmpNodeList->end();

  // loop over nodes:
  for( ; it_nL != it_nL_end; ++it_nL )
  {
    int type = (*it_nL)->type();
    if (type == _DNODE)
    {
      // Register solution LIDs.
      if ( (*it_nL)->depSolnVarCount() )
      {
        (*it_nL)->get_DepSolnGIDVec( indexVec );

        for( unsigned int i = 0; i < indexVec.size(); ++i )
          indexor.globalToLocal(Parallel::SOLUTION_OVERLAP_GND, indexVec[i] );

        (*it_nL)->registerDepLIDswithDev( indexVec );
      }

      // Register state LIDs.
      if ( (*it_nL)->depStateVarCount() )
      {
        (*it_nL)->get_DepStateGIDVec( indexVec );

        for( unsigned int i = 0; i < indexVec.size(); ++i )
          indexor.globalToLocal(Parallel::STATE_OVERLAP, indexVec[i]);

        (*it_nL)->registerDepStateLIDswithDev( indexVec );
      }

      // Register store LIDs.
      if ( (*it_nL)->depStoreVarCount() )
      {
        (*it_nL)->get_DepStoreGIDVec( indexVec );
  
        for( unsigned int i = 0; i < indexVec.size(); ++i )
          indexor.globalToLocal(Parallel::STORE_OVERLAP, indexVec[i]);

        (*it_nL)->registerDepStoreLIDswithDev( indexVec );
      }
    }
  }
}

//-----------------------------------------------------------------------------
// Function      : CktGraphBasic::registerJacLIDswithDevs
// Purpose       : Loop over nodes and register jacobian local ids
//                 with each device
// Special Notes :
// Scope         : public
// Creator       : Robert Hoekstra, SNL, Parallel Computational Sciences
// Creation Date : 8/10/06
//-----------------------------------------------------------------------------
void CktGraphBasic::registerJacLIDswithDevs( Indexor & indexor )
{
  std::vector< std::vector<int> > stampVec;

  indexor.setupAcceleratedMatrixIndexing(Parallel::JACOBIAN_OVERLAP_GND);

  CktNodeList * tmpNodeList = getBFSNodeList();

  CktNodeList::const_iterator it_nL = tmpNodeList->begin();
  CktNodeList::const_iterator it_nL_end = tmpNodeList->end();

  // loop over nodes:
  for( ; it_nL != it_nL_end; ++it_nL )
  {
    CktNode & cn = **it_nL;
    if( cn.type() == _DNODE )
    {
      const std::vector<int> & intGIDs = cn.get_SolnVarGIDList();
      const std::vector<int> & extGIDs = cn.get_ExtSolnVarGIDList();
      const std::vector<int> & depGIDs = cn.get_DepSolnGIDJacVec();
      std::vector<int> gids( intGIDs.size() + extGIDs.size() + depGIDs.size() );
      std::copy( extGIDs.begin(), extGIDs.end(), gids.begin() );
      std::copy( intGIDs.begin(), intGIDs.end(), gids.begin() + extGIDs.size() );
      std::copy( depGIDs.begin(), depGIDs.end(), gids.begin() + extGIDs.size() + intGIDs.size() );

      stampVec = cn.jacobianStamp();

      int numRows = stampVec.size();
      for( int i = 0; i < numRows; ++i )
      {
        int numCols = stampVec[i].size();
        for( int j = 0; j < numCols; ++j )
          stampVec[i][j] = gids[ stampVec[i][j] ];
      }

      std::vector<int> counts(3);
      counts[0] = extGIDs.size();
      counts[1] = intGIDs.size();
      counts[2] = depGIDs.size();
      cn.registerGIDDataWithDev( counts, gids, stampVec );

      indexor.matrixGlobalToLocal(Parallel::JACOBIAN_OVERLAP_GND, gids, stampVec );

      cn.registerJacLIDswithDev( stampVec );
    }
  }

  indexor.deleteAcceleratedMatrixIndexing();
}

//-----------------------------------------------------------------------------
// Function      : CktGraphBasic::regenerateGIDNodeMap
// Purpose       : Redo global index node map
// Special Notes : Should find a way to automate this
// Scope         : public
// Creator       : Robert Hoekstra, SNL, Parallel Computational Sciences
// Creation Date : 8/10/06
//-----------------------------------------------------------------------------
void CktGraphBasic::regenerateGIDNodeMap()
{
  // Clear the map, just in case this was done before.
  indexToGID_.clear();
  gIDtoIndex_.clear();

  CktNodeList::const_iterator it_cnL = BFSNodeList_.begin();
  CktNodeList::const_iterator it_cnL_end = BFSNodeList_.end();
  for( ; it_cnL != it_cnL_end ; ++it_cnL )
  {
    int index = cktgph_.getIndex( NodeID((*it_cnL)->get_id(),(*it_cnL)->type()) );
    int gid = (*it_cnL)->get_gID();
    indexToGID_[ index ] = gid;
    gIDtoIndex_[ gid ] = index;
  }
}

//-----------------------------------------------------------------------------
// Function      : CktGraphBasic::replaceNode
// Purpose       : replace supernode two nodes
// Special Notes : 
// Scope         : public
// Creator       : Richard Schiek, Electrical and Microsystems Modeling
// Creation Date : 2/10/10
//-----------------------------------------------------------------------------
CktNode * CktGraphBasic::replaceNode( const NodeID nodeToBeReplaced, 
                                                  const NodeID nodeToKeep )
{
  // procedure is as follows:
  // 1. get the adjacency of both nodes
  // 2. combine to the two adjacencies
  // 3. set nodeToKeep's adjacency to what we found in step 2.
  // 4. tell the graph to replace any other adjacencies that refer to nodeToBeReplaced with nodeToKeep
  // 5. Remove nodeToBeReplaced and return it's associated CktNode object
  
  // look up key for these nodes in graph.
  CktNode * nodeToBeReplacedCktNodePtr = FindCktNode( nodeToBeReplaced );
  
  // 1. get the adjacency of both nodes
  std::vector<NodeID> adjNodeToBeReplaced, adjNodeToKeep;
  returnAdjIDs( nodeToBeReplaced, adjNodeToBeReplaced );
  returnAdjIDs( nodeToKeep, adjNodeToKeep );
  
  /*
  // 2. combine to the two adjacencies
  // loop over ajdNodeToBeReplaced and add any nodes not found in ajdNodeToKeep to ajdNodeToKeep
  std::vector<std::string>::iterator currNodeToBeReplacedAdjItr = adjNodeToBeReplaced.begin();
  std::vector<std::string>::iterator endNodeToBeReplacedAdjItr = adjNodeToBeReplaced.end();
  while( currNodeToBeReplacedAdjItr != endNodeToBeReplacedAdjItr )
  {
    std::vector<std::string>::iterator beginNodeToKeepAdjItr = ajdNodeToKeep.begin();
    std::vector<std::string>::iterator endNodeToKeepAdjItr = ajdNodeToKeep.end();
    std::vector<std::string>::iterator locationNodeToKeepAdjItr = find( beginNodeToKeepAdjItr, endNodeToKeepAdjItr, *currNodeToBeReplacedAdjItr);
    if( locationNodeToKeepAdjItr == endNodeToKeepAdjItr )
    {
      // this adjacency was not in the new list.  So add it in
      ajdNodeToKeep.push_back( *currNodeToBeReplacedAdjItr );
    }
    currNodeToBeReplacedAdjItr++;
  }
  
  
  // 3. set nodeToKeep's adjacency to what we found in step 2.
  cktgph_.setAdjacent( nodeToBeReplaced, nodeToKeep, ajdNodeToKeep );
  */
  cktgph_.addToAdjacent( nodeToBeReplaced, nodeToKeep, adjNodeToBeReplaced );
  
  // 4. tell the graph to replace any other adjacencies that refer to nodeToBeReplaced with nodeToKeep
  cktgph_.replaceAdjacent( nodeToBeReplaced, nodeToKeep );
  
  // 5. Remove nodeToBeReplaced and return it's associated CktNode object
  cktgph_.removeKey( nodeToBeReplaced );

  // changed ordering so set isModified_ flag
  isModified_ = true;
  
  return nodeToBeReplacedCktNodePtr;
}


//-----------------------------------------------------------------------------
// Function      : CktGraphBasic::removeRedundantDevices
// Purpose       : remove any device nodes that are only connected to one ckt node
// Special Notes : 
// Scope         : public
// Creator       : Richard Schiek, Electrical and Microsystems Modeling
// Creation Date : 2/10/10
//-----------------------------------------------------------------------------
void CktGraphBasic::removeRedundantDevices(std::vector< CktNode * > & removedDevices)
{
  std::ostringstream outputStringStream;
  // Collect the deviceIDs for all the devices to be removed from the graph
  std::vector< NodeID> deviceIDs;
  const Graph::Data1Map &dataMap = cktgph_.getData1Map();

  Graph::Data1Map::const_iterator currentCktNodeItr = dataMap.begin();
  Graph::Data1Map::const_iterator endCktNodeItr = dataMap.end();
  while( currentCktNodeItr != endCktNodeItr )
  {
    if( ((*currentCktNodeItr).second)->type() == _DNODE )
    {
      CktNode_Dev * cktNodeDevPtr = dynamic_cast<CktNode_Dev*>((*currentCktNodeItr).second);
      const Device::InstanceBlock *deviceInstanceBlockPtr = cktNodeDevPtr->deviceInstanceBlock();
      if (deviceInstanceBlockPtr)
      {
        // have a valid device.
        NodeID deviceID = (*currentCktNodeItr).first;
        int deviceIndex = cktgph_.getIndex( deviceID );
        const std::vector<int> &adjacentIDs = cktgph_.getAdjacentRow( deviceIndex );
        int numAdjIDs = adjacentIDs.size(); 
 
        bool removeDevice=false;
        if( numAdjIDs == 2 )
        {
          if( adjacentIDs[0] == adjacentIDs[1] )
            removeDevice=true;
        }
        else if( numAdjIDs == 3 )
        {
          if( ( adjacentIDs[0] == adjacentIDs[1] ) && (adjacentIDs[1] == adjacentIDs[2]) )
            removeDevice=true;
        }
        else if( numAdjIDs == 4 )
        {
          if( ( adjacentIDs[0] == adjacentIDs[1] ) && (adjacentIDs[1] == adjacentIDs[2])
            && (adjacentIDs[2] == adjacentIDs[3]) )
            removeDevice=true;
        }
        if( removeDevice )
        {
          deviceIDs.push_back(deviceID);
          removedDevices.push_back((*currentCktNodeItr).second);
        }
      }
      else
      {
        // issue fatal error as this case shouldn't occur
        Report::DevelFatal() << "Topology::removeRedundantDevices() null Device Instance Block pointer.";
      }
    }
    currentCktNodeItr++;
  }

  // If there are any devices to remove, remove them from the graph and mark the object as modified.
  if( removedDevices.size() > 0 )
  {
    cktgph_.removeKeys( deviceIDs );

    // After the devices are removed, check the graph to see if any singletons were created.
    // These are most likely ghost nodes that connected the removed devices to the rest of the circuit.
    // NOTE:  This can be a real issue in practice, so don't remove this search.
    std::vector< NodeID> singletonIDs = cktgph_.getSingletons();
    if (singletonIDs.size() > 0)
      cktgph_.removeKeys( singletonIDs );

    isModified_=true;
  }

}

//-----------------------------------------------------------------------------
// Function      : CktGraphBasic::put
// Purpose       : Allows virtual override of operator<<
// Special Notes :
// Scope         : public
// Creator       : Robert Hoekstra, SNL, Parallel Computational Sciences
// Creation Date : 8/10/06
//-----------------------------------------------------------------------------
std::ostream& CktGraphBasic::put(std::ostream& os) const
{
  int i = 0;

  CktNodeList::const_iterator it_cnL = BFSNodeList_.begin();
  CktNodeList::const_iterator it_cnL_end = BFSNodeList_.end();
  for( ; it_cnL != it_cnL_end ; ++it_cnL, ++i )
  {
    os << "[" << i << "]:" << **it_cnL << std::endl;
  }

  // Print out information about the circuit graph.
  cktgph_.print( os );

  return os;
}

} // namespace Topo
} // namespace Xyce
