//-----------------------------------------------------------------------------
// Copyright Notice
//
//   Copyright 2002 Sandia Corporation. Under the terms
//   of Contract DE-AC04-94AL85000 with Sandia Corporation, the U.S.
//   Government retains certain rights in this software.
//
//    Xyce(TM) Parallel Electrical Simulator
//    Copyright (C) 2002-2017 Sandia Corporation
//
//    This program is free software: you can redistribute it and/or modify
//    it under the terms of the GNU General Public License as published by
//    the Free Software Foundation, either version 3 of the License, or
//    (at your option) any later version.
//
//    This program is distributed in the hope that it will be useful,
//    but WITHOUT ANY WARRANTY; without even the implied warranty of
//    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//    GNU General Public License for more details.
//
//    You should have received a copy of the GNU General Public License
//    along with this program.  If not, see <http://www.gnu.org/licenses/>.
//-----------------------------------------------------------------------------

//-------------------------------------------------------------------------
//
// Purpose        :
//
// Special Notes  :
//
// Creator        : Robert J. Hoekstra, SNL, Parallel Computational Sciences
//
// Creation Date  : 05/26/00
//
//
//
//
//-------------------------------------------------------------------------

#include <Xyce_config.h>

#include <iostream>
#include <numeric>
#include <assert.h>

#include <N_ERH_ErrorMgr.h>
#include <N_IO_CmdParse.h>
#include <N_PDS_Comm.h>
#include <N_PDS_Manager.h>
#include <N_PDS_Migrate.h>
#include <N_PDS_Node.h>
#include <N_PDS_ParMap.h>
#include <N_TOP_CktGraph.h>
#include <N_TOP_CktNode.h>
#include <N_TOP_CktNode_Dev.h>
#include <N_TOP_Misc.h>
#include <N_TOP_SerialLSUtil.h>
#include <N_TOP_Topology.h>
#include <N_UTL_FeatureTest.h>
#include <N_UTL_OptionBlock.h>

#include <Epetra_Util.h>
#include <Teuchos_Utils.hpp>

namespace Xyce {
namespace Topo {

//-----------------------------------------------------------------------------
// Function      : SerialLSUtil::SerialLSUtil
// Purpose       : constructor
// Special Notes :
// Scope         : public
// Creator       : Eric Keiter  SNL, Parallel Computational Sciences
// Creation Date : 5/25/05
//-----------------------------------------------------------------------------
SerialLSUtil::SerialLSUtil(
  Topology &            topology,
  const IO::CmdParse &  command_line,
  IO::HangingResistor & hanging_resistor,
  N_PDS_Manager &       pds_manager)
  : Linear::QueryUtil(),
    topology_(topology),
    commandLine_ (command_line),
    hangingResistor_(hanging_resistor),
    pdsManager_(pds_manager),
    numGlobalNodes_(0),
    numGlobalRows_(0),
    numGlobalStateVars_(0),
    numGlobalStoreVars_(0),
    numGlobalLeadCurrentVars_(0),
    numGlobalNZs_(0)
{
}

//-----------------------------------------------------------------------------
// Function      : SerialLSUtil::operator<<
// Purpose       : generate utility with reference to topology
// Special Notes :
// Scope         : public
// Creator       : Rob Hoekstra, SNL, Parallel Computational Sciences
// Creation Date : 6/15/00
//-----------------------------------------------------------------------------
std::ostream & operator<< (std::ostream & os, const SerialLSUtil & tlsu )
{
  os << "Serial Topology LS Utility" << std::endl;
  os << "-------------------" << std::endl;
  os << "Num Global Nodes: " << tlsu.numGlobalNodes_ << std::endl;
  os << "Num Global Rows: " << tlsu.numGlobalRows_ << std::endl;

  os << "Num Global State Vars: " << tlsu.numGlobalStateVars_ << std::endl;

  os << "Num Global Store Vars: " << tlsu.numGlobalStoreVars_ << std::endl;

  os << "Num Global LeadCurrent Vars: " << tlsu.numGlobalLeadCurrentVars_ << std::endl;

  os << "Num Global NZs: " << tlsu.numGlobalNZs_ << std::endl;

  os << "Node Array: ";
  for( int i = 0; i < tlsu.numGlobalNodes_; ++i )
    os << tlsu.nodeList_GID_[i] << " ";
  os << std::endl;

  os << "GID Array: ";
  for( int i = 0; i < tlsu.numGlobalRows_; ++i )
    os << tlsu.rowList_GID_[i] << " ";
  os << std::endl;

  os << "State GID Array: ";
  for( int i = 0; i < tlsu.numGlobalStateVars_; ++i )
    os << tlsu.rowList_StateGID_[i] << " ";
  os << std::endl;

  os << "Store GID Array: ";
  for( int i = 0; i < tlsu.numGlobalStoreVars_; ++i )
    os << tlsu.rowList_StoreGID_[i] << " ";
  os << std::endl;

  os << "LeadCurrent GID Array: ";
  for( int i = 0; i < tlsu.numGlobalLeadCurrentVars_; ++i )
    os << tlsu.rowList_LeadCurrentGID_[i] << " ";
  os << std::endl;

  os << "NZ Array: ";
  for( int i = 0; i < tlsu.numGlobalRows_; ++i )
    os << tlsu.rowList_NumNZs_[i] << " ";
  os << std::endl;

  os << "Col Index Array: " << std::endl;
  for( int i = 0; i < tlsu.numGlobalRows_; ++i )
  {
    os << tlsu.rowList_GID_[i] << ": ";
    for( std::vector<int>::const_iterator it_iL = tlsu.rowList_ColList_[i].begin();
	it_iL != tlsu.rowList_ColList_[i].end(); ++it_iL )
      os << (*it_iL) << " ";
    os << std::endl;
  }

  return os;
}

//-----------------------------------------------------------------------------
// Function      : SerialLSUtil::setupRowCol
// Purpose       : Setup row/col data for linear solver including reorder
// Special Notes :
// Scope         : public
// Creator       : Rob Hoekstra, SNL, Parallel Computational Sciences
// Creation Date : 2/1/01
//-----------------------------------------------------------------------------
bool SerialLSUtil::setupRowCol()
{

  setupNodeGIDs();

  setupSolnAndStateGIDs();

  if (DEBUG_TOPOLOGY)
    Xyce::dout() << topology_ << std::endl;

  topology_.registerGIDswithDevs();

  if( checkConnectivity_ )
  { 
    //Setup index to GID map in CktGraph
    topology_.regenerateGIDNodeMap();
    
    testVoltageNodeConnectivity_();
  }

  //resolve late dependencies for devices
  topology_.resolveDependentVars();

  extractAllGIDsFromTopology();

  generateRowColData();

  bool netlistcopy = hangingResistor_.getNetlistCopy();
  std::string netlistFilename("");
  if (commandLine_.getArgumentValue("netlist") != "")
  {
    netlistFilename = commandLine_.getArgumentValue("netlist");
  }
  bool oneTermNotNoDCPath = true;
  //We use this boolean to print a different banner depending upon whether
  //resistors are being added because they are connected to only one device
  //terminal, or if they are being added because they have no DC path to
  //ground.


  //append resistors to nodes with only one terminal connection.

  if (netlistcopy && !connToOneTermIDVector_.empty())
  {
    std::string onetermres(hangingResistor_.getOneTermRes());
    topology_.addResistors(connToOneTermIDVector_,onetermres,netlistFilename,
                           oneTermNotNoDCPath);
  }


  //append resistors to nodes with no dc path to ground.
  if (netlistcopy && !noDCPathIDVector_.empty())
  {
    std::string nodcpathres(hangingResistor_.getNoDCPathRes());
    topology_.addResistors(noDCPathIDVector_,nodcpathres,netlistFilename,
                           !oneTermNotNoDCPath);

  }

  //if we've requested to produce a netlist file with resistors between
  //dangling nodes and ground, but it turns out that there aren't any
  //dangling nodes, we just need to add a ".END" to the end of the netlist
  //file copy that we produced in the I/O Interface Package (not critical).
  if (netlistcopy)
  {
    topology_.appendEndStatement(netlistFilename);
  }

  //Don't remove this!!!!!!!!
  return true;
}

//-----------------------------------------------------------------------------
// Function      : SerialLSUtil::testVoltageNodeConnectivity
// Purpose       : testing of voltage node connectivity for problems
// Special Notes : initially, just warn if a voltage node has only 1 connection
// Scope         : public
// Creator       : Rob Hoekstra, SNL, Parallel Computational Sciences
// Creation Date : 10/31/03
//-----------------------------------------------------------------------------
bool SerialLSUtil::testVoltageNodeConnectivity_()
{

  CktNodeList::const_iterator it_cnL = topology_.getOrderedNodeList().begin();
  CktNodeList::const_iterator end_cnL = topology_.getOrderedNodeList().end();

  int i, j, k;
  int gid, num_gid;
  int num_nodes = 0;
  std::vector<int> gidList;
  std::vector<int> a,b;
  std::vector<int> candidates;
  unordered_map<int, int> gid_pos;
  unordered_map<int,std::string> cName;

  bool oneTerm = hangingResistor_.getOneTerm();

  for( ; it_cnL != end_cnL; ++it_cnL )
  {
    if ((*it_cnL)->type() == _VNODE)
    {
      gid = (*it_cnL)->get_gID();
      if (gid >= 0)
      {
        num_gid = topology_.numAdjNodes( gid );
        if (num_gid <= 1)
        {
          candidates.push_back(gid);
          cName[gid] = (*it_cnL)->get_id();

          if(oneTerm)
          {
            (*it_cnL)->setTrueConnToOneTermVar();
          }
        }
        gid_pos[gid] = num_nodes++; 
      }
    }
  }

  outputTopoWarnings (candidates, cName,
                      std::string("connected to only 1 device Terminal"));

  unordered_map<int, int>::iterator gp_i;
  unordered_map<int, int>::iterator gp_end;
  std::vector<int> node_val (num_nodes,0);

  gp_i   = gid_pos.begin();
  gp_end = gid_pos.end();
  for ( ; gp_i != gp_end; ++gp_i)
  {
    node_val[(*gp_i).second] = (*gp_i).first;
  }

  it_cnL = topology_.getOrderedNodeList().begin();
  cName.clear();
  for( ; it_cnL != end_cnL; ++it_cnL )
  {
    if ((*it_cnL)->type() == _DNODE)
    {
      const std::vector<int> & lead_conn = (*it_cnL)->leadConnect();
      i = lead_conn.size();

      if (i > 0)
      {
        int gid = (*it_cnL)->get_gID();
        gidList.clear();
        topology_.returnAdjGIDs(gid, gidList);
        std::vector<int>::iterator gl = gidList.begin();
        const std::vector<int> & solnList = (*it_cnL)->get_ExtSolnVarGIDList();
        std::vector<int> GIDs;

        std::vector<int>::const_iterator sol_i   = solnList.begin();
        std::vector<int>::const_iterator sol_end = solnList.end();
        for ( ; sol_i!=sol_end; ++sol_i)
        {
          if (*sol_i == -1)
          {
            GIDs.push_back(-1);
          }
          else
          {
            GIDs.push_back(*(gl++));
          }
        }
        for (k=0 ; k<(int)lead_conn.size() ; ++k)
        {
          if (lead_conn[k] == 0)
          {
            if (GIDs[k] >= 0)
            {
              node_val[gid_pos[GIDs[k]]] = -1;
            }
            i--;
          }
        }
        for (j=1 ; j<10 ; ++j)
        {
          int last = -100;
          for (k=0 ; k<(int)lead_conn.size() ; ++k)
          {
            if (lead_conn[k] == j)
            {
              i--;
              if (last == -100)
              {
                last = GIDs[k];
              }
              else
              {
                if (last == -1)
                {
                  if (GIDs[k] >= 0)
                    node_val[gid_pos[GIDs[k]]] = -1;
                }
                else
                {
                  if (GIDs[k] >= 0)
                  {
                    a.push_back(gid_pos[last]);
                    b.push_back(gid_pos[GIDs[k]]);
                  }
                  else
                    node_val[gid_pos[last]] = -1;
                }
                if (GIDs[k] < last)
                  last = GIDs[k];
              }
            }
          }
          if (i == 0)
          {
            break;
          }
        }
        if (i != 0)
        {
          Report::DevelFatal0() << " Connectivity checker: lead index not found.  This checker is limited to devices with less than ten leads.  If you have gotten this error, and the circuit contains a device with more connections than this, you may need to run Xyce with this diagnostic turned off, via:\n  .options topology CHECK_CONNECTIVITY=0 ";
        }
      } // if (i > 0)
    } // if ((*it_cnL)->type() == _DNODE)
  } // for( ; it_cnL != end_cnL; ++it_cnL )

  bool same_local, same = false;
  while (!same)
  {
    same = true;
    same_local = false;
    while (!same_local)
    {
      same_local = true;
      for (i=0 ; i<(int)a.size() ; ++i)
      {
        if (node_val[a[i]] < node_val[b[i]])
        {
          node_val[b[i]] = node_val[a[i]];
          same_local = false;
        }
        else if (node_val[b[i]] < node_val[a[i]])
        {
          node_val[a[i]] = node_val[b[i]];
          same_local = false;
        }
      }
      if (!same_local)
        same = false;
    }
  }

  bool noDCPath = hangingResistor_.getNoDCPath();

  cName.clear();
  candidates.clear();
  for (i=0 ; i<(int)node_val.size() ; ++i)
  {
    if (node_val[i] != -1)
    {
      it_cnL = topology_.getOrderedNodeList().begin();
      for( ; it_cnL != end_cnL; ++it_cnL )
      {
        if ((*it_cnL)->type() == _VNODE)
        {
          gid = (*it_cnL)->get_gID();
          if (gid >= 0 && node_val[gid_pos[gid]] >= 0)
          {
            candidates.push_back(gid);
            const std::string & id = (*it_cnL)->get_id();
            cName[gid] = id;
            if (!(*it_cnL)->getConnToOneTermVar() && noDCPath)
              //We let 'connected to one
            {                                   //terminal' take precedence
              (*it_cnL)->setTrueNoDCPathVar();  //over 'no DC path.'  (Don't
            }                                   //want to label a node as
          }                                     //*both* being connected to only one
        }                                       //terminal and having no DC path to ground
      }                                         //since this will cause the addition of two
      break;                                    //resistors instead of just one.
    }
  }

  outputTopoWarnings (candidates, cName,
                      std::string("does not have a DC path to ground"));

  return true;
}

//-----------------------------------------------------------------------------
// Function      : SerialLSUtil::outputTopoWarnings
// Purpose       : Output warnings from node connectivity checks
// Special Notes :
// Scope         : private
// Creator       : Dave Shirley, PSSI
// Creation Date : 06/21/05
//-----------------------------------------------------------------------------
void SerialLSUtil::outputTopoWarnings(std::vector<int> & candidates,
                                    unordered_map<int,std::string> & cName,
                                    std::string errMsg)
{
  std::set<std::string> warnings;

  if (candidates.size() > 0)
  {
    for (unsigned i=0 ; i < candidates.size() ; ++i)
    {
      std::string msg("Voltage Node (" + cName[candidates[i]] + ") " + errMsg);
      warnings.insert(msg);
    }
  }

  if (!warnings.empty())
  {
    std::set<std::string>::iterator warn = warnings.begin();
    for ( ; warn != warnings.end() ; ++warn)
    {
      Report::UserWarning0() << *warn;
    }
  }
}

//-----------------------------------------------------------------------------
// Function      : SerialLSUtil::setupNodeGIDs
// Purpose       : Generate Ordering and Var GIDs.
// Special Notes :
// Scope         : public
// Creator       : Rob Hoekstra, SNL, Parallel Computational Sciences
// Creation Date : 2/22/01
//-----------------------------------------------------------------------------
bool SerialLSUtil::setupNodeGIDs()
{
  //get lists of owned and boundary/ghost node GIDs
  topology_.generateOrderedNodeList();

  nodeList_GID_.clear();

  //loop over nodes and reset all GIDs to new lex. ordering
  int newGID = 0; 
  for (CktNodeList::const_iterator it_cnL = topology_.getOrderedNodeList().begin(), end_cnL = topology_.getOrderedNodeList().end(); it_cnL != end_cnL; ++it_cnL )
  {
    if( (*it_cnL)->get_id() != "0" )
    {
      (*it_cnL)->set_gID( newGID );
      nodeList_GID_.push_back( newGID );
    
      // Increment count.
      newGID++;
    }
    else
    {
      (*it_cnL)->set_gID( -1 );
    }
  }

  numGlobalNodes_ = nodeList_GID_.size();

  return true;
}

#ifndef HAVE_IOTA
// iota is not part of the C++ standard.  It is an extension.
namespace {

template <class _ForwardIterator, class _Tp>
void
iota(_ForwardIterator __first, _ForwardIterator __last, _Tp __value)
{
  while (__first != __last)
    *__first++ = __value++;
}

} // namespace <unnamed>
#endif


//-----------------------------------------------------------------------------
// Function      : SerialLSUtil::setupSolnAndStateGIDs
// Purpose       : Generate Ordering and Var GIDs.
// Special Notes :
// Scope         : public
// Creator       : Rob Hoekstra, SNL, Parallel Computational Sciences
// Creation Date : 3/2/01
//-----------------------------------------------------------------------------
bool SerialLSUtil::setupSolnAndStateGIDs()
{
  //get soln and state var counts from all owned v-nodes and d-nodes
  std::vector<int> rowCountVec(numGlobalNodes_+1);
  std::vector<int> stateCountVec(numGlobalNodes_+1);
  std::vector<int> storeCountVec(numGlobalNodes_+1);
  std::vector<int> leadCurrentCountVec(numGlobalNodes_+1);

  int Loc = 0;
  rowCountVec[Loc] = 0;
  stateCountVec[Loc] = 0;
  storeCountVec[Loc] = 0;
  leadCurrentCountVec[Loc] = 0;

  for (CktNodeList::const_iterator it_cnL = topology_.getOrderedNodeList().begin(), end_cnL = topology_.getOrderedNodeList().end(); it_cnL != end_cnL; ++it_cnL )
  {
    if( (*it_cnL)->get_IsOwned() && (*it_cnL)->get_gID() != -1 )
    {
        rowCountVec[Loc+1] = rowCountVec[Loc] + (*it_cnL)->solnVarCount();
        stateCountVec[Loc+1] = stateCountVec[Loc] + (*it_cnL)->stateVarCount();
        storeCountVec[Loc+1] = storeCountVec[Loc] + (*it_cnL)->storeVarCount();
        leadCurrentCountVec[Loc+1] = leadCurrentCountVec[Loc] + (*it_cnL)->branchDataVarCount();
        ++Loc;
    }
  }

  numGlobalRows_ = rowCountVec[Loc];
  numGlobalStateVars_ = stateCountVec[Loc];
  numGlobalStoreVars_ = storeCountVec[Loc];
  numGlobalLeadCurrentVars_ = leadCurrentCountVec[Loc];

  //loop over nodes and assign soln and state GIDs
  Loc = 0;
  for (CktNodeList::iterator it_cnL = topology_.getOrderedNodeList().begin(), end_cnL = topology_.getOrderedNodeList().end(); it_cnL != end_cnL; ++it_cnL )
  {
    if( (*it_cnL)->get_IsOwned() )
    {
      if ( (*it_cnL)->get_gID() != -1 )
      {
        // Set solution GIDs
        int count = rowCountVec[Loc+1] - rowCountVec[Loc];
        if ( count )
        {
          std::vector<int>& rowGIDs = (*it_cnL)->get_SolnVarGIDList();
          rowGIDs.resize( count );
          iota( rowGIDs.begin(), rowGIDs.end(), rowCountVec[Loc] );
        }
        // Set state GIDs
        count = stateCountVec[Loc+1] - stateCountVec[Loc];
        if ( count )
        {
          std::vector<int>& stateGIDs = (*it_cnL)->get_StateVarGIDList();
          stateGIDs.resize( count );
          iota( stateGIDs.begin(), stateGIDs.end(), stateCountVec[Loc] );
        }
        // Set store GIDs
        count = storeCountVec[Loc+1] - storeCountVec[Loc];
        if ( count )
        {
          std::vector<int>& storeGIDs = (*it_cnL)->get_StoreVarGIDList();
          storeGIDs.resize( count );
          iota( storeGIDs.begin(), storeGIDs.end(), storeCountVec[Loc] );
        }
        // Set lead current GIDs
        count = leadCurrentCountVec[Loc+1] - leadCurrentCountVec[Loc];
        if ( count )
        {
          std::vector<int>& leadCurrentGIDs = (*it_cnL)->get_LeadCurrentVarGIDList();
          leadCurrentGIDs.resize( count );
          iota( leadCurrentGIDs.begin(), leadCurrentGIDs.end(), leadCurrentCountVec[Loc] );
        }

        Loc++;
      }
      else
      {
        (*it_cnL)->set_SolnVarGIDList( std::vector<int>(1,-1) );
      }
    }
    else
    {
      Report::DevelFatal0() << "Node: " << (*it_cnL)->get_id() << ", global index ("
                            << Teuchos::Utils::toString( (*it_cnL)->get_gID() )
                            << ") is NOT found!";
    }
  }

  return true;

}

//-----------------------------------------------------------------------------
// Function      : SerialLSUtil::generateRowColData
// Purpose       : Generate row/col data for linear solver.
// Special Notes :
// Scope         : public
// Creator       : Rob Hoekstra, SNL, Parallel Computational Sciences
// Creation Date : 5/26/00
//-----------------------------------------------------------------------------
void SerialLSUtil::generateRowColData()
{
  //--- set numGlobalRows_, numGlobalStateVars_, and resize lists
  numGlobalRows_ = rowList_GID_.size();
  numGlobalStateVars_ = rowList_StateGID_.size();
  numGlobalStoreVars_ = rowList_StoreGID_.size();
  numGlobalLeadCurrentVars_ = rowList_LeadCurrentGID_.size();

  if (DEBUG_TOPOLOGY)
    Xyce::dout() << "Serial Topology Util Vals: " << std::endl
                 << numGlobalRows_ << " " << numGlobalRows_ << std::endl
                 << numGlobalStateVars_ << " " << numGlobalStateVars_ << std::endl
                 << numGlobalStoreVars_ << " " << numGlobalStoreVars_ << std::endl
                 << numGlobalLeadCurrentVars_ << " " << numGlobalLeadCurrentVars_ << std::endl;

  int numRows = numGlobalRows_ + 1;

  //Build global to local map for speed
  unordered_map<int,int> GtoL_Map;
  for( int i = 0; i < numGlobalRows_; ++i )
    GtoL_Map[ rowList_GID_[i] ] = i;
  GtoL_Map[ -1 ] = numGlobalRows_;

  rowList_ColList_.resize( numRows );
  rowList_NumNZs_.resize( numRows );

  //    to compile a list of col indices for each row
  for (CktNodeList::const_iterator it_cnL = topology_.getOrderedNodeList().begin(), end_cnL = topology_.getOrderedNodeList().end(); it_cnL != end_cnL; ++it_cnL )
  {
    if( (*it_cnL)->type() == _DNODE )
    {
      const std::vector< std::vector<int> > & stamp = (*it_cnL)->jacobianStamp();
      const std::vector<int> & intGIDs = (*it_cnL)->get_SolnVarGIDList();
      const std::vector<int> & extGIDs = (*it_cnL)->get_ExtSolnVarGIDList();
      const std::vector<int> & depGIDs = (*it_cnL)->get_DepSolnGIDJacVec();
      std::vector<int> gids( intGIDs.size() + extGIDs.size() + depGIDs.size() );
      copy( extGIDs.begin(), extGIDs.end(), gids.begin() );
      copy( intGIDs.begin(), intGIDs.end(), gids.begin() + extGIDs.size() );
      copy( depGIDs.begin(), depGIDs.end(), gids.begin() + extGIDs.size() + intGIDs.size() );

#if 0
      std::cout << "jacStamp size = " << stamp.size() <<std::endl;
#endif

      for( unsigned int i = 0; i < stamp.size(); ++i )
      {
        int length = stamp[i].size();
        for( int j = 0; j < length; ++j )
        {
          if (stamp[i][j] < (int)gids.size())
          {
#if 0
            std::cout << "  jacStamp["<<i<<"]["<<j<<"] = " << stamp[i][j] << std::endl;
#endif
            rowList_ColList_[ GtoL_Map[ gids[i] ] ].push_back( gids[ stamp[i][j] ] );
          }
        }
      }
    }
  }


  if (DEBUG_TOPOLOGY)
    Xyce::dout() << Xyce::section_divider << std::endl
                 << "Row List of NZ Cols extracted" << std::endl
                 << Xyce::section_divider << std::endl;

  numGlobalNZs_ = 0;

#ifdef Xyce_NOX_LOCA_ARTIFICIAL_HOMOTOPY_SUPPORT
    //add in diagonal for homotopy support
    for( int i = 0; i < numGlobalRows_; ++i )
      rowList_ColList_[i].push_back( rowList_GID_[i] );
#endif

  //--- sort list of col indices and get rid of redundancies
  //    generate num of NZs data
  for( int i = 0; i < numRows; ++i )
  {
    std::sort(rowList_ColList_[i].begin(), rowList_ColList_[i].end());
    rowList_ColList_[i].erase(std::unique(rowList_ColList_[i].begin(), rowList_ColList_[i].end()), rowList_ColList_[i].end());

    rowList_NumNZs_[i] = rowList_ColList_[i].size();

    numGlobalNZs_ += rowList_NumNZs_[i];
  }

  if (DEBUG_TOPOLOGY)
    Xyce::dout() << Xyce::section_divider << std::endl
                 << "Row List of NZ Cols cleaned up" << std::endl
                 << Xyce::section_divider << std::endl
                 << *this;

}

//-----------------------------------------------------------------------------
// Function      : SerialLSUtil::extractAllGIDsFromTopology
// Purpose       : Fill all GID vectors using ordered node list.
// Special Notes :
// Scope         : public
// Creator       : Rob Hoekstra, SNL, Parallel Computational Sciences
// Creation Date : 5/26/00
//-----------------------------------------------------------------------------
void SerialLSUtil::extractAllGIDsFromTopology()
{
  // Clear all vectors.
  rowList_GID_.clear();
  rowList_StateGID_.clear();
  rowList_StoreGID_.clear();
  rowList_LeadCurrentGID_.clear();
  vnodeGIDVector_.clear();
  vsrcGIDVector_.clear();
  nonlinGIDVector_.clear();
  noDCPathIDVector_.clear();
  connToOneTermIDVector_.clear();

  CktNodeList::const_iterator it = topology_.getOrderedNodeList().begin();
  CktNodeList::const_iterator end = topology_.getOrderedNodeList().end();
  for ( ; it != end; ++it )
  {
    // Own this node, get solution, state, and store information.
    if( (*it)->get_IsOwned() && ( (*it)->get_gID() != -1 ) )
    {
      // Get solution variable GIDs.
      rowList_GID_.insert(rowList_GID_.end(),
          (*it)->get_SolnVarGIDList().begin(),
          (*it)->get_SolnVarGIDList().end());

      // Get state variable GIDs.
      if ((*it)->stateVarCount())
      {
        rowList_StateGID_.insert(rowList_StateGID_.end(),
            (*it)->get_StateVarGIDList().begin(),
            (*it)->get_StateVarGIDList().end());
      }

      // Get store variable GIDs.
      if ((*it)->storeVarCount())
      {
        rowList_StoreGID_.insert(rowList_StoreGID_.end(),
            (*it)->get_StoreVarGIDList().begin(),
            (*it)->get_StoreVarGIDList().end() );
      }

      // Get lead current variable GIDs.
      if ((*it)->branchDataVarCount())
      {
        rowList_LeadCurrentGID_.insert( rowList_LeadCurrentGID_.end(),
            (*it)->get_LeadCurrentVarGIDList().begin(),
            (*it)->get_LeadCurrentVarGIDList().end() );
      }

      // Collect voltage nodes.
      if ( (*it)->type() == _VNODE )
      {
        vnodeGIDVector_.push_back( *((*it)->get_SolnVarGIDList().begin()) );

        // Nodes with no DC path to ground.
        if ((*it)->getNoDCPathVar())
        {
          noDCPathIDVector_.push_back((*it)->get_id());
        }

        // Nodes with only one connection.
        if ((*it)->getConnToOneTermVar())
        {
          connToOneTermIDVector_.push_back((*it)->get_id());
        }
      }
    }

    if ( (*it)->get_IsOwned() && ((*it)->type() == _DNODE) )
    {
      const std::string & id = (*it)->get_id();
      std::string::size_type col = id.find_first_of(':');

      if ( id[col+1] == 'V' || id[col+1] == 'v' )
      {
        vsrcGIDVector_.insert( vsrcGIDVector_.end(),
            (*it)->get_SolnVarGIDList().begin(),
            (*it)->get_SolnVarGIDList().end() );

        vsrcGIDVector_.insert( vsrcGIDVector_.end(),
            (*it)->get_ExtSolnVarGIDList().begin(),
            (*it)->get_ExtSolnVarGIDList().end() );
      }

      CktNode_Dev * cktNodeDevPtr = dynamic_cast<CktNode_Dev*>(*it);
      if (!(cktNodeDevPtr->deviceInstance()->isLinearDevice()))
      {
        nonlinGIDVector_.insert( nonlinGIDVector_.end(),
            (*it)->get_SolnVarGIDList().begin(),
            (*it)->get_SolnVarGIDList().end() );

        nonlinGIDVector_.insert( nonlinGIDVector_.end(),
            (*it)->get_ExtSolnVarGIDList().begin(),
            (*it)->get_ExtSolnVarGIDList().end() );
      }
    }
  } 

  // Make sure the nonlinGIDVector_ has unique entries.
  // First sort, then erase duplicates, then remove ground node GID.
  std::sort( nonlinGIDVector_.begin(), nonlinGIDVector_.end() );
  nonlinGIDVector_.erase(std::unique(nonlinGIDVector_.begin(), nonlinGIDVector_.end() ), nonlinGIDVector_.end() ); 
  if ( nonlinGIDVector_.size() > 0 )
  {
    if ( nonlinGIDVector_.front() == -1 )
      nonlinGIDVector_.erase( nonlinGIDVector_.begin() );
  }

}

} // namespace Topo
} // namespace Xyce
