//-----------------------------------------------------------------------------
// Copyright Notice
//
//   Copyright 2002 Sandia Corporation. Under the terms
//   of Contract DE-AC04-94AL85000 with Sandia Corporation, the U.S.
//   Government retains certain rights in this software.
//
//    Xyce(TM) Parallel Electrical Simulator
//    Copyright (C) 2002-2017 Sandia Corporation
//
//    This program is free software: you can redistribute it and/or modify
//    it under the terms of the GNU General Public License as published by
//    the Free Software Foundation, either version 3 of the License, or
//    (at your option) any later version.
//
//    This program is distributed in the hope that it will be useful,
//    but WITHOUT ANY WARRANTY; without even the implied warranty of
//    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//    GNU General Public License for more details.
//
//    You should have received a copy of the GNU General Public License
//    along with this program.  If not, see <http://www.gnu.org/licenses/>.
//-----------------------------------------------------------------------------

//-----------------------------------------------------------------------------
//
// Purpose        :
//
// Special Notes  :
//
// Creator        : Robert J. Hoekstra, SNL, Electrical & Microsystems
//
// Creation Date  : 08/10/06
//
//
//
//
//-----------------------------------------------------------------------------

#ifndef N_TOP_CktGraphBasic_h
#define N_TOP_CktGraphBasic_h 1

#include <iosfwd>
#include <string>

#include <N_TOP_fwd.h>
#include <N_TOP_Misc.h>
#include <N_TOP_CktGraph.h>
#include <N_UTL_Graph.h>

namespace Xyce {
namespace Topo {

//-----------------------------------------------------------------------------
// Class         : CktGraphBasic
// Purpose       :
// Special Notes :
// Creator       : Rob Hoekstra, SNL, Electrical & Microsystems
// Creation Date : 8/10/06
//-----------------------------------------------------------------------------
class CktGraphBasic : public CktGraph
{
public:
  typedef Util::Graph<NodeID, CktNode *> Graph;

  // Default constructor.
  CktGraphBasic(const int maxTries);

  // Constructor
  CktGraphBasic(const std::string & cgID, const int maxTries);

  // Constructor
  CktGraphBasic(const std::string & cgID, const std::list<NodeID> & nodelist, const int maxTries);

private:
  CktGraphBasic(const CktGraphBasic &);
  CktGraphBasic &operator=(const CktGraphBasic &);

public:
  // Destructor
  ~CktGraphBasic();

  // Inserts graph node for ckt node if does not exist
  void InsertNode(CktNode * cktnode,
                  const std::vector<NodeID> & neighborList);

  // Returns pointer to specified ckt node
  CktNode * FindCktNode(const NodeID & cnID);

  // Breadth first, depth first, and basic traversals of graph
  //----------------------------------------------------------

  // Produces list of ckt nodes in breadth-first traversal order
  CktNodeList* getBFSNodeList();

  // Returns the node list from the circuit graph without any specific ordering
  const Graph::Data1Map &getNodeList() { return cktgph_.getData1Map(); }

  // assigns global ids to device int. and ext. vars
  //----------------------------------------------------------

  // Loop over nodes and register int and ext global ids with each device
  void registerGIDswithDevs();

  // Loop over nodes and register int and ext global ids with each device
  void registerStateGIDswithDevs();
  void registerStoreGIDswithDevs();

  // Loop over nodes and register int and ext local ids with each device
  void registerLIDswithDevs( Indexor & indexor );
  // Loop over nodes and register state local ids with each device
  void registerStateLIDswithDevs( Indexor & indexor );
  void registerStoreLIDswithDevs( Indexor & indexor );

  // Loop over nodes and register dep. local ids with each device
  void registerDepLIDswithDevs( Indexor & indexor );
  // Loop over nodes and register branch local ids with each device
  void registerBranchDataLIDswithDevs( Indexor & indexor );

  //Loop over nodes and register jacobian offsets with each device
  void registerJacLIDswithDevs( Indexor & indexor );

  // Returns vector of adj ids
  void returnAdjIDs( const NodeID & id, std::vector<NodeID> & adj_ids );

  // Returns vector of adj gids
  void returnAdjGIDs( int gid, std::vector<int> & adj_gids );

  // Reutrns number of adj gids
  int numAdjNodes( int gid ); 

  // Loop over adjacent nodes creating ordered lists of neighboring global id's
  // and owning processor numbers
  void returnAdjNodes(const NodeID & id, std::vector<int> & gidList,
                      std::vector<int> & svGIDList, std::vector<int> & procList,
                      std::list<NodeID> & idList);

  // Loop over adjacent nodes connected to ground creating ordered lists of
  // neighboring global id's, if processor number and neighboring ids names are not needed.
  void returnAdjNodesWithGround(const NodeID& id,
                                std::vector<int>& gidList,
                                std::vector<int>& svGIDList);
  
  // Redo global index node map
  void regenerateGIDNodeMap();

  // supernode given nodes
  CktNode * replaceNode( const NodeID nodeToBeReplaced, const NodeID nodeToKeep );
  void removeRedundantDevices(std::vector< CktNode * > & removedDevices);

private:
  Graph                 cktgph_;                ///< Circuit graph pair = <id, node type>, CktNode = data
  CktNodeList           BFSNodeList_;           ///< List of ckt nodes in breadth-first traversal order.
  bool                  isModified_;            ///< Don't update traversals if not modified - flag.
  int                   maxTries_;              ///< Maximum number of attempts to compute the graph center.

  unordered_map<int,int>     indexToGID_;
  unordered_map<int,int>     gIDtoIndex_;
 
public:
  std::ostream & put(std::ostream & os) const;
};

} // namespace Topo
} // namespace Xyce

#endif
