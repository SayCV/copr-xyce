
//-----------------------------------------------------------------------------
// Copyright Notice
//
//   Copyright 2002 Sandia Corporation. Under the terms
//   of Contract DE-AC04-94AL85000 with Sandia Corporation, the U.S.
//   Government retains certain rights in this software.
//
//    Xyce(TM) Parallel Electrical Simulator
//    Copyright (C) 2002-2017 Sandia Corporation
//
//    This program is free software: you can redistribute it and/or modify
//    it under the terms of the GNU General Public License as published by
//    the Free Software Foundation, either version 3 of the License, or
//    (at your option) any later version.
//
//    This program is distributed in the hope that it will be useful,
//    but WITHOUT ANY WARRANTY; without even the implied warranty of
//    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//    GNU General Public License for more details.
//
//    You should have received a copy of the GNU General Public License
//    along with this program.  If not, see <http://www.gnu.org/licenses/>.
//-----------------------------------------------------------------------------

//-------------------------------------------------------------------------
//
// Purpose        :
//
// Special Notes  :
//
// Creator        : Robert J. Hoekstra, SNL, Parallel Computational Sciences
//
// Creation Date  : 03/20/00
//
//
//
//
//-------------------------------------------------------------------------

#include <Xyce_config.h>

#include <sstream>
#include <fstream>

#include <N_UTL_fwd.h>

#include <N_ANP_AnalysisManager.h>
#include <N_DEV_DeviceBlock.h>
#include <N_DEV_DeviceMgr.h>
#include <N_DEV_DeviceState.h>
#include <N_ERH_ErrorMgr.h>
#include <N_IO_CmdParse.h>
#include <N_IO_HangingResistor.h>
#include <N_IO_RestartNode.h>
#include <N_PDS_Comm.h>
#include <N_PDS_Manager.h>
#include <N_TOP_CktGraph.h>
#include <N_TOP_CktGraphBasic.h>
#include <N_TOP_CktNode.h>
#include <N_TOP_CktNode_Dev.h>
#include <N_TOP_CktNode_V.h>
#include <N_TOP_Directory.h>
#include <N_TOP_Indexor.h>
#include <N_TOP_NodeDevBlock.h>
#include <N_TOP_LSUtilFactory.h>
#include <N_TOP_Topology.h>
#include <N_UTL_ExtendedString.h>
#include <N_UTL_FeatureTest.h>
#include <N_UTL_Functors.h>
#include <N_UTL_Marshal.h>
#include <N_UTL_OptionBlock.h>
#include <N_LAS_QueryUtil.h>

#include <N_PDS_Serial.h>
#include <N_PDS_MPI.h>


namespace Xyce {
namespace Topo {

//-----------------------------------------------------------------------------
// Function      : Topology::registerPkgOptionsMgr
// Purpose       :
// Special Notes :
// Scope         : public
// Creator       : Rich Schiek, 1437
// Creation Date : 10/21/08
//-----------------------------------------------------------------------------
bool registerPkgOptionsMgr(Topology &topology, IO::PkgOptionsMgr &options_manager)
{
  registerPkgOptionsMgr(*topology.getLinearSolverUtility(), options_manager);

  return true;
}

//-----------------------------------------------------------------------------
// Function      : Topology::Topology
// Purpose       :
// Special Notes :
// Scope         : public
// Creator       : Rob Hoekstra, SNL, Parallel Computational Sciences
// Creation Date : 5/16/00
//-----------------------------------------------------------------------------
Topology::Topology(
  const IO::CmdParse &          command_line,
  IO::HangingResistor &         hanging_resistor,
  N_PDS_Manager &               pds_manager)
  : commandLine_(command_line),
    linearSolverUtility_(Topo::LSUtilFactory::newLSUtil(*this, command_line, hanging_resistor, pds_manager)),
    maxTries_(command_line.getArgumentIntValue("-maxgraphcentertries", 1)),
    pdsManager_(pds_manager),
    mainGraphPtr_(new CktGraphBasic("", maxTries_)),
    icSettings_(0),
    nodeSymbols_(Util::SYMBOL_TYPE_END),
    gnd_("gnd")
{}

//-----------------------------------------------------------------------------
// Function      : Topology::~Topology
// Purpose       : destructor
// Special Notes :
// Scope         : public
// Creator       : Rob Hoekstra, SNL, Parallel Computational Sciences
// Creation Date : 5/16/00
//-----------------------------------------------------------------------------
Topology::~Topology()
{
  delete linearSolverUtility_;
  delete icSettings_;
  delete mainGraphPtr_;
}

//-----------------------------------------------------------------------------
// Function      : Topology::registerICs
// Purpose       : Registers parallel mgr
// Special Notes :
// Scope         : public
// Creator       : Robert Hoekstra, SNL, Parallel Computational Sciences
// Creation Date : 2/1/01
//-----------------------------------------------------------------------------
bool Topology::registerICs( const Util::OptionBlock & ob )
{
  delete icSettings_;
  icSettings_ = new Util::OptionBlock( ob );

  return true;
}

//-----------------------------------------------------------------------------
// Returns adj IDs to the given ID
//-----------------------------------------------------------------------------
void Topology::returnAdjIDs( const NodeID& id, std::vector<NodeID>& adj_ids ) const
{
  return mainGraphPtr_->returnAdjIDs(id, adj_ids);
}

//-----------------------------------------------------------------------------
// Returns adj GIDs to the given GID
//-----------------------------------------------------------------------------
void Topology::returnAdjGIDs( int gid, std::vector<int>& adj_gids ) const
{
  return mainGraphPtr_->returnAdjGIDs(gid, adj_gids);
}

//-----------------------------------------------------------------------------
// Returns number of adj nodes
//-----------------------------------------------------------------------------
int Topology::numAdjNodes( int gid ) const
{
  return mainGraphPtr_->numAdjNodes( gid );
}

//-----------------------------------------------------------------------------
// Loop over adjacent nodes creating ordered lists of neighboring global id's
// and owning processor numbers (abstract).
//-----------------------------------------------------------------------------
void Topology::returnAdjNodes(
  const NodeID& id,
  std::vector<int>& gidList,
  std::vector<int>& svGIDList,
  std::vector<int>& procList,
  std::list<NodeID>& idList) const
{
  mainGraphPtr_->returnAdjNodes(id, gidList, svGIDList, procList, idList);
}

//-----------------------------------------------------------------------------
// Returns pointer to specified ckt node (abstract).
//-----------------------------------------------------------------------------
const CktNode * Topology::findCktNode(const NodeID& cnID) const
{
  return mainGraphPtr_->FindCktNode(cnID);
}

//-----------------------------------------------------------------------------
// Function      : Topology::setupGlobalIndices
// Purpose       : Lin system data setup
// Special Notes :
// Scope         : public
// Creator       : Robert Hoekstra, SNL, Parallel Computational Sciences
// Creation Date : 2/1/01
//-----------------------------------------------------------------------------
bool Topology::setupGlobalIndices()
{
  return linearSolverUtility_->setupRowCol();
}

//-----------------------------------------------------------------------------
// Function      : Topology::addDevice
// Purpose       : New dev-node instantiator (planarized ckts only)
// Special Notes :
// Scope         : public
// Creator       : Rob Hoekstra, SNL, Parallel Computational Sciences
// Creation Date : 5/20/00
//-----------------------------------------------------------------------------
void
Topology::addDevice(
  Device::DeviceMgr &           device_manager,
  const NodeDevBlock &             node_block,
  const Device::InstanceBlock * instance_block )
{
  std::vector<NodeID> emptyNLList, nlList;
  //------ Add connected voltage nodes

  std::vector<std::string>::const_iterator it_nlL = node_block.get_NodeList().begin();
  std::vector<std::string>::const_iterator end_nlL = node_block.get_NodeList().end();

  for( ; it_nlL != end_nlL ; ++it_nlL )
  {
    //----- insert each v-node: Unless the v-node already exists,
    //----- it will be instantiated but not owned and ProcNum_
    //----- identifies the owning processor
    mainGraphPtr_->InsertNode(new CktNode_V(*it_nlL), emptyNLList);

    nlList.push_back( NodeID( *it_nlL, _VNODE ) );
  }

  //------- Now instantiate the device node,  DistribMgr has
  //------- already set ownership

  mainGraphPtr_->InsertNode(new CktNode_Dev(node_block, instance_block, device_manager), nlList);
}

//-----------------------------------------------------------------------------
// Function      : Topology::registerGIDswithDevs
// Purpose       : register the int. and ext. global ids stored by
//                 the cktnodes with their respective devices
// Special Notes :
// Scope         : public
// Creator       : Rob Hoekstra, SNL, Parallel Computational Sciences
// Creation Date : 5/22/00
//-----------------------------------------------------------------------------
void Topology::registerGIDswithDevs()
{
  mainGraphPtr_->registerGIDswithDevs();
  mainGraphPtr_->registerStateGIDswithDevs();
  mainGraphPtr_->registerStoreGIDswithDevs();
}

//-----------------------------------------------------------------------------
// Function      : Topology::registerLIDswithDevs
// Purpose       : register the int. and ext. local ids stored by
//                 the cktnodes with their respective devices
// Special Notes :
// Scope         : public
// Creator       : Rob Hoekstra, SNL, Parallel Computational Sciences
// Creation Date : 6/12/02
//-----------------------------------------------------------------------------
void Topology::registerLIDswithDevs()
{
  if( commandLine_.getArgumentValue( "-dva" ) != "off" )
  {
    Indexor indexor( pdsManager_ );

    mainGraphPtr_->registerLIDswithDevs( indexor );
    mainGraphPtr_->registerStateLIDswithDevs( indexor );
    mainGraphPtr_->registerStoreLIDswithDevs( indexor );
    mainGraphPtr_->registerBranchDataLIDswithDevs( indexor );

    mainGraphPtr_->registerDepLIDswithDevs( indexor );
  }
}

//-----------------------------------------------------------------------------
// Function      : Topology::registerJacLIDswithDevs
// Purpose       : register the jacobian local offsets with devices
// Special Notes :
// Scope         : public
// Creator       : Rob Hoekstra, SNL, Parallel Computational Sciences
// Creation Date : 9/5/02
//-----------------------------------------------------------------------------
void Topology::registerJacLIDswithDevs()
{
  if( commandLine_.getArgumentValue( "-dma" ) != "off" )
  {
    Indexor indexor(pdsManager_);

    mainGraphPtr_->registerJacLIDswithDevs( indexor );
  }
}

//-----------------------------------------------------------------------------
// Function      : Topology::resolveDependentVars
// Purpose       : loop through devices and resolve their secondary
//                 dependencies
// Special Notes : Used to resolve Expressions and Current Dependencies
// Scope         : public
// Creator       : Rob Hoekstra, SNL, Parallel Computational Sciences
// Creation Date : 5/05/01
//-----------------------------------------------------------------------------
void Topology::resolveDependentVars()
{
  int solnCount = 0, stateCount = 0, storeCount = 0;
  std::vector<int> solnLocVec, stateLocVec, storeLocVec;
  std::vector<NodeID> solnNidVec, stateNidVec, storeNidVec;
  std::vector<NodeID> idVec;

  // Find out if any device nodes have dependent variables that need to be resolved.
  for (CktNodeList::iterator it_cnL = mainGraphPtr_->getBFSNodeList()->begin(),
      it_cnL_end = mainGraphPtr_->getBFSNodeList()->end(); it_cnL != it_cnL_end; ++it_cnL )
  {
    if ( (*it_cnL)->type() == _DNODE )
    {
      // Get dependent solution variables
      (*it_cnL)->getDepSolnVars( idVec );
      if( !idVec.empty() )
      {
        solnLocVec.push_back( solnCount );
        solnNidVec.insert( solnNidVec.end(), idVec.begin(), idVec.end() );
        solnCount += idVec.size();
      }

      // Get dependent state variables
      (*it_cnL)->getDepStateVars( idVec );
      if( !idVec.empty() )
      {
        stateLocVec.push_back( stateCount );
        stateNidVec.insert( stateNidVec.end(), idVec.begin(), idVec.end() );
        stateCount += idVec.size();
      }

      // Get dependent store variables
      (*it_cnL)->getDepStoreVars( idVec );
      if( !idVec.empty() )
      {
        storeLocVec.push_back( storeCount );
        storeNidVec.insert( storeNidVec.end(), idVec.begin(), idVec.end() );
        storeCount += idVec.size();
      }
    }
  }

  // Determine if we need to generate the parallel directory by summing all counts.
  int tSolnCount, tStateCount, tStoreCount;
  pdsManager_.getPDSComm()->sumAll( &solnCount, &tSolnCount, 1 );
  pdsManager_.getPDSComm()->sumAll( &stateCount, &tStateCount, 1 );
  pdsManager_.getPDSComm()->sumAll( &storeCount, &tStoreCount, 1 );

  // If there is work to do, then create the directory and resolve the GIDs.
  if (tSolnCount || tStateCount || tStoreCount)
  {
    // Generate the directory.
    Directory directory(*this, *pdsManager_.getPDSComm());
    directory.generateDirectory();

    std::vector< std::vector<int> > gidVec, indexVec;
    std::vector<int> procVec;

    if (tSolnCount)
    {
      solnLocVec.push_back( solnCount );

      directory.getSolnGIDs( solnNidVec, gidVec, procVec );

      int count = 0;
      for (CktNodeList::iterator it_cnL = mainGraphPtr_->getBFSNodeList()->begin(),
           it_cnL_end = mainGraphPtr_->getBFSNodeList()->end(); it_cnL != it_cnL_end; ++it_cnL )
      {
        if ( (*it_cnL)->type() == _DNODE )
        {
          (*it_cnL)->getDepSolnVars( idVec );
          if( !idVec.empty() )
          {
            indexVec.assign( gidVec.begin()+solnLocVec[count],
                             gidVec.begin()+solnLocVec[count+1] );
            (*it_cnL)->set_DepSolnGIDVec( indexVec );
            (*it_cnL)->registerDepSolnGIDs( indexVec );
            ++count;
          }
        }
      }

      depSolnGIDMap_.clear();
      for( unsigned int i = 0; i < gidVec.size(); ++i )
        for( unsigned int ii = 0; ii < gidVec[i].size(); ++ii )
          depSolnGIDMap_[ gidVec[i][ii] ] = procVec[i];
    }

    if (tStateCount)
    {
      stateLocVec.push_back( stateCount );

      gidVec.clear();
      procVec.clear();
      directory.getStateGIDs( stateNidVec, gidVec, procVec );

      int count = 0;
      for (CktNodeList::iterator it_cnL = mainGraphPtr_->getBFSNodeList()->begin(),
          it_cnL_end = mainGraphPtr_->getBFSNodeList()->end(); it_cnL != it_cnL_end; ++it_cnL )
      {
        if ( (*it_cnL)->type() == _DNODE )
        {
          (*it_cnL)->getDepStateVars( idVec );
          if( !idVec.empty() )
          {
            indexVec.assign( gidVec.begin()+stateLocVec[count],
                             gidVec.begin()+stateLocVec[count+1] );
            (*it_cnL)->set_DepStateGIDVec( indexVec );
            (*it_cnL)->registerDepStateGIDs( indexVec );
            ++count;
          }
        }
      }

      depStateGIDMap_.clear();
      for( unsigned int i = 0; i < gidVec.size(); ++i )
        for( unsigned int ii = 0; ii < gidVec[i].size(); ++ii )
          depStateGIDMap_[ gidVec[i][ii] ] = procVec[i];
    }

    if (tStoreCount)
    {
      storeLocVec.push_back( storeCount );
    
      gidVec.clear();
      procVec.clear();
      directory.getStoreGIDs( storeNidVec, gidVec, procVec );

      int count = 0;
      for (CktNodeList::iterator it_cnL = mainGraphPtr_->getBFSNodeList()->begin(), 
          it_cnL_end = mainGraphPtr_->getBFSNodeList()->end(); it_cnL != it_cnL_end; ++it_cnL )
      {
        if ( (*it_cnL)->type() == _DNODE )
        {
          (*it_cnL)->getDepStoreVars( idVec );
          if( !idVec.empty() )
          {
            indexVec.assign( gidVec.begin()+storeLocVec[count],
                             gidVec.begin()+storeLocVec[count+1] );
            (*it_cnL)->set_DepStoreGIDVec( indexVec );
            (*it_cnL)->registerDepStoreGIDs( indexVec );
            ++count;
          }
        }
      }

      depStoreGIDMap_.clear();
      for( unsigned int i = 0; i < gidVec.size(); ++i )
        for( unsigned int ii = 0; ii < gidVec[i].size(); ++ii )
          depStoreGIDMap_[ gidVec[i][ii] ] = procVec[i];
    }
  }
}

//-----------------------------------------------------------------------------
// Function      : Topology::OutputBFSGraphLists
// Purpose       : Output to Xyce::dout() BFS node list for debugging
// Special Notes :
// Scope         : public
// Creator       : Rob Hoekstra, SNL, Parallel Computational Sciences
// Creation Date : 5/16/00
//-----------------------------------------------------------------------------
void Topology::OutputBFSGraphLists() const
{
  Xyce::dout() << "BFS Node Listing for Graphs" << std::endl;

  for (CktNodeList::const_iterator it_cnL = mainGraphPtr_->getBFSNodeList()->begin(),
      end_cnL = mainGraphPtr_->getBFSNodeList()->end(); it_cnL != end_cnL; ++it_cnL )
  {
    Xyce::dout() << *(*it_cnL) << std::endl;
  }
}

//-----------------------------------------------------------------------------
// Function      : Topology::generateOrderedNodeList
// Purpose       : Currently sets orderedNodeListPtr_ attribute to
//                 BFS traversal of main ckt.
// Special Notes :
// Scope         : public
// Creator       : Rob  Hoekstra, SNL, Parallel Computational Sciences
// Creation Date : 5/16/00
//-----------------------------------------------------------------------------
void Topology::generateOrderedNodeList() const
{
  orderedNodeListPtr_ = mainGraphPtr_->getBFSNodeList();
}

//-----------------------------------------------------------------------------
// Function      : verifyNodesAndDevices -- scans existing topology
//                 and asks device manager to verify each device.
//                 if the device manager returns false on any verification,
//                 then the nodes on that device are added to a list of nodes
//                 to be supernoded and the device will later be removed as redundant
// Special Notes :
// Scope         : public
// Creator       : Richard Schiek, Electrical and Microsystems modeling
// Creation Date : 2/18/2010
//-----------------------------------------------------------------------------
void Topology::verifyNodesAndDevices(
  Device::DeviceMgr &   device_manager)
{
  if( linearSolverUtility_->supernodeFlag() )
  {
    int badDeviceCount=0;

    const CktGraph::Graph::Data1Map & dataMap = mainGraphPtr_->getNodeList();
    CktGraph::Graph::Data1Map::const_iterator currentCktNodeItr = dataMap.begin();
    CktGraph::Graph::Data1Map::const_iterator endCktNodeItr = dataMap.end();
    while( currentCktNodeItr != endCktNodeItr )
    {
      if( ((*currentCktNodeItr).second)->type() == _DNODE )
      {
        CktNode_Dev * cktNodeDevPtr = dynamic_cast<CktNode_Dev*>((*currentCktNodeItr).second);
        const Device::InstanceBlock *deviceInstanceBlockPtr = cktNodeDevPtr->deviceInstanceBlock();
        if (deviceInstanceBlockPtr)
        {
          bool deviceInstanceOk = device_manager.verifyDeviceInstance( *deviceInstanceBlockPtr );
          if( !deviceInstanceOk )
          {
            badDeviceCount++;
            // place the nodes for this device in the superNodeList_
            // collected nodes so that they can be combined (supernoded)
            // It's ok to let the device node get created and inserted into the
            // topology.  we can remove it later
            NodeID deviceID = (*currentCktNodeItr).first;

            std::vector< NodeID > adjacentIDs;
            mainGraphPtr_->returnAdjIDs( deviceID, adjacentIDs );

            std::vector< NodeID >::iterator currentID = adjacentIDs.begin();
            std::vector< NodeID >::iterator endID = adjacentIDs.end();
            std::vector< NodeID >::iterator nextID = currentID;
            nextID++;

            while( nextID != endID )
            {
              
              if ( (*currentID).first != (*nextID).first )
              {
                // these nodes are to be supernoded.  Take the lexically smaller one
                // as the node to keep (i.e. A < B )
                if( (*currentID).first < (*nextID).first )
                {
                  // format of pair is nodeToReplace, nodeToKeep
                  superNodeList_.push_back( make_pair( *nextID, *currentID ) );
                }
                else
                {
                  // format of pair is nodeToReplace, nodeToKeep
                  superNodeList_.push_back( make_pair( *currentID, *nextID ) );
                }
             }
              currentID++;
              nextID++;
            }
          }

        }
        else
        {
          // issue fatal error as this case shouldn't occur
          Report::DevelFatal().in("Topology::verifyNodesAndDevices") 
            << "null Device Instance Block pointer";
        }
      }
      currentCktNodeItr++;
    }

    Report::UserWarning() << "Device verification found " << badDeviceCount << " device(s) to remove";
  }
}

//-----------------------------------------------------------------------------
// Function      : Topology::removeTaggedNodesAndDevices
// Purpose       : Remove devices and nodes that were tagged for removal
//                 during parsing.  Node removal is done through supernoding,
//                 .i.e. replacing one node globally with another.
// Special Notes :
// Scope         : public
// Creator       : Richard Schiek, Electrical and Microsystems modeling
// Creation Date : 2/2/2010
//-----------------------------------------------------------------------------
void Topology::removeTaggedNodesAndDevices()
{
  if( linearSolverUtility_->supernodeFlag() )
  {
    if (DEBUG_TOPOLOGY)
      Xyce::dout() << "Topology::removeTaggedNodesAndDevices" << std::endl
                   << *this << std::endl;

    // storage for oldNode that we'll delete when done with this routine
    // use a set because we can get the same oldNode CktNode pointer
    // multiple times
    CktNodeList oldNodeList;

    // print out current state of supernode list
    std::vector< std::pair<NodeID, NodeID> >::iterator currentNodePair = superNodeList_.begin();
    std::vector< std::pair<NodeID, NodeID> >::iterator endNodePair = superNodeList_.end();
    unordered_set<NodeID> nodesReplaced;
    while ( currentNodePair != endNodePair )
    {
      NodeID nodeToBeReplaced( currentNodePair->first );
      NodeID replacementNode( currentNodePair->second );
      if( nodeToBeReplaced != replacementNode)
      {
        unordered_set<NodeID>::iterator nodesReplacedEnd = nodesReplaced.end();
        unordered_set<NodeID>::iterator nodeReplacedLoc = nodesReplaced.find( nodeToBeReplaced );
        if( nodeReplacedLoc == nodesReplacedEnd )
        {
          // this node hasn't been done before so replace it
          Report::UserWarning() << "Replacing node \"" << nodeToBeReplaced << "\" with \"" << replacementNode << "\"";

          if (DEBUG_TOPOLOGY && nodeToBeReplaced.first < replacementNode.first)
            Xyce::dout() << "Ordering is wrong on nodes!" << std::endl;

          CktNode * oldNode = mainGraphPtr_->replaceNode( nodeToBeReplaced, replacementNode );
          nodesReplaced.insert( nodeToBeReplaced );

          // If we delete this old node now, we'll make the orderedNodeListPtr_ untraversable.
          // this would be ok as we can regenerate it, but that takes time and we would only
          // invalidate it when we do our next delete.  So, store up the oldNode so we can
          // delete them when were done
          oldNodeList.push_back( oldNode );

          // now that we've replaced "nodeToBeReplaced" with "replacementNode" we need to
          // search the superNodeList_ from this point on also doing this same substitution
          //
          // for example if our super node list was:
          //
          //    B   A
          //    C   B
          //
          // If after the B->A substitution we didn't update our list, then we would next bring
          // back the B's with C->B.
          //
          std::vector< std::pair<NodeID, NodeID> >::iterator nextNodePair = currentNodePair;
          nextNodePair++;
          while ( nextNodePair != endNodePair )
          {
            if( nextNodePair->first == nodeToBeReplaced )
            {
              if( replacementNode.first < (nextNodePair->second).first )
              {
                // need to swap on insert
                *nextNodePair = make_pair( nextNodePair->second, replacementNode );
              }
              else
              {
                // just insert in order
                *nextNodePair = make_pair( replacementNode, nextNodePair->second );
              }
            }
            else if( nextNodePair->second == nodeToBeReplaced )
            {
              if( replacementNode.first < (nextNodePair->first).first )
              {
                // no swap needed
                *nextNodePair = make_pair( nextNodePair->first, replacementNode );
              }
              else
              {
                // need to swap
                *nextNodePair = make_pair( replacementNode, nextNodePair->first );
              }
            }
            nextNodePair++;
          }
        }
      }
      currentNodePair++;
    }

    if( nodesReplaced.size() > 0 )
    {
      Report::UserWarning() << "After combining equivalent nodes, " << nodesReplaced.size() << " nodes were removed";
    }

    std::vector< CktNode * > removedDevices;
    {
      //Stats::StatTop _topoStat("Topology Remove Redundant Devices");
      //Stats::TimeBlock _topoTimer(_topoStat);

      mainGraphPtr_->removeRedundantDevices(removedDevices);
    }
    // now it's safe to delete the old nodes and device nodes
    for (CktNodeList::iterator it = oldNodeList.begin(), end = oldNodeList.end(); it != end; ++it)
    {
      delete *it;
    }

    if (!removedDevices.empty())
    {
      Report::UserWarning() <<  "After removing devices connected to one terminal, " << removedDevices.size() << " devices were removed";

      // delete old devices that were removed
      for (std::vector<CktNode *>::iterator it = removedDevices.begin(), end = removedDevices.end(); it != end; ++it)
      {
        CktNode_Dev *cktNodeDevPtr = dynamic_cast<CktNode_Dev*>(*it);

        if (cktNodeDevPtr && cktNodeDevPtr->deviceInstanceBlock())
        {
          // have a valid device.
          if (DEBUG_TOPOLOGY)
            Xyce::dout() << "Removed device id: \"" << (*it)->get_id() << "\"" << std::endl;

          delete cktNodeDevPtr;
        }
      }
    }

    // Clear supernode storage.
    superNodeList_.clear();
    globalSuperNodeList_.clear();
  }
}

//-----------------------------------------------------------------------------
// Function      : Topology::mergeOffProcTaggedNodesAndDevices
// Purpose       : Merge the off processor superNodeList_ and communicate
//                 the same list to all procs so topology reduction is the
//                 same on all procs
// Special Notes :
// Scope         : public
// Creator       : Richard Schiek, Electrical and Microsystems modeling
// Creation Date : 2/2/2010
//-----------------------------------------------------------------------------
void Topology::mergeOffProcTaggedNodesAndDevices()
{
#ifdef Xyce_PARALLEL_MPI
  if( linearSolverUtility_->supernodeFlag() )
  {
    N_PDS_Comm * commPtr = pdsManager_.getPDSComm();
    int numProcs = commPtr->numProc();
    int thisProc = commPtr->procID();

    // Set up a pointer to tell us what processor the supernodes come from.
    std::vector<int> procPtr(numProcs+1);
    procPtr[0] = 0;

    int localNodes = superNodeList_.size();

    // Count the bytes for packing these strings
    int byteCount = 0;

    // First count the size of the local superNodeList_
    byteCount += sizeof(int);

    // Now count all the NodeIDs in the list
    for (std::vector< std::pair<NodeID, NodeID> >::iterator nodePair = superNodeList_.begin(); 
        nodePair != superNodeList_.end(); nodePair++) 
    {
      byteCount += ((nodePair->first).first).length() + 2*sizeof(int);
      byteCount += ((nodePair->second).first).length() + 2*sizeof(int);
    }

    for( int p = 0; p < numProcs; ++p )
    {
      commPtr->barrier();

      // Broadcast the buffer size for this processor.
      int bsize=0;
      if (p==thisProc) { bsize = byteCount; }
      commPtr->bcast( &bsize, 1, p );

      // Create buffer.
      int pos = 0;
      char * superNodeBuffer = new char[bsize];

      if (p==thisProc) 
      {
        // Pack number of supernodes on this processor and place in globalSuperNodeList_
        commPtr->pack( &localNodes, 1, superNodeBuffer, bsize, pos );
        for (std::vector< std::pair<NodeID, NodeID> >::iterator nodePair = superNodeList_.begin(); 
            nodePair != superNodeList_.end(); nodePair++) 
        {
          // Pack first entry of pair.
          int length = ((nodePair->first).first).size();
          commPtr->pack( &length, 1, superNodeBuffer, bsize, pos );
          commPtr->pack( ((nodePair->first).first).c_str(), length, superNodeBuffer, bsize, pos );
          commPtr->pack( &((nodePair->first).second), 1, superNodeBuffer, bsize, pos );

          // Pack second entry of pair.
          length = ((nodePair->second).first).size();
          commPtr->pack( &length, 1, superNodeBuffer, bsize, pos );
          commPtr->pack( ((nodePair->second).first).c_str(), length, superNodeBuffer, bsize, pos );
          commPtr->pack( &((nodePair->second).second), 1, superNodeBuffer, bsize, pos );
        }
        // Update the processor pointer.
        procPtr[p+1] = procPtr[p] + localNodes;

        // Broadcast packed buffer.
        commPtr->bcast( superNodeBuffer, bsize, p );

      }
      else {

        // Unpack buffer and place in globalSuperNodeList_
        commPtr->bcast( superNodeBuffer, bsize, p );

        // Get number of supernodes from that processor
        int numSuperNodes = 0;
        commPtr->unpack( superNodeBuffer, bsize, pos, &numSuperNodes, 1 );

        // Update the processor pointer.
        procPtr[p+1] = procPtr[p] + numSuperNodes;

        // Extract supernode pairs and push to the back of the globalSuperNodeList_
        int length=0;
        for (int i=0; i<numSuperNodes; ++i) {

          // Unpack first pair.
          commPtr->unpack( superNodeBuffer, bsize, pos, &length, 1 );
          std::string first_val( (superNodeBuffer+pos), length );
          pos += length;
          int first_type = 0;
          commPtr->unpack( superNodeBuffer, bsize, pos, &first_type, 1 );

          // Unpack second pair.
          commPtr->unpack( superNodeBuffer, bsize, pos, &length, 1 );
          std::string second_val( (superNodeBuffer+pos), length );
          pos += length;
          int second_type = 0;
          commPtr->unpack( superNodeBuffer, bsize, pos, &second_type, 1 );

          // Push to back of globalSuperNodeList_
          globalSuperNodeList_.push_back( make_pair( NodeID(first_val,first_type), NodeID(second_val,second_type) ) );
        }
      }
      // Clean up.
      delete [] superNodeBuffer;
    }

    // Now go through the local superNodeList_ and tack on any boundary cases, where adjacencies may effect device removal.
    for (std::vector< std::pair<NodeID, NodeID> >::iterator nodePair = superNodeList_.begin(); nodePair != superNodeList_.end(); nodePair++)
    {
      NodeID nodeToBeRemoved = nodePair->first;
      NodeID replacementNode = nodePair->second;
      std::vector< std::pair<NodeID, NodeID> >::iterator currentGlobalSN = globalSuperNodeList_.begin();
      std::vector< std::pair<NodeID, NodeID> >::iterator endGlobalSN = globalSuperNodeList_.end();
      while ( currentGlobalSN != endGlobalSN )
      {
        // Add pair if replacement node is node to be removed by another processor.
        if (currentGlobalSN->first == replacementNode)
          superNodeList_.push_back( *currentGlobalSN );
        // Add pair if node to be removed is node a replacement node on another processor.
        if (currentGlobalSN->second == nodeToBeRemoved)
          superNodeList_.push_back( *currentGlobalSN );
        currentGlobalSN++;
      }
    }
  }
#endif
}

//-----------------------------------------------------------------------------
// Function      : Topology::instantiateDevices
// Purpose       : Delayed instantiation of devices
// Special Notes :
// Scope         : public
// Creator       : Rob  Hoekstra, SNL, Parallel Computational Sciences
// Creation Date : 5/16/03
//-----------------------------------------------------------------------------
void Topology::instantiateDevices()
{
  generateOrderedNodeList();

  for (CktNodeList::iterator it = orderedNodeListPtr_->begin(), 
      end = orderedNodeListPtr_->end(); it != end; ++it )
  {
    CktNode_Dev * cnd = dynamic_cast<CktNode_Dev*>(*it);

    if (cnd)
    {
      cnd->instantiate();
    }
  }
}

//-----------------------------------------------------------------------------
// Function      : Topology::getNodeSVarGIDs
// Purpose       : Return list of solution var indices for named node.
// Special Notes : returns false if node not owned or not local.
// Scope         : public
// Creator       : Rob  Hoekstra, SNL, Parallel Computational Sciences
// Creation Date : 10/11/00
//-----------------------------------------------------------------------------
bool Topology::getNodeSVarGIDs( const NodeID& id,
		                      std::vector<int> & sVarGIDList,
		                      std::vector<int> & extSVarGIDList,
                                      char & type ) const
{
  CktNode * cnPtr = mainGraphPtr_->FindCktNode( id );

  if( cnPtr != NULL )
  {
    if( cnPtr->type() == _DNODE ) type = 'D';
    else                          type = 'V';

    sVarGIDList.assign( cnPtr->get_SolnVarGIDList().begin(), cnPtr->get_SolnVarGIDList().end() );
    extSVarGIDList.assign( cnPtr->get_ExtSolnVarGIDList().begin(), cnPtr->get_ExtSolnVarGIDList().end() );
    if( cnPtr->get_IsOwned() )
    {
      return true;
    }
    else
    {
      sVarGIDList.clear();
      return false;
    }
  }
  else
    return false;
}

//-----------------------------------------------------------------------------
// Function      : Topology::regenerateGIDNodeMap
// Purpose       :
// Special Notes :
// Scope         : public
// Creator       : Robert J Hoekstra, SNL, Parallel Computational Sciences
// Creation Date : 3/6/01
//-----------------------------------------------------------------------------
void Topology::regenerateGIDNodeMap()
{
  mainGraphPtr_->regenerateGIDNodeMap();
}

//-----------------------------------------------------------------------------
// Function      : operator<<
// Purpose       : implementation for debugging
// Special Notes :
// Scope         : public
// Creator       : Rob Hoekstra, SNL, Parallel Computational Sciences
// Creation Date : 5/16/00
//-----------------------------------------------------------------------------
std::ostream& operator<<(std::ostream& os, const Topology &topology)
{
  os << topology.getMainGraph() << std::endl;

  return os;
}

//-----------------------------------------------------------------------------
// Function      : Topology::generateICLoader
// Purpose       : SuperNode all nodes associated with voltage sources
// Special Notes :
// Scope         : public
// Creator       : Robert J Hoekstra, SNL, Parallel Computational Sciences
// Creation Date : 3/20/01
//-----------------------------------------------------------------------------
bool Topology::generateICLoader(
  Device::DeviceMgr &   device_manager)
{
  std::vector< std::pair<int,double> > * vecP = NULL;
  if( icSettings_ != NULL )
  {
    Xyce::dout() << *icSettings_;

    vecP = new std::vector< std::pair<int,double> >();

    CktNode * cnp;
    for( Util::ParamList::const_iterator iterPL = icSettings_->begin();
         iterPL != icSettings_->end(); ++iterPL )
    {
      cnp = mainGraphPtr_->FindCktNode( NodeID( iterPL->tag(), -1 ) );
      if( cnp != NULL )
        if( cnp->get_IsOwned() )
          vecP->push_back( std::pair<int,double>(
		*(cnp->get_SolnVarGIDList().begin()), iterPL->getImmutableValue<double>() ) );
    }

    return device_manager.registerICLoads( vecP );
  }
  else
    return true;
}

//-----------------------------------------------------------------------------
// Function      : Topology::getRestartNodes
// Purpose       :
// Special Notes :
// Scope         : public
// Creator       : Robert J Hoekstra, SNL, Parallel Computational Sciences
// Creation Date : 8/29/01
//-----------------------------------------------------------------------------
bool Topology::getRestartNodes(Analysis::AnalysisManager &analysis_manager, std::vector<IO::RestartNode*> & nodeVec )
{
  if (!orderedNodeListPtr_)
    return false;

  int count = 0;
  for (CktNodeList::const_iterator iterCN = orderedNodeListPtr_->begin(), 
      endCN  = orderedNodeListPtr_->end(); iterCN != endCN; ++iterCN )
  {
    if( (*iterCN)->get_IsOwned() && (*iterCN)->get_gID() != -1 )
    {
      ++count;
    }
  }

  nodeVec.resize(count);

  count = 0;
  for (CktNodeList::iterator iterCN = orderedNodeListPtr_->begin(), 
      endCN  = orderedNodeListPtr_->end(); iterCN != endCN; ++iterCN )
  {
    if( (*iterCN)->get_IsOwned() && (*iterCN)->get_gID() != -1 )
    {
      CktNode *cnP = *iterCN;

      nodeVec[count] = new IO::RestartNode( cnP->get_id(), cnP->type() );

      int i = 0;
      const std::vector<int> & gidList = cnP->get_SolnVarGIDList();
      nodeVec[count]->solnVarData.resize( gidList.size() );
      for( std::vector<int>::const_iterator iterIC = gidList.begin(); iterIC != gidList.end(); ++iterIC, ++i )
        analysis_manager.getSolnVarData( *iterIC, nodeVec[count]->solnVarData[i] );

      i = 0;
      int numStateVars = cnP->stateVarCount();
      nodeVec[count]->stateVarData.resize( numStateVars );
      if (numStateVars)
      {
        const std::vector<int> & gidList2 = cnP->get_StateVarGIDList();
        for( std::vector<int>::const_iterator iterIC = gidList2.begin(); iterIC != gidList2.end(); ++iterIC, ++i )
          analysis_manager.getStateVarData( *iterIC, nodeVec[count]->stateVarData[i] );
      }

      i = 0;
      int numStoreVars = cnP->storeVarCount();
      nodeVec[count]->storeVarData.resize( numStoreVars );
      if (numStoreVars)
      {
        const std::vector<int> & gidList3 = cnP->get_StoreVarGIDList();
        for( std::vector<int>::const_iterator iterIC = gidList3.begin(); iterIC != gidList3.end(); ++iterIC, ++i )
          analysis_manager.getStoreVarData( *iterIC, nodeVec[count]->storeVarData[i] );
      }

      if( cnP->type() == _DNODE )
        nodeVec[count]->devState = (dynamic_cast<CktNode_Dev*>(cnP))->getDevState();

      ++count;
    }
  }

  return true;
}

//-----------------------------------------------------------------------------
// Function      : Topology::restoreRestartNodes
// Purpose       :
// Special Notes :
// Scope         : public
// Creator       : Robert J Hoekstra, SNL, Parallel Computational Sciences
// Creation Date : 8/29/01
//-----------------------------------------------------------------------------
bool Topology::restoreRestartNodes(
    Analysis::AnalysisManager &analysis_manager, 
    const std::vector<IO::RestartNode*> & nodeVec)
{
  CktNode * cnP;

  for( unsigned int i = 0; i < nodeVec.size(); ++i )
  {
    cnP = mainGraphPtr_->FindCktNode( NodeID(nodeVec[i]->ID,nodeVec[i]->type) );

    if( cnP != NULL )
    {
      if (DEBUG_RESTART)
      {
        Xyce::dout() << "Restoring Node: " << nodeVec[i]->ID << std::endl;
      }

      const std::vector<int> & gidList = cnP->get_SolnVarGIDList();
      int pos = 0;
      for( std::vector<int>::const_iterator iterIC = gidList.begin();
           iterIC != gidList.end(); ++iterIC, ++pos )
      {
        analysis_manager.setSolnVarData( *iterIC, nodeVec[i]->solnVarData[pos] );
      }

      if (cnP->stateVarCount())
      {
        const std::vector<int> & gidList2 = cnP->get_StateVarGIDList();
        pos = 0;
        for( std::vector<int>::const_iterator iterIC = gidList2.begin();
             iterIC != gidList2.end(); ++iterIC, ++pos )
        {
          analysis_manager.setStateVarData( *iterIC, nodeVec[i]->stateVarData[pos] );
        }
      }

      if (cnP->storeVarCount())
      {
        const std::vector<int> & gidList3 = cnP->get_StoreVarGIDList();
        pos = 0;
        for( std::vector<int>::const_iterator iterIC = gidList3.begin();
             iterIC != gidList3.end(); ++iterIC, ++pos )
        {
          analysis_manager.setStoreVarData( *iterIC, nodeVec[i]->storeVarData[pos] );
        }
      }

      if( nodeVec[i]->devState != NULL && nodeVec[i]->devState != 0 )
      {
        (dynamic_cast<CktNode_Dev*>(cnP))->setDevState( *nodeVec[i]->devState );
      }
    }
  }

  return true;
}


//-----------------------------------------------------------------------------
// Function      : Topology::outputNameFile
// Purpose       : This is a kludgy function designed to output all the
//                 solution variable indices and their respective names
//                 to a file.
//
//                 The original point was to create a file to compare
//                 with SPICE, so the names needed to be as similar
//                 as possible to SPICE's naming convention.
//
// Special Notes :
// Scope         : public
// Creator       : Eric R. Keiter, SNL, Parallel Computational Sciences
// Creation Date : 9/07/01
//-----------------------------------------------------------------------------
bool Topology::outputNameFile(
  Parallel::Machine     comm,
  const std::string &   path,
  bool                  override_output)
{
  loadNodeSymbols();


  if (linearSolverUtility_->namesFileFlag() || override_output)
  {
    Indexor indexor(pdsManager_);

    std::ostringstream oss;
    std::vector<int> id(1);
    for (int i = 0, size = solutionNodeNames_.size(); i < size; ++i)
    {
      if (*solutionNodeNames_[i] != "gnd") {
        id[0] = i;
        std::string s = *solutionNodeNames_[i];
        Util::toLower(s);
        indexor.localToGlobal(Parallel::SOLUTION, id);

        oss << "\t" << id[0] << "\t" << std::setw(12) << s << std::endl;
      }
    }

    Util::Marshal mout;
    mout << oss.str();

    std::vector<std::string> dest;
    Parallel::GatherV(comm, 0, mout.str(), dest);

    if (Parallel::rank(comm) == 0) {
      std::ofstream output_stream(path.c_str(), std::ios_base::out);

      if (output_stream.fail())
      {
        Report::UserWarning() << "Unable to open names file" <<std::endl;
      }
      else
      {
        output_stream << "HEADER" << std::endl;
        for (int p = 0; p < Parallel::size(comm); ++p) {
          Util::Marshal min(dest[p]);

          std::string s;
          min >> s;
          output_stream << s;
        }
      }
    }
  }

  return true;
}

//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------
void Topology::loadNodeSymbols() const
{
  generateOrderedNodeList();

  if (nodeSymbols_[Util::SOLUTION_SYMBOL].empty()) {
    for (CktNodeList::const_iterator it = orderedNodeListPtr_->begin(), end  = orderedNodeListPtr_->end(); it != end; ++it)
    {
      if ((*it)->get_IsOwned())
      {
        (*it)->loadNodeSymbols(const_cast<Topology &>(*this));
      }
    }
    solutionNodeNames_.resize(nodeSymbols_[Util::SOLUTION_SYMBOL].size() + 1, &gnd_);
    for (NodeNameMap::const_iterator it = nodeSymbols_[Util::SOLUTION_SYMBOL].begin(), end = nodeSymbols_[Util::SOLUTION_SYMBOL].end(); it != end; ++it) {
      ThrowRequire((*it).second < solutionNodeNames_.size());

      solutionNodeNames_[(*it).second] = &(*it).first;
    }
  }
}

//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------
const std::vector<char> & Topology::getVarTypes() const
{
  generateOrderedNodeList();

  if (variableTypes_.empty())
  {
    for (CktNodeList::iterator it = orderedNodeListPtr_->begin(), 
        end = orderedNodeListPtr_->end(); it != end; ++it )
    {
      if( (*it)->get_IsOwned() && ( (*it)->get_gID() != -1 ) )
      {
          (*it)->varTypeList(variableTypes_); // variableTypes_.push_back( 'V' );
      }
    }
  }

  return variableTypes_;
}

//-----------------------------------------------------------------------------
// Function      : Topology::addResistors
// Purpose       : Adds resistors (between ground and nodes which are connected
//                 to only one device terminal) to a copy of the netlist file.
// Special Notes :
// Scope         : public
// Creator       : Keith Santarelli, SNL, Electrical and Microsystems Modeling
// Creation Date : 12/11/07
//-----------------------------------------------------------------------------
void Topology::addResistors
(const std::vector<std::string> &       inputVec,
 const std::string &                    resValue,
 const std::string &                    netlistFilename,
 bool                                   oneTermNotNoDCPath)
{
  std::string netlistCopy(netlistFilename);
  netlistCopy += "_xyce.cir";
  std::ofstream copyFile;
  copyFile.open(netlistCopy.c_str(),std::ios::app);  //put in append mode

  std::string msg("");

  if (DEBUG_IO) {
    if (oneTermNotNoDCPath)
    {
      msg = "Adding resistors of value ";
      //msg += resvalue;
      msg += " between ground and nodes connected to only one device";
      msg += "terminal in file ";
      msg += netlistCopy;
    }
    else
    {
      msg = "Adding resistors of value ";
      //msg += resvalue;
      msg += " between ground and nodes with no DC path to ground in file ";
      msg += netlistCopy;
    }

    Xyce::dout() << msg << std::endl;
  }

  //Some error checking in case we can't open the file.
  if(copyFile.fail())
  {
    if (oneTermNotNoDCPath)
    {
      Report::UserError() 
        << "Error adding resistors between ground and nodes connected to only one device terminal: cannot open file " 
        << netlistCopy;
    }
    else
    {
      Report::UserError() 
        << "Error adding resistors between ground and nodes with no DC path to ground: cannot open file " 
        << netlistCopy;
    }

    return;
  }

  std::string banner("");

  if (oneTermNotNoDCPath)
  {
    banner = "*XYCE-GENERATED OUTPUT:  Adding resistors between ground and ";
    banner += "nodes connected to only 1 device terminal:";
  }
  else
  {
    banner = "*XYCE-GENERATED OUTPUT:  Adding resistors between ground and ";
    banner += "nodes with no DC path to ground:";
  }

  copyFile << std::endl << std::endl << banner << std::endl << std::endl;


  //Now, loop through the ids in inputVec and add the resistors.

  std::vector<std::string>::const_iterator inputit = inputVec.begin();
  std::vector<std::string>::const_iterator inputend = inputVec.end();
  std::string node("");
  int count = 0;

  while (inputit != inputend)
  {
    node = *inputit;

    //If node is blank (""), then something has gone wrong---we're trying to
    //access a node that's not of type _VNODE (this *shouldn't* happen,
    //assuming that everything here is done correctly, but, in case it does,
    //we don't want to add junk lines to the copy of the netlist file.

    if (node == "")
    {
      Report::UserWarning() 
        <<  "Attempt to access circuit node not of type _VNODE.  No line will be printed in netlist copy file";
    }
    else
    {
      std::string resname("R");

      if (oneTermNotNoDCPath)
      {
        resname += "ONETERM";
      }
      else
      {
        resname += "NODCPATH";
      }

      copyFile << resname;
      copyFile << count+1 << " " << node << " 0 " << resValue;
      copyFile << std::endl;
    }
    inputit++;
    count++;
  }
  copyFile.close();
}

//-----------------------------------------------------------------------------
// Function      : Topology::appendEndStatement
// Purpose       : Adds ".END" to a copy of the netlist file.
// Special Notes :
// Scope         : public
// Creator       : Keith Santarelli, SNL, Electrical and Microsystems Modeling
// Creation Date : 12/11/07
//-----------------------------------------------------------------------------
void Topology::appendEndStatement(const std::string & netlistFilename)
{
  std::string netlistCopy(netlistFilename);
  netlistCopy += "_xyce.cir";
  std::ofstream copyFile;
  copyFile.open(netlistCopy.c_str(),std::ios::app);  //put in append mode

  std::string msg("");

  //Some error checking in case we can't open the file.
  if(copyFile.fail())
  {
    Report::UserError() << "Attempt to append .END statement as part of netlist copy procedure:  Cannot open file " << netlistCopy;
  }

  copyFile << std::endl << ".END" << std::endl;
  copyFile.close();
}

} // namespace Topo
} // namespace Xyce
