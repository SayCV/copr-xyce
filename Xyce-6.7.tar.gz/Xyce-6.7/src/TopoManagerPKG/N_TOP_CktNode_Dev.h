//-----------------------------------------------------------------------------
// Copyright Notice
//
//   Copyright 2002 Sandia Corporation. Under the terms
//   of Contract DE-AC04-94AL85000 with Sandia Corporation, the U.S.
//   Government retains certain rights in this software.
//
//    Xyce(TM) Parallel Electrical Simulator
//    Copyright (C) 2002-2017 Sandia Corporation
//
//    This program is free software: you can redistribute it and/or modify
//    it under the terms of the GNU General Public License as published by
//    the Free Software Foundation, either version 3 of the License, or
//    (at your option) any later version.
//
//    This program is distributed in the hope that it will be useful,
//    but WITHOUT ANY WARRANTY; without even the implied warranty of
//    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//    GNU General Public License for more details.
//
//    You should have received a copy of the GNU General Public License
//    along with this program.  If not, see <http://www.gnu.org/licenses/>.
//-----------------------------------------------------------------------------

//-----------------------------------------------------------------------------
//
// Purpose        :
//
// Special Notes  :
//
// Creator        : Robert J. Hoekstra, SNL, Parallel Computational Sciences
//
// Creation Date  : 03/20/00
//
//
//
//
//-----------------------------------------------------------------------------

#ifndef N_TOP_CktNode_Dev_h
#define N_TOP_CktNode_Dev_h 1

#include <N_DEV_fwd.h>

#include <N_TOP_CktNode.h>
#include <N_TOP_NodeDevBlock.h>
#include <N_DEV_DeviceInstance.h>
#include <N_DEV_DeviceBlock.h>

namespace Xyce {
namespace Topo {

//-----------------------------------------------------------------------------
// Class         : CktNode_Dev
// Purpose       :
// Special Notes :
// Creator       : Rob Hoekstra, SNL, Parallel Computational Sciences
// Creation Date : 5/16/00
//-----------------------------------------------------------------------------
class CktNode_Dev : public CktNode
{
public:
  CktNode_Dev(
    Device::DeviceInstance *      device_instance,
    const NodeDevBlock &          node_block)
    : CktNode(node_block.getDevBlock().getInstanceName().getEncodedName()),
      deviceInstance_(device_instance),
      deviceManager_(0),
      instanceBlock_(0)
  {}

  CktNode_Dev(
    const NodeDevBlock &                   node_block,
    const Device::InstanceBlock *       instance_block,
    Device::DeviceMgr &                 device_manager)
    : CktNode(node_block.getDevBlock().getInstanceName().getEncodedName()),
      deviceInstance_(0),
      deviceManager_(&device_manager),
      instanceBlock_(instance_block)
  {}

  // Destructor
  virtual ~CktNode_Dev();

private:
  CktNode_Dev(const CktNode_Dev &);
  CktNode_Dev & operator=(const CktNode_Dev &);

public:
  int type() const { return _DNODE; }

  bool getNoDCPathVar() {return false;}

  bool getConnToOneTermVar() {return false;}

  void setTrueNoDCPathVar() {}

  void setTrueConnToOneTermVar() {}

  virtual void loadNodeSymbols(Topology &topology) const;

  bool instantiated() const
  {
    return deviceInstance_!=0;
  }
  
  bool instantiate();

  const Device::InstanceBlock *deviceInstanceBlock()
  {
    return instanceBlock_;
  }

  const Device::DeviceInstance *deviceInstance()
  {
    return deviceInstance_;
  }

  // Get's the device state object.
  Device::DeviceState * getDevState();

  // Set's the device state object.
  bool setDevState(const Device::DeviceState & state);

  // Registers int. and ext. global ids with dev instance.
  void registerGIDswithDev(const IndexPairVector & intGIDList,
  	const IndexPairVector & extGIDList);

  // Registers state global ids with dev instance.
  void registerStateGIDswithDev(const IndexPairVector & stateGIDList);
  void registerStoreGIDswithDev(const IndexPairVector & storeGIDList);

  void registerLIDswithDev( const std::vector<int> & intLIDVec,
                            const std::vector<int> & extLIDVec );
  void registerStateLIDswithDev( const std::vector<int> & stateLIDVec );
  void registerStoreLIDswithDev( const std::vector<int> & storeLIDVec );
  void registerLeadCurrentLIDswithDev( const std::vector<int> & leadCurrentLIDVec);

  void registerDepLIDswithDev( const std::vector< std::vector<int> > & depLIDVec );
  void registerDepStateLIDswithDev( const std::vector< std::vector<int> > & depStateLIDVec );
  void registerDepStoreLIDswithDev( const std::vector< std::vector<int> > & depStoreLIDVec );

  // Setup secondary dependencies.
  void getDepSolnVars( std::vector< NodeID >& dsVars );
  void registerDepSolnGIDs(const std::vector< std::vector< int > > & dsGIDs);
  void getDepStateVars( std::vector< NodeID >& dsVars );
  void registerDepStateGIDs(const std::vector< std::vector< int > > & dsGIDs);
  void getDepStoreVars( std::vector< NodeID >& dsVars );
  void registerDepStoreGIDs(const std::vector< std::vector< int > > & dsGIDs);
  void getDepLeadCurrentVars( std::vector< NodeID >& dlcVars );
  void registerDepLeadCurrentGIDs(const std::vector< std::vector< int > > & dlcGIDs);

  const std::vector<int> & get_StateVarGIDList() const {
    return stateVarGIDList_;
  }

  std::vector<int> & get_StateVarGIDList() {
    return stateVarGIDList_;
  }

  void set_StateVarGIDList(const std::vector<int> & svGIDList) {
    stateVarGIDList_ = svGIDList;
  }

  const std::vector<int> & get_StoreVarGIDList() const {
    return storeVarGIDList_;
  }

  std::vector<int> & get_StoreVarGIDList() {
    return storeVarGIDList_;
  }

  void set_StoreVarGIDList(const std::vector<int> & svGIDList) {
    storeVarGIDList_ = svGIDList;
  }

  const std::vector<int> & get_LeadCurrentVarGIDList() const {
    return leadCurrentVarGIDList_;
  }

  std::vector<int> & get_LeadCurrentVarGIDList() {
    return leadCurrentVarGIDList_;
  }

  void set_LeadCurrentVarGIDList(const std::vector<int> & lcvGIDList) {
    leadCurrentVarGIDList_ = lcvGIDList;
  }

  void get_DepSolnGIDVec(std::vector< std::vector<int> > & dsGIDs) const {
    dsGIDs = depSolnGIDVec_;
  }
  void set_DepSolnGIDVec(const std::vector< std::vector<int> > & dsGIDs) {
    depSolnGIDVec_ = dsGIDs;
  }
  void get_DepStateGIDVec(std::vector< std::vector<int> > & dsGIDs) const {
    dsGIDs = depStateGIDVec_;
  }
  void set_DepStateGIDVec(const std::vector< std::vector<int> > & dsGIDs) {
    depStateGIDVec_ = dsGIDs;
  }
  void get_DepStoreGIDVec(std::vector< std::vector<int> > & dsGIDs) const {
    dsGIDs = depStoreGIDVec_;
  }
  void set_DepStoreGIDVec(const std::vector< std::vector<int> > & dsGIDs) {
    depStoreGIDVec_ = dsGIDs;
  }

  const std::vector<std::string> & getDepStoreVars();

  int solnVarCount() const;
  int stateVarCount() const;
  int storeVarCount() const;
  int branchDataVarCount() const;

  int depSolnVarCount() const {
    return depSolnGIDVec_.size();
  }
 
  int depStateVarCount() const {
    return depStateGIDVec_.size();
  }
 
  int depStoreVarCount() const {
    return depStoreGIDVec_.size();
  }

  const std::vector<int> & leadConnect() const;

  const std::vector< std::vector<int> > & jacobianStamp() const;
  const std::vector<int> & get_DepSolnGIDJacVec() { return deviceInstance_->getDepSolnGIDVec(); }

  void registerJacLIDswithDev( const std::vector< std::vector<int> > & jacLIDVec );

  void registerGIDDataWithDev(
        const std::vector<int> & counts,
        const std::vector<int> & GIDs,
  	const std::vector< std::vector<int> > & jacGIDs );

  void varTypeList( std::vector<char> & varTypeVec ) const;

private:

  // Pointer to a device instance.
  Device::DeviceInstance *      deviceInstance_;
  Device::DeviceMgr *           deviceManager_;
  const Device::InstanceBlock * instanceBlock_;

  std::vector<int>              stateVarGIDList_;               /// State variable global id list.
  std::vector<int>              storeVarGIDList_;
  std::vector<int>              leadCurrentVarGIDList_;

  std::vector< std::vector<int> > depSolnGIDVec_;
  std::vector< std::vector<int> > depStateGIDVec_;
  std::vector< std::vector<int> > depStoreGIDVec_;

public:

    std::ostream & put(std::ostream & os) const;

};

} // namespace Topo
} // namespace Xyce

#endif
