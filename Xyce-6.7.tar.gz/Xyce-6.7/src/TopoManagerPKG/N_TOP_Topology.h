//-----------------------------------------------------------------------------
// Copyright Notice
//
//   Copyright 2002 Sandia Corporation. Under the terms
//   of Contract DE-AC04-94AL85000 with Sandia Corporation, the U.S.
//   Government retains certain rights in this software.
//
//    Xyce(TM) Parallel Electrical Simulator
//    Copyright (C) 2002-2017 Sandia Corporation
//
//    This program is free software: you can redistribute it and/or modify
//    it under the terms of the GNU General Public License as published by
//    the Free Software Foundation, either version 3 of the License, or
//    (at your option) any later version.
//
//    This program is distributed in the hope that it will be useful,
//    but WITHOUT ANY WARRANTY; without even the implied warranty of
//    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//    GNU General Public License for more details.
//
//    You should have received a copy of the GNU General Public License
//    along with this program.  If not, see <http://www.gnu.org/licenses/>.
//-----------------------------------------------------------------------------

//-----------------------------------------------------------------------------
//
// Purpose        :
//
// Special Notes  :
//
// Creator        : Robert J. Hoekstra, SNL, Parallel Computational Sciences
//
// Creation Date  : 03/20/00
//
//
//
//
//-----------------------------------------------------------------------------

#ifndef N_TOP_Topology_h
#define N_TOP_Topology_h

// ---------- Standard Includes ----------
#include <string>
#include <list>
#include <map>
#include <set>
#include <iosfwd>
#include <vector>

#include <N_ANP_fwd.h>
#include <N_DEV_fwd.h>
#include <N_IO_fwd.h>
#include <N_PDS_fwd.h>
#include <N_TOP_fwd.h>
#include <N_LAS_fwd.h>
#include <N_UTL_fwd.h>

#include <N_DEV_DeviceBlock.h>
#include <N_TOP_Misc.h>
#include <N_UTL_NoCase.h>
#include <N_UTL_NodeSymbols.h>

namespace Xyce {
namespace Topo {

//-----------------------------------------------------------------------------
// Class         : Topology
// Purpose       :
// Special Notes :
// Creator       : Rob Hoekstra, SNL, Parallel Computational Sciences
// Creation Date : 5/16/00
//-----------------------------------------------------------------------------
class Topology
{
  friend std::ostream & operator << (std::ostream & os, const Topology & topo);

public:
  Topology(const IO::CmdParse & cp, IO::HangingResistor &hanging_resistor, N_PDS_Manager &pds_manager);
  ~Topology();

private:
  Topology(const Topology & right);
  Topology &operator=(const Topology & right);

public:
  bool registerICs(const Util::OptionBlock & ob);

  // Setup linear system information.
  bool setupGlobalIndices();

  Device::DeviceNameInstanceBlockMap &getDeviceNames() {
    return deviceNames_;
  }

  // Current add methods for devices tailored to work with device ghosting.
  void addDevice(Device::DeviceMgr &device_manager, const NodeDevBlock & nb, const Device::InstanceBlock *ibPtr);

  // Main call to register global id's with device instances.
  void registerGIDswithDevs();

  // Main call to register state-variable global id's with device instances.
  void registerStateGIDswithDevs();

  // Main call to register store-variable global id's with device instances.
  void registerStoreGIDswithDevs();

  // Main call to register local id's with device instances.
  void registerLIDswithDevs();

  // Main call to register local id's with device instances.
  void registerJacLIDswithDevs();

  // Resolution of Secondary Dependencies for devices.
  void resolveDependentVars();

  // Output to screen, debug, traversals of graph.
  void OutputBFSGraphLists() const;

  // Generate Ordered node list using BFS.
  void generateOrderedNodeList() const;

  const CktNodeList &getOrderedNodeList() const
  {
    return *orderedNodeListPtr_;
  }

  CktNodeList &getOrderedNodeList() 
  {
    return *orderedNodeListPtr_;
  }

  // merge the off processor superNodeList_ and communicate the same list
  // to all procs so topology reduction is the same on all procs
  void mergeOffProcTaggedNodesAndDevices();

  // this functions builds up the supernode list.  Called at the end of
  // parsing from n_cir_xyce
  void verifyNodesAndDevices(Device::DeviceMgr &device_manager);

 // remove any nodes and devices that were tagged for removal during parsing
  void removeTaggedNodesAndDevices();

  // Used for delayed instantiation of devices
  void instantiateDevices();

  // Return list of solution var indices for named node.  Returns false if node
  // not owned or not local.
  bool getNodeSVarGIDs( const NodeID &id,
                        std::vector<int> & sVarGIDList,
                        std::vector<int> & extSVarGIDList,
                        char & type ) const;

  // Accessor to get utility class for linear solver.
  Linear::QueryUtil *getLinearSolverUtility()
  {
    return linearSolverUtility_;
  }

  void regenerateGIDNodeMap();

  bool generateICLoader(Device::DeviceMgr &device_manager);

  // Restart capability.
  bool getRestartNodes(Analysis::AnalysisManager &analysis_manager, std::vector< IO::RestartNode * > & nodeVec);
  bool restoreRestartNodes(Analysis::AnalysisManager &analysis_manager, const std::vector< IO::RestartNode * > & nodeVec);

  // Solution variable name output.
  bool outputNameFile(Parallel::Machine comm, const std::string &path, bool overRideOutput = false);

  // These calls generate and return node maps.
  // NOTE:  The node type is known, this map will have unique keys.
  void loadNodeSymbols() const;

  const std::vector<char> &getVarTypes() const;

  const NodeNameMap &getSolutionNodeNameMap() const {
    loadNodeSymbols();
    return nodeSymbols_[Util::SOLUTION_SYMBOL];
  }

  const NodeNameMap &getStateNodeNameMap() const {
    loadNodeSymbols();
    return nodeSymbols_[Util::STATE_SYMBOL];
  }

  const NodeNameMap &getStoreNodeNameMap() const {
    loadNodeSymbols();
    return nodeSymbols_[Util::STORE_SYMBOL];
  }

  const NodeNameMap &getExternalNodeNameMap() const {
    loadNodeSymbols();
    return nodeSymbols_[Util::EXTERN_SYMBOL];
  }

  const NodeNameMap &getBranchVarsNodeNameMap() const {
    loadNodeSymbols();
    return nodeSymbols_[Util::BRANCH_SYMBOL];
  }
  
  // These functions are added to augment a copy of the netlist file to
  // include resistors which connect ground to "dangling" nodes.
  // NOTE: These IDs are assumed to be _VNODE, so no need to use NodeID.

  void addResistors(const std::vector<std::string> & inputVec, const std::string & resValue,
		    const std::string & netlistFilename, bool oneTermNotNoDCPath);

  void appendEndStatement(const std::string & netlistFilename);

  // Returns adj IDs to the given ID
  void returnAdjIDs( const NodeID& id, std::vector<NodeID>& adj_ids ) const;

  // Returns adj GIDs to the given GID
  void returnAdjGIDs( int gid, std::vector<int>& adj_gids ) const;

  // Returns the number of adjacent nodes, without their GIDs.
  int numAdjNodes( int gid ) const;

  // Loop over adjacent nodes creating ordered lists of neighboring global id's
  // and owning processor numbers.
  void returnAdjNodes(
    const NodeID &      id,
    std::vector<int> &  gidList,
    std::vector<int> &  svGIDList,
    std::vector<int> &  procList,
    std::list<NodeID> & idList) const;

  const std::map< int, int > &getDepSolnGIDMap() const {
    return depSolnGIDMap_;
  }

  const std::map< int, int > &getDepStateGIDMap() const {
    return depStateGIDMap_;
  }

  const std::map< int, int > &getDepStoreGIDMap() const {
    return depStoreGIDMap_;
  }

  N_PDS_Manager &getPDSManager() {
    return pdsManager_;
  }

  Util::SymbolTable &getNodeSymbols() {
    return nodeSymbols_;
  }

  const std::vector<const std::string *> &getSolutionNodeNames() const {
    return solutionNodeNames_;
  }
  
  CktGraph &getMainGraph() {
    return *mainGraphPtr_;
  }

  const CktGraph &getMainGraph() const {
    return *mainGraphPtr_;
  }

  const std::map< int, int > &getDepLeadCurrentGIDMap() const {
    return depLeadCurrentGIDMap_;
  }

  // Returns pointer to specified ckt node.
  const CktNode *findCktNode(const NodeID& cnID) const;

private:
  const IO::CmdParse &                  commandLine_;           ///< Command line object
  Device::DeviceNameInstanceBlockMap    deviceNames_;           ///< Device name to instance block
  Linear::QueryUtil *                   linearSolverUtility_;   ///< Utility class to extract alloc info for linear solver.

  int                                   maxTries_;              ///< Maximum number of tries to find the graph center

  N_PDS_Manager &                       pdsManager_;            ///< Parallel services manager object

  CktGraph *                            mainGraphPtr_;

  // Pointer to the time-integration manager object.
  mutable CktNodeList *                 orderedNodeListPtr_;

  Util::OptionBlock *                   icSettings_;

  std::map< int, int >                  depSolnGIDMap_;
  std::map< int, int >                  depStateGIDMap_;
  std::map< int, int >                  depStoreGIDMap_;
  std::map< int, int >                  depLeadCurrentGIDMap_;

  // this is a list of nodes to be supernoded
  // format is: nodeToBeReplaced, nodeToBeKept in each pair.
  // NOTE: this memory is cleared after the nodes are removed from the ordered node list. 
  std::vector< std::pair<NodeID, NodeID> >                superNodeList_;
  std::vector< std::pair<NodeID, NodeID> >                globalSuperNodeList_;

  mutable Util::SymbolTable                             nodeSymbols_;
  mutable std::vector<char>                             variableTypes_;
  mutable std::vector<const std::string *>              solutionNodeNames_;
  const std::string                                     gnd_;
};

bool registerPkgOptionsMgr(Topology &topology, IO::PkgOptionsMgr &options_manager);

} // namespace Topo
} // namespace Xyce

#endif
