//-----------------------------------------------------------------------------
// Copyright Notice
//
//   Copyright 2002 Sandia Corporation. Under the terms
//   of Contract DE-AC04-94AL85000 with Sandia Corporation, the U.S.
//   Government retains certain rights in this software.
//
//    Xyce(TM) Parallel Electrical Simulator
//    Copyright (C) 2002-2017 Sandia Corporation
//
//    This program is free software: you can redistribute it and/or modify
//    it under the terms of the GNU General Public License as published by
//    the Free Software Foundation, either version 3 of the License, or
//    (at your option) any later version.
//
//    This program is distributed in the hope that it will be useful,
//    but WITHOUT ANY WARRANTY; without even the implied warranty of
//    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//    GNU General Public License for more details.
//
//    You should have received a copy of the GNU General Public License
//    along with this program.  If not, see <http://www.gnu.org/licenses/>.
//-----------------------------------------------------------------------------

//-------------------------------------------------------------------------
//
// Purpose        :
//
// Special Notes  :
//
// Creator        : Robert J. Hoekstra, SNL, Parallel Computational Sciences
//
// Creation Date  : 05/26/00
//
//
//
//
//-------------------------------------------------------------------------

#include <Xyce_config.h>

#include <iostream>
#include <numeric>
#include <assert.h>

#include <N_ERH_ErrorMgr.h>
#include <N_IO_CmdParse.h>
#include <N_PDS_Comm.h>
#include <N_PDS_Directory.h>
#include <N_PDS_GlobalAccessor.h>
#include <N_PDS_Manager.h>
#include <N_PDS_Migrate.h>
#include <N_PDS_Node.h>
#include <N_PDS_ParMap.h>
#include <N_TOP_CktGraph.h>
#include <N_TOP_CktNode.h>
#include <N_TOP_CktNode_Dev.h>
#include <N_TOP_Misc.h>
#include <N_TOP_ParLSUtil.h>
#include <N_TOP_Topology.h>
#include <N_UTL_FeatureTest.h>
#include <N_UTL_OptionBlock.h>
#include <N_UTL_Stats.h>
#include <N_UTL_fwd.h>

#include <Epetra_Util.h>
#include <Teuchos_Utils.hpp>

namespace Xyce {
namespace Topo {

//-----------------------------------------------------------------------------
// Function      : ParLSUtil::ParLSUtil
// Purpose       : constructor
// Special Notes :
// Scope         : public
// Creator       : Eric Keiter  SNL, Parallel Computational Sciences
// Creation Date : 5/25/05
//-----------------------------------------------------------------------------
ParLSUtil::ParLSUtil(
  Topology &            topology,
  const IO::CmdParse &  command_line,
  IO::HangingResistor & hanging_resistor,
  N_PDS_Manager &       pds_manager)
  : Linear::QueryUtil(),
    topology_(topology),
    commandLine_ (command_line),
    hangingResistor_(hanging_resistor),
    pdsManager_(pds_manager),
    numGlobalNodes_(0),
    numLocalNodes_(0),
    baseNodeGID_(0),
    numGlobalRows_(0),
    numLocalRows_(0),
    numExternRows_(0),
    numGlobalExternRows_(0),
    baseRowGID_(0),
    numGlobalStateVars_(0),
    numLocalStateVars_(0),
    numExternStateVars_(0),
    numGlobalExternStateVars_(0),
    baseStateVarGID_(0),
    numGlobalStoreVars_(0),
    numLocalStoreVars_(0),
    numExternStoreVars_(0),
    numGlobalExternStoreVars_(0),
    baseStoreVarGID_(0),
    numGlobalLeadCurrentVars_(0),
    numLocalLeadCurrentVars_(0),
    numExternLeadCurrentVars_(0),
    numGlobalExternLeadCurrentVars_(0),
    baseLeadCurrentVarGID_(0),
    numGlobalNZs_(0),
    numLocalNZs_(0)
{
}

//-----------------------------------------------------------------------------
// Function      : ParLSUtil::operator<<
// Purpose       : generate utility with reference to topology
// Special Notes :
// Scope         : public
// Creator       : Rob Hoekstra, SNL, Parallel Computational Sciences
// Creation Date : 6/15/00
//-----------------------------------------------------------------------------
std::ostream & operator<< (std::ostream & os, const ParLSUtil & tlsu )
{
  os << "Parallel Topology LS Utility" << std::endl;
  os << "-------------------" << std::endl;
  os << "ProcID: " << tlsu.pdsManager_.getPDSComm()->procID() << std::endl;
  os << "Num Global Nodes: " << tlsu.numGlobalNodes_ << std::endl;
  os << "Num Local Nodes: " << tlsu.numLocalNodes_ << std::endl;
  os << "Num Global Rows: " << tlsu.numGlobalRows_ << std::endl;
  os << "Num Local Rows: " << tlsu.numLocalRows_ << std::endl;
  os << "Num Extern Rows: " << tlsu.numExternRows_ << std::endl;
  os << "Num Global Extern Rows: " << tlsu.numGlobalExternRows_ << std::endl;
  os << "Row GID Base: " << tlsu.baseRowGID_ << std::endl;

  os << "Num Global State Vars: " << tlsu.numGlobalStateVars_ << std::endl;
  os << "Num Local State Vars: " << tlsu.numLocalStateVars_ << std::endl;
  os << "Num Extern State Vars: " << tlsu.numExternStateVars_ << std::endl;
  os << "Num Global Extern State Vars: " << tlsu.numGlobalExternStateVars_ << std::endl;
  os << "State Var GID Base: " << tlsu.baseStateVarGID_ << std::endl;

  os << "Num Global Store Vars: " << tlsu.numGlobalStoreVars_ << std::endl;
  os << "Num Local Store Vars: " << tlsu.numLocalStoreVars_ << std::endl;
  os << "Num Extern Store Vars: " << tlsu.numExternStoreVars_ << std::endl;
  os << "Num Global Extern Store Vars: " << tlsu.numGlobalExternStoreVars_ << std::endl;
  os << "Store Var GID Base: " << tlsu.baseStoreVarGID_ << std::endl;

  os << "Num Global LeadCurrent Vars: " << tlsu.numGlobalLeadCurrentVars_ << std::endl;
  os << "Num Local LeadCurrent Vars: " << tlsu.numLocalLeadCurrentVars_ << std::endl;
  os << "Num Extern LeadCurrent Vars: " << tlsu.numExternLeadCurrentVars_ << std::endl;
  os << "Num Global Extern LeadCurrent Vars: " << tlsu.numGlobalExternLeadCurrentVars_ << std::endl;
  os << "LeadCurrent Var GID Base: " << tlsu.baseLeadCurrentVarGID_ << std::endl;

  os << "Num Global NZs: " << tlsu.numGlobalNZs_ << std::endl;
  os << "Num Local NZs: " << tlsu.numLocalNZs_ << std::endl;

  os << "Node Array: ";
  for( int i = 0; i < tlsu.numLocalNodes_; ++i )
    os << tlsu.nodeList_GID_[i] << " ";
  os << std::endl;

  os << "Extern Node Array: ";
  for( unsigned int i = 0; i < tlsu.nodeList_ExternGID_.size(); ++i )
    os << tlsu.nodeList_ExternGID_[i].first << " " <<
	tlsu.nodeList_ExternGID_[i].second << "   ";
  os << std::endl;

  os << "GID Array: ";
  for( int i = 0; i < tlsu.numLocalRows_; ++i )
    os << tlsu.rowList_GID_[i] << " ";
  os << std::endl;

  os << "Extern GID Array: ";
  for( unsigned int i = 0; i < tlsu.rowList_ExternGID_.size(); ++i )
    os << tlsu.rowList_ExternGID_[i].first << " " <<
	tlsu.rowList_ExternGID_[i].second << "   ";
  os << std::endl;

  os << "State GID Array: ";
  for( int i = 0; i < tlsu.numLocalStateVars_; ++i )
    os << tlsu.rowList_StateGID_[i] << " ";
  os << std::endl;

  os << "Extern State GID Array: ";
  for( unsigned int i = 0; i < tlsu.rowList_ExternStateGID_.size(); ++i )
    os << tlsu.rowList_ExternStateGID_[i].first << " " <<
	tlsu.rowList_ExternStateGID_[i].second << "   ";
  os << std::endl;

  os << "Store GID Array: ";
  for( int i = 0; i < tlsu.numLocalStoreVars_; ++i )
    os << tlsu.rowList_StoreGID_[i] << " ";
  os << std::endl;

  os << "Extern Store GID Array: ";
  for( unsigned int i = 0; i < tlsu.rowList_ExternStoreGID_.size(); ++i )
    os << tlsu.rowList_ExternStoreGID_[i].first << " " <<
	tlsu.rowList_ExternStoreGID_[i].second << "   ";
  os << std::endl;

  os << "LeadCurrent GID Array: ";
  for( int i = 0; i < tlsu.numLocalLeadCurrentVars_; ++i )
    os << tlsu.rowList_LeadCurrentGID_[i] << " ";
  os << std::endl;

  os << "Extern LeadCurrent GID Array: ";
  for( unsigned int i = 0; i < tlsu.rowList_ExternLeadCurrentGID_.size(); ++i )
    os << tlsu.rowList_ExternLeadCurrentGID_[i].first << " " <<
	tlsu.rowList_ExternLeadCurrentGID_[i].second << "   ";
  os << std::endl;

  os << "NZ Array: ";
  for( int i = 0; i < tlsu.numLocalRows_; ++i )
    os << tlsu.rowList_NumNZs_[i] << " ";
  os << std::endl;

  os << "Col Index Array: " << std::endl;
  for( int i = 0; i < tlsu.numLocalRows_; ++i )
  {
    os << tlsu.rowList_GID_[i] << ": ";
    for( std::vector<int>::const_iterator it_iL = tlsu.rowList_ColList_[i].begin();
	it_iL != tlsu.rowList_ColList_[i].end(); ++it_iL )
      os << (*it_iL) << " ";
    os << std::endl;
  }

  return os;
}

//-----------------------------------------------------------------------------
// Function      : ParLSUtil::setupRowCol
// Purpose       : Setup row/col data for linear solver including reorder
// Special Notes :
// Scope         : public
// Creator       : Rob Hoekstra, SNL, Parallel Computational Sciences
// Creation Date : 2/1/01
//-----------------------------------------------------------------------------
bool ParLSUtil::setupRowCol()
{
  topology_.generateOrderedNodeList();

  N_PDS_Comm & comm = *pdsManager_.getPDSComm();
  int procCnt = comm.numProc();
  int procID = comm.procID();

  //construct v-node and d-node directories
  typedef RCP< Xyce::Parallel::IndexNode > IndexNodePtr;

  typedef std::multimap< std::string, IndexNodePtr > VNodeContainer;
  typedef std::map< std::string, IndexNodePtr > INodeContainer;

  typedef Xyce::Parallel::Hash<std::string> StringHash;
  typedef Xyce::Parallel::Migrate<std::string,Xyce::Parallel::IndexNode> INMigrate;

  typedef Xyce::Parallel::Directory< std::string,
                                     Xyce::Parallel::IndexNode,
                                     StringHash,
                                     VNodeContainer,
                                     INMigrate >
    VNodeDir;

  StringHash SHobj( procCnt );
  INMigrate Mobj( comm );

  //loop over node list and setup IndexNodes for Vs, register with VDir 
  VNodeDir VDir( Mobj, SHobj );

  //data for directory registration
  INodeContainer VData;

  //vectors for retrieval
  std::vector<std::string> VNames;
  VNames.reserve( int(topology_.getOrderedNodeList().size()/2) );

  //find all voltage nodes connected to a voltage source in case we
  // need to force these nodes to be on the same processor
  int dSize=0;
  unordered_set<std::string> Vsrc_Connected_Nodes;
  for (CktNodeList::const_iterator it_cnL = topology_.getOrderedNodeList().begin(), end_cnL = topology_.getOrderedNodeList().end(); it_cnL != end_cnL; ++it_cnL )
  {
    const std::string & id = (*it_cnL)->get_id();
    int type = (*it_cnL)->type();

    if (DEBUG_TOPOLOGY)
      Xyce::dout() << "Considering nodes for: " << id << std::endl;

    if  (type == _DNODE)
    {
      std::string::size_type col = id.find_first_of(':');
      if ( id[col+1] == 'V' || id[col+1] == 'v'
           || id.substr(col+1,col+6) == "yiso2"
           || id.substr(col+1,col+6) == "YISO2"
           || id.substr(col+1,col+5) == "yext"
           || id.substr(col+1,col+5) == "YEXT" )
      {
        if (DEBUG_TOPOLOGY)
          Xyce::dout() << "Getting adjacent nodes for: " << id << std::endl;

        std::vector<NodeID> adj_ids;
        topology_.returnAdjIDs( NodeID(id,type), adj_ids );
        int adjSize = adj_ids.size();
        for( int i = 0; i < adjSize; ++i )
        {
          if (DEBUG_TOPOLOGY)
            Xyce::dout() << "adj_ids["<<i<<"] = " << adj_ids[i] << std::endl;

          if( adj_ids[i].first != "0" )
          {
            Vsrc_Connected_Nodes.insert(adj_ids[i].first);
          }
        }
      }
    
      // Count the number of device nodes. 
      dSize++;
    }
    else if (type == _VNODE && id != "0")
    {
      IndexNodePtr inode( new Xyce::Parallel::IndexNode( -99, procID ) );
      VData[id] = inode;
      VNames.push_back( id );
    }
  }

  if (DEBUG_TOPOLOGY)
    Xyce::dout() << "Vsrc_Connected_Nodes:"<<std::endl;

  unordered_set<std::string>::iterator its = Vsrc_Connected_Nodes.begin();
  unordered_set<std::string>::iterator fts = Vsrc_Connected_Nodes.end();
  for( ; its != fts; ++its )
  {
    if (DEBUG_TOPOLOGY)
      Xyce::dout() << *its << std::endl;

    VData[ *its ]->gid = -98;
  }

  VDir.addEntries( VData );
 
  //v-node use multimap, pick owner
  //locally loop over container in VDir, pick an owner
  //random choice of owner
  VNodeContainer & VNodes = VDir.container();
  VNodeContainer::iterator iterVN = VNodes.begin();
  VNodeContainer::iterator endVN = VNodes.end();
  VNodeContainer OwnedVNodes;

  std::string id("");
  while( iterVN != endVN )
  {
    int proc = -1;

    id = iterVN->first;
    if( iterVN->second->gid == -98 ) proc = iterVN->second->pid;

    IndexNodePtr inode( new Xyce::Parallel::IndexNode( -99, iterVN->second->pid ) );

    ++iterVN;
    if( (iterVN != endVN) && (id == iterVN->first) )
    {
      std::vector<int> intVec;
      intVec.push_back(inode->pid);
      while( (iterVN != endVN) && (iterVN->first == id) )
      {
        if( iterVN->second->gid == -98 ) proc = iterVN->second->pid;

        intVec.push_back( iterVN->second->pid );
        ++iterVN;
      }
      if( proc != -1 )
      {
        inode->pid = proc;
        if (DEBUG_TOPOLOGY)
          std::cout << "pNode: " << id << " " << proc << std::endl;
      }
      else
      {
        random_shuffle( intVec.begin(), intVec.end() );
        inode->pid = *(intVec.begin());
      }
    }

    OwnedVNodes.insert( VNodeContainer::value_type( id, inode ) );
  }

  VNodes = OwnedVNodes;
  OwnedVNodes.clear();

  //gids for both
  //locally loop over containers in VDir and DDir and set GIDs
  int VSize = VNodes.size();
  double tmpVar1, tmpVar2;

  tmpVar1 = static_cast<double>(VSize);
  comm.scanSum( &tmpVar1, &tmpVar2, 1 );
  int baseVNodeGID = static_cast<int>(tmpVar2) - VSize;

  comm.sumAll( &tmpVar1, &tmpVar2, 1 );
  int globalVNodeCnt = static_cast<int>(tmpVar2);

  int currGID = baseVNodeGID;
  iterVN = VNodes.begin();
  for( ; iterVN != endVN; ++iterVN, ++currGID )
    iterVN->second->gid = currGID;

  //compute base GID for device nodes to be used later
  tmpVar1 = static_cast<double>(dSize);
  comm.scanSum( &tmpVar1, &tmpVar2, 1 );
  int baseDNodeGID = static_cast<int>(tmpVar2) - dSize + globalVNodeCnt;

  //push indices back
  //do gets on VDir to get ownership and GIDs
  VData.clear();

  VDir.getEntries( VNames, VData );

  currGID = baseDNodeGID;
  for (CktNodeList::const_iterator it_cnL = topology_.getOrderedNodeList().begin(), end_cnL = topology_.getOrderedNodeList().end(); it_cnL != end_cnL; ++it_cnL )
  {
    CktNode & cn = **it_cnL;
    const std::string & id = cn.get_id();
    int type = cn.type();

    if( id != "0" )
    {
      if( type == _VNODE )
      {
        IndexNodePtr inode = VData[id];
        cn.set_gID( inode->gid );
        cn.set_ProcNum( inode->pid );
        cn.set_IsOwned( procID == inode->pid );
      }
      else if( type == _DNODE )
      {
        cn.set_gID( currGID++ );
        cn.set_ProcNum( procID );
        cn.set_IsOwned( true );
      }
    }
    else
    {
      cn.set_gID( -1 );
      cn.set_ProcNum( -1 );
      cn.set_IsOwned( false );
    }
  }

  if (DEBUG_TOPOLOGY)
  {
  comm.barrier();

  for( int i = 0; i < procCnt; ++i )
  {
    if( i == procID )
    {
      Xyce::dout() << "<<<<<<<<<<<<<ORIGINAL INDEX NODES>>>>>>>>>>>>>>>>>>>>>> " << procID << "\n";
      CktNodeList::const_iterator itL2 = topology_.getOrderedNodeList().begin();
      CktNodeList::const_iterator endL2 = topology_.getOrderedNodeList().end();
      for( int i = 0 ; itL2 != endL2; ++itL2, ++i )
      {
        Xyce::dout() << "Proc: " << procID << "\t" << "Node: " << i << std::endl;
        Xyce::dout() << **itL2;
      }
      Xyce::dout() << "<<<<<<<<ORIGINAL INDEX NODES END>>>>>>>>>>>>>>>>>>>>>> " << procID << "\n";
    }
    comm.barrier();
  }

  comm.barrier();
  }

  setupNodeGIDs();

  if (DEBUG_TOPOLOGY)
  {
  comm.barrier();

  for( int i = 0; i < procCnt; ++i )
  {
    if( i == procID )
    {
      Xyce::dout() << "<<<<<<<<<<<<<REINDEXED NODES>>>>>>>>>>>>>>>>>>>>>> " << procID << "\n";
      CktNodeList::const_iterator itL2 = topology_.getOrderedNodeList().begin();
      CktNodeList::const_iterator endL2 = topology_.getOrderedNodeList().end();
      for( int i = 0 ; itL2 != endL2; ++itL2, ++i )
      {
        Xyce::dout() << "Proc: " << procID << "\t" << "Node: " << i << std::endl;
        Xyce::dout() << **itL2;
      }
      Xyce::dout() << "<<<<<<<<REINDEXED NODES END>>>>>>>>>>>>>>>>>>>>>> " << procID << "\n";
    }
    comm.barrier();
  }

  comm.barrier();
  }

  setupSolnAndStateGIDs();

  if (DEBUG_TOPOLOGY)
    Xyce::dout() << topology_ << std::endl;

  topology_.registerGIDswithDevs();

  if( checkConnectivity_ )
  { 
    //Setup index to GID map in CktGraph
    topology_.regenerateGIDNodeMap();
    
    testVoltageNodeConnectivity_();
  }

  //resolve late dependencies for devices
  topology_.resolveDependentVars();

  extractAllGIDsFromTopology();

  generateRowColData();

#ifdef Xyce_PARALLEL_MPI

  //Added 1/3/08, KRS:  For correct parallel implementation, we need to
  //put all of the information from each proc in the noDCPathGIDVector_ and
  //connToOneTermGIDVector_ back onto proc 0.  If we don't, and the parallel
  //run is taking place on different machines (rather than one machine with
  //multiple procs), then each machine will open up a local copy of the netlist
  //copy file and write to this file *only* those resistors which correspond to
  //nodes owned by that machine.
  generateGlobalNoDCPathList();
  generateGlobalConnToOneTermList();

  if (procID == 0)
  {

#endif
    bool netlistcopy = hangingResistor_.getNetlistCopy();
    std::string netlistFilename("");
    if (commandLine_.getArgumentValue("netlist") != "")
    {
      netlistFilename = commandLine_.getArgumentValue("netlist");
    }
    bool oneTermNotNoDCPath = true;
    //We use this boolean to print a different banner depending upon whether
    //resistors are being added because they are connected to only one device
    //terminal, or if they are being added because they have no DC path to
    //ground.


    //append resistors to nodes with only one terminal connection.

    if (netlistcopy && !connToOneTermIDVector_.empty())
    {
      std::string onetermres(hangingResistor_.getOneTermRes());
      topology_.addResistors(connToOneTermIDVector_,onetermres,netlistFilename,
                             oneTermNotNoDCPath);
    }


    //append resistors to nodes with no dc path to ground.
    if (netlistcopy && !noDCPathIDVector_.empty())
    {
      std::string nodcpathres(hangingResistor_.getNoDCPathRes());
      topology_.addResistors(noDCPathIDVector_,nodcpathres,netlistFilename,
                             !oneTermNotNoDCPath);

    }

    //if we've requested to produce a netlist file with resistors between
    //dangling nodes and ground, but it turns out that there aren't any
    //dangling nodes, we just need to add a ".END" to the end of the netlist
    //file copy that we produced in the I/O Interface Package (not critical).
    if (netlistcopy)
    {
      topology_.appendEndStatement(netlistFilename);
    }

#if defined(Xyce_PARALLEL_MPI)
  }
#endif

  //Don't remove this!!!!!!!!
  return true;
}

//-----------------------------------------------------------------------------
// Function      : ParLSUtil::testVoltageNodeConnectivity
// Purpose       : testing of voltage node connectivity for problems
// Special Notes : initially, just warn if a voltage node has only 1 connection
// Scope         : public
// Creator       : Rob Hoekstra, SNL, Parallel Computational Sciences
// Creation Date : 10/31/03
//-----------------------------------------------------------------------------
bool ParLSUtil::testVoltageNodeConnectivity_()
{
  std::map<int,std::string> cName;

  CktNodeList::const_iterator it_cnL = topology_.getOrderedNodeList().begin();
  CktNodeList::const_iterator end_cnL = topology_.getOrderedNodeList().end();

#if defined(Xyce_PARALLEL_MPI)
  N_PDS_Comm & comm = *(pdsManager_.getPDSComm());
  int procCnt = comm.numProc();
  int procID = comm.procID();
  int m, n;
  int proc;
#endif
  int i, j, k;
  int gid, num_gid;
  std::vector<int> gidList;
  std::vector<int> a,b;
  std::vector<int> candidates;
  std::map<int,int> my_vnodes;
  std::map<int, std::vector<int> > gid_map;
  std::map<int, std::vector<int> >::iterator gm_i;
  std::map<int, std::vector<int> >::iterator gm_end;

#if defined(Xyce_PARALLEL_MPI)
  std::vector<int> comm_pe;
  std::map< int, std::set<int> > comm_gid;
  std::map< int, std::set<int> >::iterator cg_i;
  std::map< int, std::set<int> >::iterator cg_end;
  std::set<int>::iterator vm_i;
  std::set<int>::iterator vm_end;

  it_cnL = topology_.getOrderedNodeList().begin();
  for( ; it_cnL != end_cnL; ++it_cnL )
  {
    if ((*it_cnL)->type() == _VNODE)
    {
      gid = (*it_cnL)->get_gID();
      if (gid >= 0 && !(*it_cnL)->get_IsOwned())
      {
        proc = (*it_cnL)->get_ProcNum();
        comm_gid[proc].insert(gid);
      }
    }
  }

  int num_proc = comm_gid.size();
  int max_num_proc = 0;
  comm.maxAll (&num_proc, &max_num_proc, 1);

  int tmpSize = procCnt*max_num_proc;
  std::vector<int> pcomm    (tmpSize,0);
  std::vector<int> pcomm_all(tmpSize,0);
  std::vector<int> ncomm    (tmpSize,0);
  std::vector<int> ncomm_all(tmpSize,0);

  i = 0;
  cg_i   = comm_gid.begin();
  cg_end = comm_gid.end() ;
  for (; cg_i!=cg_end; ++cg_i)
  {
    pcomm[procID*max_num_proc+i] = (*cg_i).first+1;
    ncomm[procID*max_num_proc+i] = (*cg_i).second.size();
    i++;
  }
  comm.sumAll(&pcomm[0], &pcomm_all[0], tmpSize);
  comm.sumAll(&ncomm[0], &ncomm_all[0], tmpSize);

  std::vector<std::vector<int> > buf;
  std::vector<int> sendBuf;
  std::vector<int> src;
  int numMsg = 0;

  // Allocate receive buffers
  for (i=0 ; i<procCnt*max_num_proc ; ++i)
  {
    if (pcomm_all[i] == procID+1)
    {
      j = i/max_num_proc;
      k = ncomm_all[i];
      buf.resize(numMsg+1);
      buf[numMsg].resize(k);
      src.push_back(j);
      numMsg++;
    }
  }

  // Issue receives
  for (i=0 ; i<numMsg ; ++i)
  {
    comm.iRecv (&buf[i][0], buf[i].size(), src[i]);
  }

  // Issue sends
  cg_i=comm_gid.begin();
  for ( ; cg_i!=cg_end; ++cg_i)
  {
    i = (*cg_i).second.size();
    sendBuf.resize(i);
    j = 0;
    vm_i=(*cg_i).second.begin();
    vm_end=(*cg_i).second.end();
    for ( ; vm_i !=vm_end; ++vm_i)
    {
      sendBuf[j++] = *vm_i;
    }
    comm.send (&sendBuf[0], i, (*cg_i).first);
  }

  // Wait for messages to complete
  comm.waitAll();

  // Use received data
  for (i=0 ; i<numMsg ; ++i)
  {
    k = buf[i].size();
    for (m=0 ; m<k ; ++m)
      comm_gid[src[i]].insert(buf[i][m]);
  }

  int n_bufs = comm_gid.size();
  std::vector<int> buf_dest(n_bufs), buf_len(n_bufs);
  std::vector<int *> buf_in(n_bufs), buf_out(n_bufs);
  std::vector< std::vector<int> > buf_gid(n_bufs);

  int buf_tot = 0;
  cg_i   = comm_gid.begin();
  cg_end = comm_gid.end();
  for ( ; cg_i!=cg_end; ++cg_i)
  {
    buf_tot += (*cg_i).second.size();
  }

  std::vector<int> actual_buf_in(buf_tot);
  std::vector<int> actual_buf_out(buf_tot);

  i = 0;
  m = 0;
  n = 0;
  cg_i   = comm_gid.begin();
  cg_end = comm_gid.end();
  for ( ; cg_i!=cg_end; ++cg_i)
  {
    j = (*cg_i).second.size();
    buf_dest[i] = (*cg_i).first;
    buf_len[i] = j;
    buf_in[i] = &actual_buf_in[m];
    buf_out[i] = &actual_buf_out[m];
    buf_gid[i].resize(j);
    m += j;

    k = 0;
    vm_i   = (*cg_i).second.begin();
    vm_end = (*cg_i).second.end();
    for ( ; vm_i !=vm_end; ++vm_i)
    {
      buf_in[i][k] = 0;
      buf_out[i][k] = 0;
      buf_gid[i][k] = *vm_i;
      gid_map[*vm_i].push_back(n+k);
      ++k;
    }
    n += k;
    ++i;
  }

  for (i=0 ; i<buf_tot ; ++i)
  {
    actual_buf_out[i] = 0;
  }

  it_cnL = topology_.getOrderedNodeList().begin();
  for( ; it_cnL != end_cnL; ++it_cnL )
  {
    if ((*it_cnL)->type() == _VNODE)
    {
      gid = (*it_cnL)->get_gID();
      if (gid >= 0)
      {
        num_gid = topology_.numAdjNodes( gid );
        if (num_gid > 0 && !((*it_cnL)->get_IsOwned()))
        {
          if (gid_map.find(gid) != gid_map.end())
          {
            actual_buf_out[gid_map[gid][0]] = num_gid;
          }
        }
      }
    }
  }

  comm_boundaries (gid_map, actual_buf_in, actual_buf_out,
                   buf_len, buf_dest, buf_in, buf_out, 1);
#endif

  bool oneTerm = hangingResistor_.getOneTerm();

  candidates.clear();
  it_cnL = topology_.getOrderedNodeList().begin();
  for( ; it_cnL != end_cnL; ++it_cnL )
  {
    if ((*it_cnL)->type() == _VNODE)
    {
      gid = (*it_cnL)->get_gID();
      if (gid >= 0)
      {
        num_gid = topology_.numAdjNodes( gid );
#if defined(Xyce_PARALLEL_MPI)
        if (num_gid <= 1 && (*it_cnL)->get_IsOwned())
        {
          if (gid_map.find(gid) == gid_map.end() ||
              (gid_map.find(gid) != gid_map.end() &&
               num_gid + actual_buf_in[gid_map[gid][0]] <= 1))
          {
#else
        if (num_gid <= 1)
        {
#endif
            candidates.push_back(gid);
            cName[gid] = (*it_cnL)->get_id();

            if(oneTerm)
            {
              (*it_cnL)->setTrueConnToOneTermVar();
            }
#if defined(Xyce_PARALLEL_MPI)
          }
#endif
        }
      }
    }
  }

  outputTopoWarnings (candidates, cName,
                      std::string("connected to only 1 device Terminal"));

  std::map<int, int> gid_pos;
  std::map<int, int>::iterator gp_i;
  std::map<int, int>::iterator gp_end;
  candidates.clear();

  it_cnL = topology_.getOrderedNodeList().begin();
  int num_nodes = 0;
  for( ; it_cnL != end_cnL; ++it_cnL )
  {
    if ((*it_cnL)->type() == _VNODE)
    {
      gid = (*it_cnL)->get_gID();
      if (gid >= 0)
        gid_pos[gid] = num_nodes++;
    }
  }
  std::vector<int> node_val (num_nodes,0);

  gp_i   = gid_pos.begin();
  gp_end = gid_pos.end();
  for ( ; gp_i != gp_end; ++gp_i)
  {
    node_val[(*gp_i).second] = (*gp_i).first;
  }
#if defined(Xyce_PARALLEL_MPI)
  i = 0;
  std::vector<int> ext_gid  (gid_pos.size(),0);
  gm_i   = gid_map.begin();
  gm_end = gid_map.end();
  for ( ; gm_i != gm_end; ++gm_i)
  {
    if (gid_pos.find((*gm_i).first) != gid_pos.end())
    {
      ext_gid[i] = gid_pos[(*gm_i).first];
      ++i;
    }
    else
    {
      Report::DevelFatal0()
        << "ParLSUtil::testVoltageNodeConnectivity_: External GID not found internally";
    }
  }
#endif

  it_cnL = topology_.getOrderedNodeList().begin();
  cName.clear();
  for( ; it_cnL != end_cnL; ++it_cnL )
  {
    if ((*it_cnL)->type() == _DNODE)
    {
      const std::vector<int> & lead_conn = (*it_cnL)->leadConnect();
      i = lead_conn.size();

      if (i > 0)
      {
        int gid = (*it_cnL)->get_gID();
        gidList.clear();
        topology_.returnAdjGIDs(gid, gidList);
        std::vector<int>::iterator gl = gidList.begin();
        const std::vector<int> & solnList = (*it_cnL)->get_ExtSolnVarGIDList();
        std::vector<int> GIDs;

        std::vector<int>::const_iterator sol_i   = solnList.begin();
        std::vector<int>::const_iterator sol_end = solnList.end();
        for ( ; sol_i!=sol_end; ++sol_i)
        {
          if (*sol_i == -1)
          {
            GIDs.push_back(-1);
          }
          else
          {
            GIDs.push_back(*(gl++));
          }
        }
        for (k=0 ; k<(int)lead_conn.size() ; ++k)
        {
          if (lead_conn[k] == 0)
          {
            if (GIDs[k] >= 0)
            {
              node_val[gid_pos[GIDs[k]]] = -1;
            }
            i--;
          }
        }
        for (j=1 ; j<10 ; ++j)
        {
          int last = -100;
          for (k=0 ; k<(int)lead_conn.size() ; ++k)
          {
            if (lead_conn[k] == j)
            {
              i--;
              if (last == -100)
              {
                last = GIDs[k];
              }
              else
              {
                if (last == -1)
                {
                  if (GIDs[k] >= 0)
                    node_val[gid_pos[GIDs[k]]] = -1;
                }
                else
                {
                  if (GIDs[k] >= 0)
                  {
                    a.push_back(gid_pos[last]);
                    b.push_back(gid_pos[GIDs[k]]);
                  }
                  else
                    node_val[gid_pos[last]] = -1;
                }
                if (GIDs[k] < last)
                  last = GIDs[k];
              }
            }
          }
          if (i == 0)
          {
            break;
          }
        }
        if (i != 0)
        {
          Report::DevelFatal0() 
            <<  " Connectivity checker: lead index not found.  This checker is limited to devices with less than ten leads.  If you have gotten this error, and the circuit contains a device with more connections than this, you may need to run Xyce with this diagnostic turned off, via:\n  .options topology CHECK_CONNECTIVITY=0 ";
        }
      } // if (i > 0)
    } // if ((*it_cnL)->type() == _DNODE)
  } // for( ; it_cnL != end_cnL; ++it_cnL )

  bool same_local, same = false;
  while (!same)
  {
    same = true;
    same_local = false;
    while (!same_local)
    {
      same_local = true;
      for (i=0 ; i<(int)a.size() ; ++i)
      {
        if (node_val[a[i]] < node_val[b[i]])
        {
          node_val[b[i]] = node_val[a[i]];
          same_local = false;
        }
        else if (node_val[b[i]] < node_val[a[i]])
        {
          node_val[a[i]] = node_val[b[i]];
          same_local = false;
        }
      }
      if (!same_local)
        same = false;
    }
#if defined(Xyce_PARALLEL_MPI)
    i = 0;
    gm_i   = gid_map.begin();
    gm_end = gid_map.end();
    for ( ; gm_i != gm_end; ++gm_i)
    {
      actual_buf_out[(*gm_i).second[0]] = node_val[ext_gid[i]];
      ++i;
    }
    comm_boundaries
      (gid_map, actual_buf_in, actual_buf_out,
       buf_len, buf_dest, buf_in, buf_out, 2);
    i = 0;
    gm_i   = gid_map.begin();
    gm_end = gid_map.end();
    for ( ; gm_i != gm_end; ++gm_i)
    {
      if (node_val[ext_gid[i]] > actual_buf_in[(*gm_i).second[0]])
      {
        node_val[ext_gid[i]] = actual_buf_in[(*gm_i).second[0]];
        same = false;
      }
      ++i;
    }
    if (same)
    {
      j = 1;
    }
    else
    {
      j = 0;
    }
    comm.sumAll(&j, &k, 1);
    if (k == procCnt)
    {
      same = true;
    }
    else
    {
      same = false;
    }
#endif
  }

  bool noDCPath = hangingResistor_.getNoDCPath();

  cName.clear();
  candidates.clear();
  for (i=0 ; i<(int)node_val.size() ; ++i)
  {
    if (node_val[i] != -1)
    {
      it_cnL = topology_.getOrderedNodeList().begin();
      for( ; it_cnL != end_cnL; ++it_cnL )
      {
        if ((*it_cnL)->type() == _VNODE)
        {
          gid = (*it_cnL)->get_gID();
          if (gid >= 0 && node_val[gid_pos[gid]] >= 0)
          {
            candidates.push_back(gid);
            const std::string & id = (*it_cnL)->get_id();
            cName[gid] = id;
            if (!(*it_cnL)->getConnToOneTermVar() && noDCPath)
              //We let 'connected to one
            {                                   //terminal' take precedence
              (*it_cnL)->setTrueNoDCPathVar();  //over 'no DC path.'  (Don't
            }                                   //want to label a node as
          }                                     //*both* being connected to only one
        }                                       //terminal and having no DC path to ground
      }                                         //since this will cause the addition of two
      break;                                    //resistors instead of just one.
    }
  }

  outputTopoWarnings (candidates, cName,
                      std::string("does not have a DC path to ground"));

  return true;
}

//-----------------------------------------------------------------------------
// Function      : ParLSUtil::comm_boundaries
// Purpose       : communicate boundary node data for topological checks
// Special Notes : mode=1 is sum, mode=2 is min
// Scope         : private
// Creator       : Dave Shirley, PSSI
// Creation Date : 09/09/05
//-----------------------------------------------------------------------------
    void ParLSUtil::comm_boundaries (std::map<int, std::vector<int> > & gid_map,
                                      std::vector<int> & actual_buf_in, std::vector<int> & actual_buf_out,
                                      std::vector<int> & buf_len, std::vector<int> & buf_dest,
                                      std::vector<int *> & buf_in, std::vector<int *> & buf_out, int mode)

    {
      N_PDS_Comm & comm = *(pdsManager_.getPDSComm());
      unsigned int i;
      unsigned int n_bufs = buf_len.size();
      std::map< int, std::map<int, bool> >::iterator cg_i;
      std::map<int, std::vector<int> >::iterator g_i = gid_map.begin() ;
      std::map<int, std::vector<int> >::iterator g_end = gid_map.end();
      for ( ; g_i != g_end; ++g_i)
      {
        if ((*g_i).second.size() > 1)
        {
          for (i=1 ; i<(*g_i).second.size() ; ++i)
            actual_buf_out[(*g_i).second[i]] = actual_buf_out[(*g_i).second[0]];
        }
      }

      for (i = 0 ; i < n_bufs ; ++i)
      {
        comm.iRecv (buf_in[i], buf_len[i], buf_dest[i]);
      }
      for (i = 0 ; i < n_bufs ; ++i)
      {
        comm.send (buf_out[i], buf_len[i], buf_dest[i]);
      }
      comm.waitAll();

      g_i = gid_map.begin();
      g_end = gid_map.end();
      for ( ; g_i != g_end; ++g_i)
      {
        if ((*g_i).second.size() > 1)
        {
          for (i=1 ; i<(*g_i).second.size() ; ++i)
          {
            if (mode == 1)
              actual_buf_in[(*g_i).second[0]] += actual_buf_in[(*g_i).second[i]];
            else if (mode == 2)
            {
              if (actual_buf_in[(*g_i).second[i]] < actual_buf_in[(*g_i).second[0]])
                actual_buf_in[(*g_i).second[0]] = actual_buf_in[(*g_i).second[i]];
            }
          }
        }
      }

      return;
    }

//-----------------------------------------------------------------------------
// Function      : ParLSUtil::outputTopoWarnings
// Purpose       : Output warnings from node connectivity checks
// Special Notes :
// Scope         : private
// Creator       : Dave Shirley, PSSI
// Creation Date : 06/21/05
//-----------------------------------------------------------------------------
    void ParLSUtil::outputTopoWarnings(std::vector<int> & candidates,
                                        std::map<int,std::string> & cName,
                                        std::string errMsg)
    {
      std::set<std::string> warnings;

#if defined(Xyce_PARALLEL_MPI)
      N_PDS_Comm & comm = *(pdsManager_.getPDSComm());
      int procCnt = comm.numProc();
      int procID = comm.procID();

      std::vector<int> candidates_all (procCnt,0);
      std::vector<int> candidates_sum (procCnt,0);

      int bs;

      for (int i=0 ; i<procCnt ; ++i)
        candidates_all[i] = 0;
      candidates_all[procID] = candidates.size();
      comm.sumAll(&candidates_all[0], &candidates_sum[0], procCnt);
#else
      int procID = 0;
#endif
      if (candidates.size() > 0)
      {
        for (unsigned i=0 ; i < candidates.size() ; ++i)
        {
          if (procID == 0)
          {
            std::string msg("Voltage Node (" + cName[candidates[i]] + ") " + errMsg);
            warnings.insert(msg);
          }
#if defined(Xyce_PARALLEL_MPI)
          else
          {
            bs = cName[candidates[i]].size();
            comm.send (&bs, 1, 0);
            comm.send (&cName[candidates[i]][0], cName[candidates[i]].size(), 0);
          }
#endif
        }
      }

#if defined(Xyce_PARALLEL_MPI)
      if (procID == 0)
      {
        std::string bad;
        std::string buf;

        for (int i=1 ; i<procCnt ; ++i)
        {
          for (int j=0 ; j<candidates_sum[i] ; ++j)
          {
            comm.recv (&bs, 1, i);
            buf.resize(bs);
            comm.recv (&buf[0], bs, i);
            bad = buf;
            std::string msg("Voltage Node (" + bad + ") " + errMsg);
            warnings.insert(msg);
          }
        }
      }
#endif
      if (procID == 0 && !warnings.empty())
      {
        std::set<std::string>::iterator warn = warnings.begin();
        for ( ; warn != warnings.end() ; ++warn)
        {
          Report::UserWarning0() <<  *warn;
        }
      }
    }

//-----------------------------------------------------------------------------
// Function      : ParLSUtil::setupNodeGIDs
// Purpose       : Generate Ordering and Var GIDs.
// Special Notes :
// Scope         : public
// Creator       : Rob Hoekstra, SNL, Parallel Computational Sciences
// Creation Date : 2/22/01
//-----------------------------------------------------------------------------
    bool ParLSUtil::setupNodeGIDs()
    {
      //get lists of owned and boundary/ghost node GIDs
      topology_.generateOrderedNodeList();

      extractNodeGIDs();

      numLocalNodes_ = nodeList_GID_.size();

      //calculate base GID for this processors nodes, lex. ordering
      double tmpVar1, tmpVar2;
      tmpVar1 = numLocalNodes_;
      pdsManager_.getPDSComm()->scanSum( &tmpVar1, &tmpVar2, 1 );
      baseNodeGID_ = static_cast<int>(tmpVar2 - numLocalNodes_);
      pdsManager_.getPDSComm()->sumAll( &tmpVar1, &tmpVar2, 1 );
      numGlobalNodes_ = static_cast<int>(tmpVar2);

      //Setup temp global accessors
      //Use to get new node GIDs for boundary/ghost nodes
      //---------------------------
      N_PDS_GlobalAccessor * nodeGlobalAccessorPtr = pdsManager_.createGlobalAccessor();
      nodeGlobalAccessorPtr->registerExternGIDVector( nodeList_ExternGID_ );
      nodeGlobalAccessorPtr->generateMigrationPlan();

      std::map<int,int> nodeGIDMap;
      std::vector<int>::const_iterator it_nL = nodeList_GID_.begin();
      for( int iSV = 0; it_nL != nodeList_GID_.end(); ++it_nL, ++iSV )
        nodeGIDMap[ *it_nL ] = iSV + baseNodeGID_;

      std::map<int,int> externGIDMap;
      nodeGlobalAccessorPtr->migrateIntArray( nodeGIDMap, externGIDMap );
      delete nodeGlobalAccessorPtr;

      //loop over nodes and reset all GIDs to new lex. ordering
      for (CktNodeList::const_iterator it_cnL = topology_.getOrderedNodeList().begin(), end_cnL = topology_.getOrderedNodeList().end(); it_cnL != end_cnL; ++it_cnL )
      {
        std::map<int,int>::const_iterator gotGID = nodeGIDMap.find( (*it_cnL)->get_gID() );
        if( gotGID != nodeGIDMap.end() )
        {
          (*it_cnL)->set_gID( gotGID->second );

          if (DEBUG_TOPOLOGY)
            Xyce::dout() << "Node: " << (*it_cnL)->get_id() << " " << (*it_cnL)->get_gID() << std::endl;

        }
        else
        {
          std::map<int,int>::const_iterator gotExtGID = externGIDMap.find( (*it_cnL)->get_gID() );

          if( gotExtGID != externGIDMap.end() )
          {
            (*it_cnL)->set_gID( gotExtGID->second );
          }
          else if( (*it_cnL)->get_gID() != -1 )
          {
            Report::DevelFatal0() << "P" <<  Teuchos::Utils::toString(pdsManager_.getPDSComm()->procID())
                                  << ": Node: " << (*it_cnL)->get_id() << ", global index ("
                                  <<  Teuchos::Utils::toString( (*it_cnL)->get_gID() ) << ") is NOT found!";
          }
        }
      }

      //Reset global accessor for new lex. indexing
      topology_.generateOrderedNodeList();

      extractNodeGIDs();

      return true;
    }

#ifndef HAVE_IOTA
// iota is not part of the C++ standard.  It is an extension.
namespace {

template <class _ForwardIterator, class _Tp>
void
iota(_ForwardIterator __first, _ForwardIterator __last, _Tp __value)
{
  while (__first != __last)
    *__first++ = __value++;
}

} // namespace <unnamed>
#endif


//-----------------------------------------------------------------------------
// Function      : ParLSUtil::setupSolnAndStateGIDs
// Purpose       : Generate Ordering and Var GIDs.
// Special Notes :
// Scope         : public
// Creator       : Rob Hoekstra, SNL, Parallel Computational Sciences
// Creation Date : 3/2/01
//-----------------------------------------------------------------------------
bool ParLSUtil::setupSolnAndStateGIDs()
{
  //get soln and state var counts from all owned v-nodes and d-nodes
  std::vector<int> rowCountVec(numLocalNodes_);
  std::vector<int> stateCountVec(numLocalNodes_);
  std::vector<int> storeCountVec(numLocalNodes_);
  std::vector<int> leadCurrentCountVec(numLocalNodes_);

  double tmpVar1, tmpVar2;
  int Loc = 0;
  numLocalRows_ = 0;
  numLocalStateVars_ = 0;
  numLocalStoreVars_ = 0;
  numLocalLeadCurrentVars_ = 0;
  for (CktNodeList::const_iterator it_cnL = topology_.getOrderedNodeList().begin(), end_cnL = topology_.getOrderedNodeList().end(); it_cnL != end_cnL; ++it_cnL )
    if( (*it_cnL)->get_IsOwned() && (*it_cnL)->get_gID() != -1 )
    {
      rowCountVec[Loc] = (*it_cnL)->solnVarCount();
      numLocalRows_ += rowCountVec[Loc];
      stateCountVec[Loc] = (*it_cnL)->stateVarCount();
      numLocalStateVars_ += stateCountVec[Loc];
      storeCountVec[Loc] = (*it_cnL)->storeVarCount();
      numLocalStoreVars_ += storeCountVec[Loc];
      leadCurrentCountVec[Loc] = (*it_cnL)->branchDataVarCount();
      numLocalLeadCurrentVars_ += leadCurrentCountVec[Loc];
      ++Loc;
    }

#ifdef Xyce_PARALLEL_MPI

  //calculate base soln and state GIDs for this processor
  tmpVar1 = numLocalRows_;
  pdsManager_.getPDSComm()->scanSum( &tmpVar1, &tmpVar2, 1 );
  baseRowGID_ = static_cast<int>(tmpVar2 - numLocalRows_);
  pdsManager_.getPDSComm()->sumAll( &tmpVar1, &tmpVar2, 1 );
  numGlobalRows_ = static_cast<int>(tmpVar2);

  tmpVar1 = numLocalStateVars_;
  pdsManager_.getPDSComm()->scanSum( &tmpVar1, &tmpVar2, 1 );
  baseStateVarGID_ = static_cast<int>(tmpVar2 - numLocalStateVars_);
  pdsManager_.getPDSComm()->sumAll( &tmpVar1, &tmpVar2, 1 );
  numGlobalStateVars_ = static_cast<int>(tmpVar2);

  tmpVar1 = numLocalStoreVars_;
  pdsManager_.getPDSComm()->scanSum( &tmpVar1, &tmpVar2, 1 );
  baseStoreVarGID_ = static_cast<int>(tmpVar2 - numLocalStoreVars_);
  pdsManager_.getPDSComm()->sumAll( &tmpVar1, &tmpVar2, 1 );
  numGlobalStoreVars_ = static_cast<int>(tmpVar2);

  tmpVar1 = numLocalLeadCurrentVars_;
  pdsManager_.getPDSComm()->scanSum( &tmpVar1, &tmpVar2, 1 );
  baseLeadCurrentVarGID_ = static_cast<int>(tmpVar2 - numLocalLeadCurrentVars_);
  pdsManager_.getPDSComm()->sumAll( &tmpVar1, &tmpVar2, 1 );
  numGlobalLeadCurrentVars_ = static_cast<int>(tmpVar2);

#else

  numGlobalRows_ = numLocalRows_;
  numGlobalStateVars_ = numLocalStateVars_;
  numGlobalStoreVars_ = numLocalStoreVars_;
  numGlobalLeadCurrentVars_ = numLocalLeadCurrentVars_;

#endif

  //Use Global Accessors to get GIDs for boundary/ghost nodes
  std::map< int,std::vector<int> > rowGIDMap, stateGIDMap;
  std::map< int,std::vector<int> > externRowGIDMap, externStateGIDMap;
  std::map< int,std::vector<int> > storeGIDMap;
  std::map< int,std::vector<int> > externStoreGIDMap;
  std::map< int,std::vector<int> > leadCurrentGIDMap;
  std::map< int,std::vector<int> > externLeadCurrentGIDMap;

  std::vector<int> tmpVec;
  int currRowLoc = baseRowGID_;
  int currStateLoc = baseStateVarGID_;
  int currStoreLoc = baseStoreVarGID_;
  int currLeadCurrentLoc = baseLeadCurrentVarGID_;
  for( int i = 0; i < numLocalNodes_; ++i )
  {
    tmpVec.resize(rowCountVec[i]);
    iota( tmpVec.begin(), tmpVec.end(), currRowLoc );
    rowGIDMap[ nodeList_GID_[i] ] = tmpVec;
    currRowLoc += rowCountVec[i];

    tmpVec.resize(stateCountVec[i]);
    iota( tmpVec.begin(), tmpVec.end(), currStateLoc );
    stateGIDMap[ nodeList_GID_[i] ] = tmpVec;
    currStateLoc += stateCountVec[i];

    tmpVec.resize(storeCountVec[i]);
    iota( tmpVec.begin(), tmpVec.end(), currStoreLoc );
    storeGIDMap[ nodeList_GID_[i] ] = tmpVec;
    currStoreLoc += storeCountVec[i];
    
    tmpVec.resize(leadCurrentCountVec[i]);
    iota( tmpVec.begin(), tmpVec.end(), currLeadCurrentLoc );
    leadCurrentGIDMap[ nodeList_GID_[i] ] = tmpVec;
    currLeadCurrentLoc += leadCurrentCountVec[i];
  }

  N_PDS_GlobalAccessor * nodeGlobalAccessorPtr = pdsManager_.createGlobalAccessor();
  nodeGlobalAccessorPtr->registerExternGIDVector( nodeList_ExternGID_ );
  nodeGlobalAccessorPtr->generateMigrationPlan();

  nodeGlobalAccessorPtr->migrateIntVecs( rowGIDMap, externRowGIDMap );
  nodeGlobalAccessorPtr->migrateIntVecs( stateGIDMap, externStateGIDMap );
  nodeGlobalAccessorPtr->migrateIntVecs( storeGIDMap, externStoreGIDMap );
  nodeGlobalAccessorPtr->migrateIntVecs( leadCurrentGIDMap, externLeadCurrentGIDMap );
  delete nodeGlobalAccessorPtr;

  //calculate number of boundary/ghost soln and state vars
  std::map< int,std::vector<int> >::iterator iterIVM = externRowGIDMap.begin();
  std::map< int,std::vector<int> >::iterator endIVM = externRowGIDMap.end();
  numExternRows_ = 0;
  for( ; iterIVM != endIVM; ++iterIVM )
    numExternRows_ += iterIVM->second.size();
  tmpVar1 = numExternRows_;
  pdsManager_.getPDSComm()->sumAll( &tmpVar1, &tmpVar2, 1 );
  numGlobalExternRows_ = static_cast<int>(tmpVar2);

  iterIVM = externStateGIDMap.begin();
  endIVM = externStateGIDMap.end();
  numExternStateVars_ = 0;
  for( ; iterIVM != endIVM; ++iterIVM )
    numExternStateVars_ += iterIVM->second.size();
  tmpVar1 = numExternStateVars_;
  pdsManager_.getPDSComm()->sumAll( &tmpVar1, &tmpVar2, 1 );
  numGlobalExternStateVars_ = static_cast<int>(tmpVar2);

  iterIVM = externStoreGIDMap.begin();
  endIVM = externStoreGIDMap.end();
  numExternStoreVars_ = 0;
  for( ; iterIVM != endIVM; ++iterIVM )
    numExternStoreVars_ += iterIVM->second.size();
  tmpVar1 = numExternStoreVars_;
  pdsManager_.getPDSComm()->sumAll( &tmpVar1, &tmpVar2, 1 );
  numGlobalExternStoreVars_ = static_cast<int>(tmpVar2);
  
  iterIVM = externLeadCurrentGIDMap.begin();
  endIVM = externLeadCurrentGIDMap.end();
  numExternLeadCurrentVars_ = 0;
  for( ; iterIVM != endIVM; ++iterIVM )
    numExternLeadCurrentVars_ += iterIVM->second.size();
  tmpVar1 = numExternLeadCurrentVars_;
  pdsManager_.getPDSComm()->sumAll( &tmpVar1, &tmpVar2, 1 );
  numGlobalExternLeadCurrentVars_ = static_cast<int>(tmpVar2);

  //loop over nodes and assign soln and state GIDs
  for (CktNodeList::const_iterator it_cnL = topology_.getOrderedNodeList().begin(), end_cnL = topology_.getOrderedNodeList().end(); it_cnL != end_cnL; ++it_cnL )
  {
    if( rowGIDMap.count( (*it_cnL)->get_gID() ) )
    {
      (*it_cnL)->set_SolnVarGIDList( rowGIDMap[ (*it_cnL)->get_gID() ] );
      (*it_cnL)->set_StateVarGIDList( stateGIDMap[ (*it_cnL)->get_gID() ] );
      (*it_cnL)->set_StoreVarGIDList( storeGIDMap[ (*it_cnL)->get_gID() ] );
      (*it_cnL)->set_LeadCurrentVarGIDList( leadCurrentGIDMap[ (*it_cnL)->get_gID() ] );
    }
    else if( externRowGIDMap.count( (*it_cnL)->get_gID() ) )
    {
      (*it_cnL)->set_SolnVarGIDList( externRowGIDMap[ (*it_cnL)->get_gID() ] );
      (*it_cnL)->set_StateVarGIDList( externStateGIDMap[ (*it_cnL)->get_gID() ] );
      (*it_cnL)->set_StoreVarGIDList( externStoreGIDMap[ (*it_cnL)->get_gID() ] );
      (*it_cnL)->set_LeadCurrentVarGIDList( externLeadCurrentGIDMap[ (*it_cnL)->get_gID() ] );
    }
    else if( (*it_cnL)->get_gID() == -1 )
      (*it_cnL)->set_SolnVarGIDList( std::vector<int>(1,-1) );
    else
    {
      Report::DevelFatal0() << "P" <<  Teuchos::Utils::toString(pdsManager_.getPDSComm()->procID())
                            << ": Node: " << (*it_cnL)->get_id() << ", global index ("
                            << Teuchos::Utils::toString( (*it_cnL)->get_gID() ) << ") is NOT found!";
    }
  }

  return true;

}

//-----------------------------------------------------------------------------
// Function      : ParLSUtil::generateRowColData
// Purpose       : Generate row/col data for linear solver.
// Special Notes :
// Scope         : public
// Creator       : Rob Hoekstra, SNL, Parallel Computational Sciences
// Creation Date : 5/26/00
//-----------------------------------------------------------------------------
void ParLSUtil::generateRowColData()
{
  int procID = pdsManager_.getPDSComm()->procID();

  //--- add in dep soln var stuff
  if( !topology_.getDepSolnGIDMap().empty() )
  {
    std::map<int,int> tmpMap;
    std::map<int,int>::const_iterator iterIIM = topology_.getDepSolnGIDMap().begin();
    std::map<int,int>::const_iterator endIIM = topology_.getDepSolnGIDMap().end();
    for( ; iterIIM != endIIM; ++iterIIM )
      if( iterIIM->second != procID ) tmpMap.insert( *iterIIM );

    for( unsigned int i = 0; i < rowList_ExternGID_.size(); ++i )
      if( rowList_ExternGID_[i].second  != procID )
        tmpMap.insert( rowList_ExternGID_[i] );

    rowList_ExternGID_.resize( tmpMap.size() );
    iterIIM = tmpMap.begin();
    for( unsigned int i = 0; i < tmpMap.size(); ++iterIIM, ++i )
      rowList_ExternGID_[i] = *iterIIM;
  }

  //--- add in dep state var stuff
  if( !topology_.getDepStateGIDMap().empty() )
  {
    std::map<int,int> tmpMap;
    std::map<int,int>::const_iterator iterIIM = topology_.getDepStateGIDMap().begin();
    std::map<int,int>::const_iterator endIIM = topology_.getDepStateGIDMap().end();
    for( ; iterIIM != endIIM; ++iterIIM )
      if( iterIIM->second != procID ) tmpMap.insert( *iterIIM );

    for( unsigned int i = 0; i < rowList_ExternStateGID_.size(); ++i )
      if( rowList_ExternStateGID_[i].second  != procID )
        tmpMap.insert( rowList_ExternStateGID_[i] );

    rowList_ExternStateGID_.resize( tmpMap.size() );
    iterIIM = tmpMap.begin();
    endIIM = tmpMap.end();
    for( int i = 0; iterIIM != endIIM; ++iterIIM, ++i )
      rowList_ExternStateGID_[i] = *iterIIM;
  }

  //--- add in dep store var stuff
  if( !topology_.getDepStoreGIDMap().empty() )
  {
    std::map<int,int> tmpMap;
    std::map<int,int>::const_iterator iterIIM = topology_.getDepStoreGIDMap().begin();
    std::map<int,int>::const_iterator endIIM = topology_.getDepStoreGIDMap().end();
    for( ; iterIIM != endIIM; ++iterIIM )
      if( iterIIM->second != procID ) tmpMap.insert( *iterIIM );

    for( unsigned int i = 0; i < rowList_ExternStoreGID_.size(); ++i )
      if( rowList_ExternStoreGID_[i].second  != procID )
        tmpMap.insert( rowList_ExternStoreGID_[i] );

    rowList_ExternStoreGID_.resize( tmpMap.size() );
    iterIIM = tmpMap.begin();
    endIIM = tmpMap.end();
    for( int i = 0; iterIIM != endIIM; ++iterIIM, ++i )
      rowList_ExternStoreGID_[i] = *iterIIM;
  }

  //--- add in dep store var stuff
  if( !topology_.getDepLeadCurrentGIDMap().empty() )
  {
    std::map<int,int> tmpMap;
    std::map<int,int>::const_iterator iterIIM = topology_.getDepLeadCurrentGIDMap().begin();
    std::map<int,int>::const_iterator endIIM = topology_.getDepLeadCurrentGIDMap().end();
    for( ; iterIIM != endIIM; ++iterIIM )
      if( iterIIM->second != procID ) tmpMap.insert( *iterIIM );

    for( unsigned int i = 0; i < rowList_ExternLeadCurrentGID_.size(); ++i )
      if( rowList_ExternLeadCurrentGID_[i].second  != procID )
        tmpMap.insert( rowList_ExternLeadCurrentGID_[i] );

    rowList_ExternLeadCurrentGID_.resize( tmpMap.size() );
    iterIIM = tmpMap.begin();
    endIIM = tmpMap.end();
    for( int i = 0; iterIIM != endIIM; ++iterIIM, ++i )
      rowList_ExternLeadCurrentGID_[i] = *iterIIM;
  }

  //--- set numLocalRows_, numLocalStateVars_, and resize lists
  numLocalRows_ = rowList_GID_.size();
  numExternRows_ = rowList_ExternGID_.size();
  numLocalStateVars_ = rowList_StateGID_.size();
  numExternStateVars_ = rowList_ExternStateGID_.size();
  numLocalStoreVars_ = rowList_StoreGID_.size();
  numExternStoreVars_ = rowList_ExternStoreGID_.size();
  numLocalLeadCurrentVars_ = rowList_LeadCurrentGID_.size();
  numExternLeadCurrentVars_ = rowList_ExternLeadCurrentGID_.size();

  double tmpVar1, tmpVar2;

  tmpVar1 = numLocalRows_;
  pdsManager_.getPDSComm()->sumAll( &tmpVar1, &tmpVar2, 1 );
  numGlobalRows_ = static_cast<int>(tmpVar2);

  tmpVar1 = numExternRows_;
  pdsManager_.getPDSComm()->sumAll( &tmpVar1, &tmpVar2, 1 );
  numGlobalExternRows_ = static_cast<int>(tmpVar2);

  tmpVar1 = numLocalStateVars_;
  pdsManager_.getPDSComm()->sumAll( &tmpVar1, &tmpVar2, 1 );
  numGlobalStateVars_ = static_cast<int>(tmpVar2);

  tmpVar1 = numExternStateVars_;
  pdsManager_.getPDSComm()->sumAll( &tmpVar1, &tmpVar2, 1 );
  numGlobalExternStateVars_ = static_cast<int>(tmpVar2);

  tmpVar1 = numLocalStoreVars_;
  pdsManager_.getPDSComm()->sumAll( &tmpVar1, &tmpVar2, 1 );
  numGlobalStoreVars_ = static_cast<int>(tmpVar2);

  tmpVar1 = numExternStoreVars_;
  pdsManager_.getPDSComm()->sumAll( &tmpVar1, &tmpVar2, 1 );
  numGlobalExternStoreVars_ = static_cast<int>(tmpVar2);

  tmpVar1 = numLocalLeadCurrentVars_;
  pdsManager_.getPDSComm()->sumAll( &tmpVar1, &tmpVar2, 1 );
  numGlobalLeadCurrentVars_ = static_cast<int>(tmpVar2);

  tmpVar1 = numExternLeadCurrentVars_;
  pdsManager_.getPDSComm()->sumAll( &tmpVar1, &tmpVar2, 1 );
  numGlobalExternLeadCurrentVars_ = static_cast<int>(tmpVar2);

  //--- block extern gids by processor to support aztec requirements
  if( numExternRows_ )
  {
    std::vector<int> externGIDs( numExternRows_ );
    std::vector<int> PIDs( numExternRows_ );
    for( int i = 0; i < numExternRows_; ++i )
    {
      externGIDs[i] = rowList_ExternGID_[i].first;
      PIDs[i] = rowList_ExternGID_[i].second;
    }

    Epetra_Util Util;
    int ** listPtr = new int *[1];
    listPtr[0] = &externGIDs[0];
    Util.Sort( true, numExternRows_, &PIDs[0], 0, 0, 1, listPtr );
    delete [] listPtr;

    for( int i = 0; i < numExternRows_; ++i )
      rowList_ExternGID_[i] = std::pair<int,int>( externGIDs[i], PIDs[i] );
  }

  if (DEBUG_TOPOLOGY)
    Xyce::dout() << "Parallel Topology Util Vals: " << std::endl
                 << numGlobalRows_ << " " << numLocalRows_ << std::endl
                 << numGlobalStateVars_ << " " << numLocalStateVars_ << std::endl
                 << numGlobalStoreVars_ << " " << numLocalStoreVars_ << std::endl
                 << numGlobalLeadCurrentVars_ << " " << numLocalLeadCurrentVars_ << std::endl;

  int numRows = numLocalRows_ + numExternRows_ + 1;

  //Build global to local map for speed
  std::map<int,int> GtoL_Map;
  for( int i = 0; i < numLocalRows_; ++i )
    GtoL_Map[ rowList_GID_[i] ] = i;
  for( int i = 0; i < numExternRows_; ++i )
    GtoL_Map[ rowList_ExternGID_[i].first ] = i + numLocalRows_;
  GtoL_Map[ -1 ] = numLocalRows_ + numExternRows_;

  rowList_ColList_.resize( numRows );
  rowList_NumNZs_.resize( numRows );

  int rcCnt = rowList_ColList_.size();
  for( int i = 0; i < rcCnt; ++i ) rowList_ColList_[i].clear();

  //    to compile a list of col indices for each row
  for (CktNodeList::const_iterator it_cnL = topology_.getOrderedNodeList().begin(), end_cnL = topology_.getOrderedNodeList().end(); it_cnL != end_cnL; ++it_cnL )
  {
    if( (*it_cnL)->type() == _DNODE )
    {
      const std::vector< std::vector<int> > & stamp = (*it_cnL)->jacobianStamp();
      const std::vector<int> & intGIDs = (*it_cnL)->get_SolnVarGIDList();
      const std::vector<int> & extGIDs = (*it_cnL)->get_ExtSolnVarGIDList();
      const std::vector<int> & depGIDs = (*it_cnL)->get_DepSolnGIDJacVec();
      std::vector<int> gids( intGIDs.size() + extGIDs.size() + depGIDs.size() );
      copy( extGIDs.begin(), extGIDs.end(), gids.begin() );
      copy( intGIDs.begin(), intGIDs.end(), gids.begin() + extGIDs.size() );
      copy( depGIDs.begin(), depGIDs.end(), gids.begin() + extGIDs.size() + intGIDs.size() );


      for( unsigned int i = 0; i < stamp.size(); ++i )
      {
        int length = stamp[i].size();
        for( int j = 0; j < length; ++j )
        {
          if (stamp[i][j] < (int)gids.size())
            rowList_ColList_[ GtoL_Map[ gids[i] ] ].push_back( gids[ stamp[i][j] ] );
        }
      }
    }
  }


  if (DEBUG_TOPOLOGY)
    Xyce::dout() << Xyce::section_divider << std::endl
                 << "Row List of NZ Cols extracted" << std::endl
                 << Xyce::section_divider << std::endl;

  numLocalNZs_ = 0;

#ifdef Xyce_NOX_LOCA_ARTIFICIAL_HOMOTOPY_SUPPORT
    //add in diagonal for homotopy support
    for( int i = 0; i < numLocalRows_; ++i )
      rowList_ColList_[i].push_back( rowList_GID_[i] );
    for( int i = 0; i < numExternRows_; ++i )
      rowList_ColList_[i+numLocalRows_].push_back( rowList_ExternGID_[i].first );
#endif

  //--- sort list of col indices and get rid of redundancies
  //    generate num of NZs data
  for( int i = 0; i < numRows; ++i )
  {
    // rowList_ColList_[i].sort();
    // rowList_ColList_[i].unique();
    std::sort(rowList_ColList_[i].begin(), rowList_ColList_[i].end());
    rowList_ColList_[i].erase(std::unique(rowList_ColList_[i].begin(), rowList_ColList_[i].end()), rowList_ColList_[i].end());

    rowList_NumNZs_[i] = rowList_ColList_[i].size();

    numLocalNZs_ += rowList_NumNZs_[i];
  }

  if (DEBUG_TOPOLOGY)
    Xyce::dout() << Xyce::section_divider << std::endl
                 << "Row List of NZ Cols cleaned up" << std::endl
                 << Xyce::section_divider << std::endl
                 << *this;

}

//-----------------------------------------------------------------------------
// Function      : ParLSUtil::generateGlobalNoDCPathList
// Purpose       : Generate row/col data for linear solver.
// Special Notes :
// Scope         : public
// Creator       : Rob Hoekstra, SNL, Parallel Computational Sciences
// Creation Date : 5/26/00
//-----------------------------------------------------------------------------
void ParLSUtil::generateGlobalNoDCPathList()
{
  //Need to compute and store the number of nodes in noDCPathGIDVector_ on
  //each processor

  N_PDS_Comm & comm = *(pdsManager_.getPDSComm());
  int procCnt = comm.numProc();
  int procID = comm.procID();

  std::vector<int> nodclength_local(procCnt,0);
  std::vector<int> nodclength_sum(procCnt,0);
  int j;

  for (j=0; j < procCnt ; j++)
  {
    if (j != procID)
      nodclength_local[j] = 0;
    else
      nodclength_local[j] = noDCPathIDVector_.size();
  }
  N_ERH_ErrorMgr::safeBarrier(pdsManager_.getPDSComm()->comm());

  comm.sumAll(&nodclength_local[0],&nodclength_sum[0],procCnt);

  //Broadcast the nodes to proc 0....
  if (procID != 0)
  {
    std::vector<std::string>::iterator nodcit = noDCPathIDVector_.begin();
    std::vector<std::string>::iterator nodcend = noDCPathIDVector_.end();
    int templength;

    while (nodcit != nodcend)
    {
      templength = (*nodcit).length();
      comm.send(&templength,1,0);
      comm.send(&(*nodcit)[0],templength,0);
      nodcit++;
    }
  }
  //....and let proc 0 receive.
  else
  {
    int templength;
    for (j=1; j < procCnt; j++)
    {
      for (int i=0; i < nodclength_sum[j]; i++)
      {
        comm.recv(&templength,1,j);
        std::string tempstring;
        tempstring.resize(templength);
        comm.recv(&tempstring[0],templength,j);
        noDCPathIDVector_.push_back(tempstring);
      }
    }
  }
  N_ERH_ErrorMgr::safeBarrier(pdsManager_.getPDSComm()->comm());
}

//-----------------------------------------------------------------------------
// Function      : ParLSUtil::generateGlobalConnToOneTermList
// Purpose       : Generate row/col data for linear solver.
// Special Notes :
// Scope         : public
// Creator       : Rob Hoekstra, SNL, Parallel Computational Sciences
// Creation Date : 5/26/00
//-----------------------------------------------------------------------------
void ParLSUtil::generateGlobalConnToOneTermList()
{
  //Need to compute and store the number of nodes in connToOneTermGIDVector_ on
  //each processor

  N_PDS_Comm & comm = *(pdsManager_.getPDSComm());
  int procCnt = comm.numProc();
  int procID = comm.procID();

  std::vector<int> connoneterm_local(procCnt,0);
  std::vector<int> connoneterm_sum(procCnt,0);
  int j;

  for (j=0; j < procCnt ; j++)
  {
    if (j != procID)
      connoneterm_local[j] = 0;
    else
      connoneterm_local[j] = connToOneTermIDVector_.size();
  }
  N_ERH_ErrorMgr::safeBarrier(pdsManager_.getPDSComm()->comm());

  comm.sumAll(&connoneterm_local[0],&connoneterm_sum[0],procCnt);

  //Broadcast the nodes to proc 0....
  if (procID != 0)
  {
    std::vector<std::string>::iterator connoneit = connToOneTermIDVector_.begin();
    std::vector<std::string>::iterator connoneend = connToOneTermIDVector_.end();
    int templength2;

    while (connoneit != connoneend)
    {
      templength2 = (*connoneit).length();
      comm.send(&templength2,1,0);
      comm.send(&(*connoneit)[0],templength2,0);
      connoneit++;
    }
  }
  //....and let proc 0 receive.
  else
  {
    int templength2;
    for (j=1; j < procCnt; j++)
    {
      for (int i=0; i < connoneterm_sum[j]; i++)
      {
	comm.recv(&templength2,1,j);
	std::string tempstring2;
	tempstring2.resize(templength2);
	comm.recv(&tempstring2[0],templength2,j);
	connToOneTermIDVector_.push_back(tempstring2);
      }
    }
  }
  N_ERH_ErrorMgr::safeBarrier(pdsManager_.getPDSComm()->comm());
}

//-----------------------------------------------------------------------------
// Function      : ParLSUtil::extractNodeGIDs
// Purpose       : Fill all GID vectors using ordered node list.
// Special Notes :
// Scope         : public
// Creator       : Rob Hoekstra, SNL, Parallel Computational Sciences
// Creation Date : 5/26/00
//-----------------------------------------------------------------------------
void ParLSUtil::extractNodeGIDs()
{
  nodeList_GID_.clear();
  nodeList_ExternGID_.clear();

  CktNodeList::const_iterator it = topology_.getOrderedNodeList().begin();
  CktNodeList::const_iterator end = topology_.getOrderedNodeList().end();

  for ( ; it != end; ++it )
  {
    if ( (*it)->get_gID() != -1 )
    {
      if( (*it)->get_IsOwned() )
      {
        nodeList_GID_.push_back( (*it)->get_gID() );
      }
      else
      {
        nodeList_ExternGID_.push_back( std::pair<int,int>( (*it)->get_gID(), (*it)->get_ProcNum() ) );
      }
    }
  }
}

//-----------------------------------------------------------------------------
// Function      : ParLSUtil::extractAllGIDsFromTopology
// Purpose       : Fill all GID vectors using ordered node list.
// Special Notes :
// Scope         : public
// Creator       : Rob Hoekstra, SNL, Parallel Computational Sciences
// Creation Date : 5/26/00
//-----------------------------------------------------------------------------
void ParLSUtil::extractAllGIDsFromTopology()
{
  // Clear all vectors.
  rowList_GID_.clear();
  rowList_ExternGID_.clear();
  rowList_StateGID_.clear();
  rowList_ExternStateGID_.clear();
  rowList_StoreGID_.clear();
  rowList_ExternStoreGID_.clear();
  rowList_LeadCurrentGID_.clear();
  rowList_ExternLeadCurrentGID_.clear();
  vnodeGIDVector_.clear();
  vsrcGIDVector_.clear();
  nonlinGIDVector_.clear();
  noDCPathIDVector_.clear();
  connToOneTermIDVector_.clear();

  CktNodeList::const_iterator it = topology_.getOrderedNodeList().begin();
  CktNodeList::const_iterator end = topology_.getOrderedNodeList().end();
  for ( ; it != end; ++it )
  {
    // Own this node, get solution, state, and store information.
    if( (*it)->get_IsOwned() && ( (*it)->get_gID() != -1 ) )
    {
      // Get solution variable GIDs.
      rowList_GID_.insert(rowList_GID_.end(),
          (*it)->get_SolnVarGIDList().begin(),
          (*it)->get_SolnVarGIDList().end());

      // Get state variable GIDs.
      if ((*it)->stateVarCount())
      {
        rowList_StateGID_.insert(rowList_StateGID_.end(),
            (*it)->get_StateVarGIDList().begin(),
            (*it)->get_StateVarGIDList().end());
      }

      // Get store variable GIDs.
      if ((*it)->storeVarCount())
      {
        rowList_StoreGID_.insert(rowList_StoreGID_.end(),
            (*it)->get_StoreVarGIDList().begin(),
            (*it)->get_StoreVarGIDList().end() );
      }

      // Get lead current variable GIDs.
      if ((*it)->branchDataVarCount())
      {
        rowList_LeadCurrentGID_.insert( rowList_LeadCurrentGID_.end(),
            (*it)->get_LeadCurrentVarGIDList().begin(),
            (*it)->get_LeadCurrentVarGIDList().end() );
      }

      // Collect voltage nodes.
      if ( (*it)->type() == _VNODE )
      {
        vnodeGIDVector_.push_back( *((*it)->get_SolnVarGIDList().begin()) );

        // Nodes with no DC path to ground.
        if ((*it)->getNoDCPathVar())
        {
          noDCPathIDVector_.push_back((*it)->get_id());
        }

        // Nodes with only one connection.
        if ((*it)->getConnToOneTermVar())
        {
          connToOneTermIDVector_.push_back((*it)->get_id());
        }
      }
    }

    // Do not own this node. Still get solution, state, and store information.
    if( !( (*it)->get_IsOwned() ) && ( (*it)->get_gID() != -1 ) )
    {
      // Get solution variable GIDs.
      std::vector<int>::const_iterator it_svL = (*it)->get_SolnVarGIDList().begin();
      std::vector<int>::const_iterator it_svL_end = (*it)->get_SolnVarGIDList().end();
      for (; it_svL != it_svL_end; ++it_svL )
      {
        rowList_ExternGID_.push_back( std::pair<int,int>( *it_svL, (*it)->get_ProcNum() ) );
      }

      // Get state variable GIDs.
      if ((*it)->stateVarCount())
      {
        it_svL = (*it)->get_StateVarGIDList().begin();
        it_svL_end = (*it)->get_StateVarGIDList().end();
        for( ; it_svL != it_svL_end; ++it_svL )
        {
          rowList_ExternStateGID_.push_back( std::pair<int,int>( *it_svL, (*it)->get_ProcNum() ) );
        }
      }

      // Get store variable GIDs.
      if ((*it)->storeVarCount())
      {
        it_svL = (*it)->get_StoreVarGIDList().begin();
        it_svL_end = (*it)->get_StoreVarGIDList().end();
        for( ; it_svL != it_svL_end; ++it_svL )
        {
          rowList_ExternStoreGID_.push_back( std::pair<int,int>( *it_svL, (*it)->get_ProcNum() ) );
        }
      }

      // Get lead current variable GIDs.
      if ((*it)->branchDataVarCount())
      {
        it_svL = (*it)->get_LeadCurrentVarGIDList().begin();
        it_svL_end = (*it)->get_LeadCurrentVarGIDList().end();
        for( ; it_svL != it_svL_end; ++it_svL )
        {
          rowList_ExternLeadCurrentGID_.push_back( std::pair<int,int>( *it_svL, (*it)->get_ProcNum() ) );
        }
      }
      
    }

    if ( (*it)->get_IsOwned() && ((*it)->type() == _DNODE) )
    {
      const std::string & id = (*it)->get_id();
      std::string::size_type col = id.find_first_of(':');

      if ( id[col+1] == 'V' || id[col+1] == 'v' )
      {
        vsrcGIDVector_.insert( vsrcGIDVector_.end(),
            (*it)->get_SolnVarGIDList().begin(),
            (*it)->get_SolnVarGIDList().end() );

        vsrcGIDVector_.insert( vsrcGIDVector_.end(),
            (*it)->get_ExtSolnVarGIDList().begin(),
            (*it)->get_ExtSolnVarGIDList().end() );
      }

      CktNode_Dev * cktNodeDevPtr = dynamic_cast<CktNode_Dev*>(*it);
      if (!(cktNodeDevPtr->deviceInstance()->isLinearDevice()))
      {
        nonlinGIDVector_.insert( nonlinGIDVector_.end(),
            (*it)->get_SolnVarGIDList().begin(),
            (*it)->get_SolnVarGIDList().end() );

        nonlinGIDVector_.insert( nonlinGIDVector_.end(),
            (*it)->get_ExtSolnVarGIDList().begin(),
            (*it)->get_ExtSolnVarGIDList().end() );
      }
    }
  } 

  // Make sure the nonlinGIDVector_ has unique entries.
  // First sort, then erase duplicates, then remove ground node GID.
  std::sort( nonlinGIDVector_.begin(), nonlinGIDVector_.end() );
  nonlinGIDVector_.erase(std::unique(nonlinGIDVector_.begin(), nonlinGIDVector_.end() ), nonlinGIDVector_.end() );
  if ( nonlinGIDVector_.size() > 0 )
  {
    if ( nonlinGIDVector_.front() == -1 )
      nonlinGIDVector_.erase( nonlinGIDVector_.begin() );
  }

}

} // namespace Topo
} // namespace Xyce
