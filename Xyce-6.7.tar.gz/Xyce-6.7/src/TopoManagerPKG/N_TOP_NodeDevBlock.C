//-----------------------------------------------------------------------------
// Copyright Notice
//
//   Copyright 2002 Sandia Corporation. Under the terms
//   of Contract DE-AC04-94AL85000 with Sandia Corporation, the U.S.
//   Government retains certain rights in this software.
//
//    Xyce(TM) Parallel Electrical Simulator
//    Copyright (C) 2002-2017 Sandia Corporation
//
//    This program is free software: you can redistribute it and/or modify
//    it under the terms of the GNU General Public License as published by
//    the Free Software Foundation, either version 3 of the License, or
//    (at your option) any later version.
//
//    This program is distributed in the hope that it will be useful,
//    but WITHOUT ANY WARRANTY; without even the implied warranty of
//    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//    GNU General Public License for more details.
//
//    You should have received a copy of the GNU General Public License
//    along with this program.  If not, see <http://www.gnu.org/licenses/>.
//-----------------------------------------------------------------------------

//-------------------------------------------------------------------------
//
// Purpose        :
//
// Special Notes  :
//
// Creator        : Robert J. Hoekstra, SNL, Parallel Computational Sciences
//
// Creation Date  : 3/3/01
//
//
//
//
//-------------------------------------------------------------------------

#include <Xyce_config.h>

#include <iostream>

#include <N_TOP_NodeDevBlock.h>
#include <N_PDS_Comm.h>
#include <N_UTL_FeatureTest.h>

namespace Xyce {
namespace Topo {

//-----------------------------------------------------------------------------
// Function      : NodeDevBlock::clear
// Purpose       :
// Special Notes :
// Scope         : public
// Creator       : Richard Schiek, Electrical and Microsystems modeling
// Creation Date : 2/8/2010
//-----------------------------------------------------------------------------
void NodeDevBlock::clear()
{
  devBlock_.clear();
  nodeList_.clear();
}


//-----------------------------------------------------------------------------
// Function      : NodeDevBlock::addNode
// Purpose       :
// Special Notes :
// Scope         : public
// Creator       : Dave Shirley
// Creation Date : 03/16/06
//-----------------------------------------------------------------------------
void NodeDevBlock::addNode(const std::string & p)
{
  nodeList_.push_back(p);
}

//-----------------------------------------------------------------------------
// Function      : NodeDevBlock::get_NodeList
// Purpose       :
// Special Notes :
// Scope         : public
// Creator       : Rob Hoekstra, SNL, Parallel Computational Sciences
// Creation Date : 5/18/00
//-----------------------------------------------------------------------------
const std::vector<std::string> & NodeDevBlock::get_NodeList() const
{
  return nodeList_;
}

//-----------------------------------------------------------------------------
// Function      : NodeDevBlock::get_NodeList
// Purpose       :
// Special Notes :
// Scope         : public
// Creator       : Rob Hoekstra, SNL, Parallel Computational Sciences
// Creation Date : 5/18/00
//-----------------------------------------------------------------------------
std::vector<std::string> & NodeDevBlock::get_NodeList() 
{
  return nodeList_;
}

//-----------------------------------------------------------------------------
//// Function      : NodeDevBlock::set_NodeList
//// Purpose       :
//// Special Notes :
//// Scope         : public
//// Creator       : Rob Hoekstra, SNL, Parallel Computational Sciences
//// Creation Date : 5/18/00
////-----------------------------------------------------------------------------
void NodeDevBlock::set_NodeList(const std::vector<std::string> & nList)
{
  nodeList_.assign(nList.begin(), nList.end());
}

//-----------------------------------------------------------------------------
// Function      : operator<<
// Purpose       :
// Special Notes :
// Scope         : public
// Creator       : Rob Hoekstra, SNL, Parallel Computational Sciences
// Creation Date : 3/3/01
//-----------------------------------------------------------------------------
std::ostream & operator<< ( std::ostream & os, const NodeDevBlock & ndb )
{
  os << "NodeDevBlock: " << ndb.devBlock_.getInstanceName().getEncodedName() << std::endl;
  os << " Connected Nodes: ";
  std::vector<std::string>::const_iterator it_tpL = ndb.get_NodeList().begin();
  std::vector<std::string>::const_iterator it_tpL_end = ndb.get_NodeList().end();
  for( ; it_tpL != it_tpL_end; ++it_tpL)
    os << "   " << *it_tpL;
  os << std::endl;

  if( ndb.isDevice() ) os << ndb.devBlock_ << std::endl;
  return os << std::endl;
}

} // namespace Topo

//-----------------------------------------------------------------------------
// Function      : NodeDevBlock::packedByteCount
// Purpose       : Counts number of bytes needed to pack object
// Special Notes :
// Scope         : public
// Creator       : Rob Hoekstra, SNL, Parallel Computational Sciences
// Creation Date : 6/13/00
//-----------------------------------------------------------------------------
template<>
int
Pack<Topo::NodeDevBlock>::packedByteCount(
  const Topo::NodeDevBlock &    node_device_block)
{
  int byteCount = 0;
  int length, size, i;
  std::vector<std::string>::const_iterator it_tpL;

  //flag for device
  byteCount += sizeof(int);

  if( node_device_block.isDevice() ) byteCount += Xyce::packedByteCount(node_device_block.devBlock_);

  size = node_device_block.nodeList_.size();
  byteCount += sizeof( int );
  it_tpL = node_device_block.nodeList_.begin();
  for( i = 0; i < size; ++i, ++it_tpL )
  {
    length = it_tpL->length();
    byteCount += sizeof( int );
    byteCount += length * sizeof( char );
  }

  return byteCount;
}

//-----------------------------------------------------------------------------
// Function      : NodeDevBlock::pack
// Purpose       : Packs NodeDevBlock into char buffer using MPI_PACK
// Special Notes :
// Scope         : public
// Creator       : Rob Hoekstra, SNL, Parallel Computational Sciences
// Creation Date : 3/3/01
//-----------------------------------------------------------------------------
template<>
void
Pack<Topo::NodeDevBlock>::pack(
  const Topo::NodeDevBlock &    node_device_block,
  char *                        buf,
  int                           bsize,
  int &                         pos,
  N_PDS_Comm *                  comm )
{
  int flag;
  int size, length;
  std::vector<std::string>::const_iterator it_tpL;

  //----- pack nodeBlock_ flag
  flag = node_device_block.isDevice() ? 1 : 0;
  comm->pack( &flag, 1, buf, bsize, pos );

  //----- pack nodeList_
  size = node_device_block.nodeList_.size();
  comm->pack( &size, 1, buf, bsize, pos );
  it_tpL = node_device_block.nodeList_.begin();
  for( int i = 0; i < size; ++i, ++it_tpL )
  {
    length = it_tpL->length();
    comm->pack( &length, 1, buf, bsize, pos );
    comm->pack( it_tpL->c_str(), length, buf, bsize, pos );
  }

  //----- pack devBlock_
  if( node_device_block.isDevice() ) Xyce::pack(node_device_block.devBlock_, buf, bsize, pos, comm );

  if (DEBUG_TOPOLOGY)
    Xyce::dout() << "Packed " << pos << " bytes for NodeDevBlock: " << node_device_block.devBlock_.getInstanceName().getEncodedName() << std::endl;
}

//-----------------------------------------------------------------------------
// Function      : NodeDevBlock::unpack
// Purpose       : Unpacks NodeDevBlock from char buffer using MPI_UNPACK
// Special Notes :
// Scope         : public
// Creator       : Rob Hoekstra, SNL, Parallel Computational Sciences
// Creation Date : 3/3/01
//-----------------------------------------------------------------------------
template<>
void
Pack<Topo::NodeDevBlock>::unpack(
  Topo::NodeDevBlock &  node_device_block,
  char *                pB,
  int                   bsize,
  int &                 pos,
  N_PDS_Comm *          comm )
{
  int flag;
  int size, length;
  double val;
  std::string tmpStr;

  //----- unpack nodeList_
  comm->unpack( pB, bsize, pos, &size, 1 );
  node_device_block.nodeList_.clear();
  for( int i = 0 ; i < size; ++i )
  {
    comm->unpack( pB, bsize, pos, &length, 1 );
    tmpStr = std::string( (pB+pos), length );
    node_device_block.nodeList_.push_back( tmpStr );
    pos += length;
  }

  comm->unpack( pB, bsize, pos, &flag, 1 );
  if( flag == 1 ) Xyce::unpack(node_device_block.devBlock_, pB, bsize, pos, comm );

  if (DEBUG_TOPOLOGY)
    Xyce::dout() << "Unpacked " << pos << " bytes for NodeDevBlock: " << node_device_block.devBlock_.getInstanceName().getEncodedName() << std::endl;
}

} // namespace Xyce
