//-----------------------------------------------------------------------------
// Copyright Notice
//
//   Copyright 2002 Sandia Corporation. Under the terms
//   of Contract DE-AC04-94AL85000 with Sandia Corporation, the U.S.
//   Government retains certain rights in this software.
//
//    Xyce(TM) Parallel Electrical Simulator
//    Copyright (C) 2002-2017 Sandia Corporation
//
//    This program is free software: you can redistribute it and/or modify
//    it under the terms of the GNU General Public License as published by
//    the Free Software Foundation, either version 3 of the License, or
//    (at your option) any later version.
//
//    This program is distributed in the hope that it will be useful,
//    but WITHOUT ANY WARRANTY; without even the implied warranty of
//    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//    GNU General Public License for more details.
//
//    You should have received a copy of the GNU General Public License
//    along with this program.  If not, see <http://www.gnu.org/licenses/>.
//-----------------------------------------------------------------------------

//-----------------------------------------------------------------------------
//
// Purpose        :
//
// Special Notes  :
//
// Creator        : Robert J. Hoekstra, SNL, Parallel Computational Sciences
//
// Creation Date  : 03/20/00
//
//
//
//
//-----------------------------------------------------------------------------

#ifndef N_TOP_CktNode_V_h
#define N_TOP_CktNode_V_h 1

#include <N_TOP_CktNode.h>

namespace Xyce {
namespace Topo {

//-----------------------------------------------------------------------------
// Class         : CktNode_V
// Purpose       :
// Special Notes :
// Creator       : Rob Hoekstra, SNL, Parallel Computational Sciences
// Creation Date : 5/16/00
//-----------------------------------------------------------------------------
class CktNode_V : public CktNode
{
public:
  // Constructor
  CktNode_V(const std::string & nodeID, const int & globalID = 0)
    : CktNode(nodeID, globalID),
    noDCPath_(false),
    connToOneTerm_(false)
    {}

private:
  // Copy constructor
  CktNode_V(const CktNode_V & right);
  CktNode_V &operator=(const CktNode_V & right);

public:
  // Destructor
  virtual ~CktNode_V() { }

  int type() const { return _VNODE; }

  int solnVarCount() const { return 1; }

  bool getNoDCPathVar() {return noDCPath_;} //See explanation in "private" 
                                            //section
  bool getConnToOneTermVar() {return connToOneTerm_;}

  void setTrueNoDCPathVar() { noDCPath_ = true;}
  
  void setTrueConnToOneTermVar() { connToOneTerm_ = true;}

  virtual void loadNodeSymbols(Topology &topology) const;

  virtual void varTypeList( std::vector<char> & varTypeVec ) const;
  
  std::ostream & put(std::ostream & os) const;

private:
  //These new boolean variables are being introduced to detect nodes for 
  //which there is no DC path to ground or nodes which are only connected to
  //one device terminal.  Detection of these situations is being used to 
  //(optionally) add large resistors between such nodes and ground  

  bool noDCPath_;
  bool connToOneTerm_;

};

} // namespace Topo
} // namespace Xyce

#endif
