//-----------------------------------------------------------------------------
// Copyright Notice
//
//   Copyright 2002 Sandia Corporation. Under the terms
//   of Contract DE-AC04-94AL85000 with Sandia Corporation, the U.S.
//   Government retains certain rights in this software.
//
//    Xyce(TM) Parallel Electrical Simulator
//    Copyright (C) 2002-2017 Sandia Corporation
//
//    This program is free software: you can redistribute it and/or modify
//    it under the terms of the GNU General Public License as published by
//    the Free Software Foundation, either version 3 of the License, or
//    (at your option) any later version.
//
//    This program is distributed in the hope that it will be useful,
//    but WITHOUT ANY WARRANTY; without even the implied warranty of
//    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//    GNU General Public License for more details.
//
//    You should have received a copy of the GNU General Public License
//    along with this program.  If not, see <http://www.gnu.org/licenses/>.
//-----------------------------------------------------------------------------

//-----------------------------------------------------------------------------
//
// Purpose        :
//
// Special Notes  :
//
// Creator        : Robert J. Hoekstra, SNL, Parallel Computational Sciences
//
// Creation Date  : 03/20/00
//
//
//
//
//-----------------------------------------------------------------------------

#ifndef N_TOP_CktNode_h
#define N_TOP_CktNode_h

#include <iosfwd>
#include <string>
#include <list>
#include <vector>
#include <map>

#include <N_TOP_fwd.h>

#include <N_TOP_Misc.h>
#include <N_UTL_IndexPair.h>

namespace Xyce {
namespace Topo {

//-----------------------------------------------------------------------------
// Class         : CktNode
// Purpose       :
// Special Notes :
// Creator       : Rob Hoekstra, SNL, Parallel Computational Sciences
// Creation Date : 5/16/00
//-----------------------------------------------------------------------------
class CktNode
{
  friend std::ostream & operator << (std::ostream & os, const CktNode & cn);

public:
  CktNode(
    const std::string & nodeID,
    const int & globalID = 0)
    : id_(nodeID),
      gID_(globalID),
      procNum_(0),
      isOwned_(true),
      Offset_(-1),
      solnVarGIDList_()
  {}

  // Destructor
  virtual ~CktNode() { }

private:
  CktNode(const CktNode &);
  CktNode &operator=(const CktNode &);

public:
  bool operator == (const CktNode & right) const { return id_ == right.id_; }
  bool operator != (const CktNode & right) const { return id_ != right.id_; }

  //-------- get and set methods for attributes

  // Get circuit node id.
  const std::string & get_id() const { return id_; }

  // Set circuit node id.
  void set_id(const std::string & value) { id_ = value; }

  // Get circuit node global id.
  const int & get_gID() const { return gID_; }

  // Set circuit node global id.
  void set_gID(const int & globalID) { gID_ = globalID; }

  virtual int type() const = 0;

  //The following get/set functions are only used in CktNode_V class
  //to access and change the noDCPath_ and connToOneTermVar_ internal variables
  //These boolean variables are not defined in the other derived classes, so
  //we create dummy functions there that do nothing.

  virtual bool getNoDCPathVar() = 0;

  virtual bool getConnToOneTermVar() = 0;

  virtual void setTrueNoDCPathVar() = 0;

  virtual void setTrueConnToOneTermVar() = 0;

  const std::vector<int> & get_SolnVarGIDList() const {
    return solnVarGIDList_;
  }

  std::vector<int> & get_SolnVarGIDList() {
    return solnVarGIDList_;
  }

  void set_SolnVarGIDList(const std::vector<int> & svGIDVec) {
    solnVarGIDList_ = svGIDVec;
  }

  const std::vector<int> & get_ExtSolnVarGIDList() const {
    return extSolnVarGIDList_;
  }

  std::vector<int> & get_ExtSolnVarGIDList() {
    return extSolnVarGIDList_;
  }

  void set_ExtSolnVarGIDList(const std::vector<int> & svGIDList) {
    extSolnVarGIDList_ = svGIDList;
  }

  virtual const std::vector<int> & get_StateVarGIDList() const {
    static std::vector<int> dummy;
    return dummy;
  }

  virtual std::vector<int> & get_StateVarGIDList() {
    static std::vector<int> dummy;
    return dummy;
  }

  virtual void set_StateVarGIDList(const std::vector<int> & svGIDList) 
  {}

  virtual const std::vector<int> & get_StoreVarGIDList() const {
    static std::vector<int> dummy;
    return dummy;
  }

  virtual std::vector<int> & get_StoreVarGIDList() {
    static std::vector<int> dummy;
    return dummy;
  }

  virtual void set_StoreVarGIDList(const std::vector<int> & svGIDList)
  {}

  virtual const std::vector<int> & get_LeadCurrentVarGIDList() const {
    static std::vector<int> dummy;
    return dummy;
  }

  virtual std::vector<int> & get_LeadCurrentVarGIDList() {
    static std::vector<int> dummy;
    return dummy;
  }

  virtual void set_LeadCurrentVarGIDList(const std::vector<int> & lcvGIDList) 
  {}

  virtual void get_DepSolnGIDVec(std::vector< std::vector<int> > & dsGIDs) const {
    dsGIDs.clear();
  }

  virtual void set_DepSolnGIDVec(const std::vector< std::vector<int> > & dsGIDs) 
  {}

  virtual void get_DepStateGIDVec(std::vector< std::vector<int> > & dsGIDs) const {
    dsGIDs.clear();
  }

  virtual void set_DepStateGIDVec(const std::vector< std::vector<int> > & dsGIDs) 
  {}

  virtual void get_DepStoreGIDVec(std::vector< std::vector<int> > & dsGIDs) const {
    dsGIDs.clear();
  }

  virtual void set_DepStoreGIDVec(const std::vector< std::vector<int> > & dsGIDs) 
  {}

  // Get the processor number.
  const int & get_ProcNum() const { return procNum_; }

  // Set the processor number.
  void set_ProcNum(const int & pNum) { procNum_ = pNum; }

  // Get the processor ownership flag.
  const bool & get_IsOwned() const { return isOwned_; }

  // Set the processor ownership flag.
  void set_IsOwned(const bool & owned) { isOwned_ = owned; }

  const int & get_Offset() const { return Offset_; }

  void set_Offset(const int & Offset) { Offset_ = Offset; }

  virtual const std::vector< std::vector<int> > & jacobianStamp() const {
    static std::vector< std::vector<int> > dummy;
    return dummy;
  }
  
  virtual void registerJacLIDswithDev( const std::vector< std::vector<int> > & jacLIDVec )
  {}

  virtual void registerGIDDataWithDev(
    const std::vector<int> & counts,
    const std::vector<int> & GIDs,
    const std::vector< std::vector<int> > & jacGIDs )
  {}

  //------- Added for use with the outputFileName function
  virtual void loadNodeSymbols(Topology &topology) const = 0;

  virtual void varTypeList( std::vector<char> & varTypeVec ) const = 0;

  //------- registration of global ids with device instances

  virtual int solnVarCount() const {
    return solnVarGIDList_.size();
  }

  virtual int extSolnVarCount() const {
    return extSolnVarGIDList_.size();
  }

  virtual int stateVarCount() const {
    return 0; 
  }

  virtual int storeVarCount() const {
    return 0;
  }

  virtual int branchDataVarCount() const {
    return 0;
  }

  virtual int depSolnVarCount() const { return 0; }

  virtual int depStateVarCount() const { return 0; }

  virtual int depStoreVarCount() const { return 0; }

  virtual const std::vector<int> & leadConnect() const
  {
    static std::vector<int> dummy;
    return dummy;
  }

  virtual void registerGIDswithDev(
    const IndexPairVector & intGIDList,
    const IndexPairVector & extGIDList)
  {}

  virtual void registerStateGIDswithDev( const IndexPairVector & stateGIDList) {}
  virtual void registerStoreGIDswithDev( const IndexPairVector & storeGIDList) {}
  virtual void registerLeadCurrentGIDswithDev( const IndexPairVector & leadCurrentGIDList) {}

  virtual void registerLIDswithDev( const std::vector<int> & intLIDVec,
                                    const std::vector<int> & extLIDVec ) {}
  virtual void registerStateLIDswithDev( const std::vector<int> & stateLIDVec ) {}
  virtual void registerStoreLIDswithDev( const std::vector<int> & storeLIDVec ) {}
  virtual void registerLeadCurrentLIDswithDev( const std::vector<int> & leadCurrentLIDVec ) {}

  virtual void registerDepLIDswithDev( const std::vector< std::vector<int> > & depLIDVec ) {}
  virtual void registerDepStateLIDswithDev( const std::vector< std::vector<int> > & depStateLIDVec ) {}
  virtual void registerDepStoreLIDswithDev( const std::vector< std::vector<int> > & depStoreLIDVec ) {}
  virtual void registerDepLeadCurrentLIDswithDev( const std::vector< std::vector<int> > & depLeadCurrentLIDVec ) {}

  virtual void getDepSolnVars( std::vector< NodeID >& dsVars ) {
    dsVars.clear();
  }

  virtual void registerDepSolnGIDs( const std::vector< std::vector<int> > & dsGIDs) {}

  virtual void getDepStateVars( std::vector< NodeID >& dsVars ) {
    dsVars.clear();
  }

  virtual void registerDepStateGIDs(const std::vector< std::vector<int> > & dsGIDs)
  {}

  virtual void getDepStoreVars( std::vector< NodeID >& dsVars ) {
    dsVars.clear();
  }

  virtual void registerDepStoreGIDs(const std::vector< std::vector<int> > & dsGIDs)
  {}

  virtual void getDepLeadCurrentVars( std::vector< NodeID >& dlcVars ) {
    dlcVars.clear();
  }

  virtual void registerDepLeadCurrentGIDs(const std::vector< std::vector<int> > & dlcGIDs)
  {}

  virtual const std::vector<int> & get_DepSolnGIDJacVec() { 
    static std::vector<int> dummy;
    return dummy;
  }

  virtual std::ostream & put(std::ostream & os) const = 0;

protected:
  std::string                   id_;            /// Node id.
  int                           gID_;           /// Global node id.
  int                           procNum_;       /// Processor number.
  bool                          isOwned_;       /// Processor ownership flag.
  int                           Offset_;

  std::vector<int>              solnVarGIDList_;                /// Solution variable global id list.
  std::vector<int>              extSolnVarGIDList_;
};

} // namespace Topo
} // namespace Xyce

#endif
