//-----------------------------------------------------------------------------
// Copyright Notice
//
//   Copyright 2002 Sandia Corporation. Under the terms
//   of Contract DE-AC04-94AL85000 with Sandia Corporation, the U.S.
//   Government retains certain rights in this software.
//
//    Xyce(TM) Parallel Electrical Simulator
//    Copyright (C) 2002-2017 Sandia Corporation
//
//    This program is free software: you can redistribute it and/or modify
//    it under the terms of the GNU General Public License as published by
//    the Free Software Foundation, either version 3 of the License, or
//    (at your option) any later version.
//
//    This program is distributed in the hope that it will be useful,
//    but WITHOUT ANY WARRANTY; without even the implied warranty of
//    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//    GNU General Public License for more details.
//
//    You should have received a copy of the GNU General Public License
//    along with this program.  If not, see <http://www.gnu.org/licenses/>.
//-----------------------------------------------------------------------------

//-------------------------------------------------------------------------
// Filename       : $RCSfile: N_LAS_HBBlockMatrixEntry.C,v $
//
// Purpose        : HB Block Matrix
//
// Special Notes  :
//
// Creator        : Heidi Thornquist, SNL 
//
// Creation Date  : 12/7/2016
//
// Revision Information:
// ---------------------
//
// Revision Number: $Revision: 1.3 $
//
// Revision Date  : $Date: 2016/03/16 22:14:27 $
//
// Current Owner  : $Author: hkthorn $
//-------------------------------------------------------------------------

#include <N_LAS_HBBlockMatrixEntry.h>
#include <N_ERH_ErrorMgr.h>
#include <numeric>

namespace Xyce
{

HBBlockMatrixEntry& HBBlockMatrixEntry::operator= (const double value)
{
  if ( isDense() )
  {
    denseMtx.putScalar( val_type( value, 0.0 ) );
  }
  else
  {
    // As a workaround for Basker, if this is an empty matrix, create a 1x1.
    // The inconsistent sizing will be resolved in a later operation if it is used.
    if (rows == 0)
    {
      rows = 1;
      cols = 1;
      diagVector.resize( rows );
    }

    for (int i=0; i<rows; i++)
    {
      diagVector[i] = val_type( value, 0.0 );
    }
  }

  return *this;
}

HBBlockMatrixEntry& HBBlockMatrixEntry::operator= (const val_type value)
{
  if ( isDense() )
  {
    denseMtx.putScalar( value );
  }
  else
  {
    // As a workaround for Basker, if this is an empty matrix, create a 1x1.
    // The inconsistent sizing will be resolved in a later operation if it is used.
    if (rows == 0)
    {
      rows = 1;
      cols = 1;
      diagVector.resize( rows );
    }

    for (int i=0; i<rows; i++)
    {
      diagVector[i] = value;
    }
  }

  return *this;
}


// Assign one block matrix to another.
HBBlockMatrixEntry& HBBlockMatrixEntry::operator=  (const HBBlockMatrixEntry& Source)
{
  rows = Source.rows;
  cols = Source.cols;
  if ( Source.isDense() )
  {
    denseMtx.reshape( Source.rows, Source.cols );
    denseMtx.assign( Source.denseMtx );
    diagVector.clear();
  }
  else
  {
    diagVector = Source.diagVector;
    denseMtx.reshape( 0, 0 );
  }

  return *this;
}

// Return this + b
const HBBlockMatrixEntry HBBlockMatrixEntry::operator+  (const HBBlockMatrixEntry& Source) const
{
  HBBlockMatrixEntry result( *this );

  if ( rows != Source.rows )
  {
    if ( (rows == 1) && isDiag() )
    {
      result.expandDiag( Source.rows );
      result += Source;
    }

    if ( (Source.rows == 1) && Source.isDiag() )
    {
      HBBlockMatrixEntry newSource( Source );
      newSource.expandDiag( rows );
      result += newSource;
    }
  }
  else
  {
    result += Source;
  }

  return result;
}

// Return this - b
const HBBlockMatrixEntry HBBlockMatrixEntry::operator-  (const HBBlockMatrixEntry& Source) const
{
  HBBlockMatrixEntry result( *this );

  if ( rows != Source.rows )
  {
    if ( (rows == 1) && isDiag() )
    {
      result.expandDiag( Source.rows );
      result -= Source;
    }
  
    if ( (Source.rows == 1) && Source.isDiag() )
    {
      HBBlockMatrixEntry newSource( Source );
      newSource.expandDiag( rows );
      result -= newSource;
    }
  }
  else
  {
    result -= Source;
  
  } 

  return result;
}

// Return this * b
const HBBlockMatrixEntry HBBlockMatrixEntry::operator*  (const HBBlockMatrixEntry& Source) const
{
  HBBlockMatrixEntry result;
  bool isMatrix = ((Source.rows == Source.cols) && (rows == cols));
 
  if ( isMatrix )
  {
    result = *this;
  
    if ( rows != Source.rows )
    {
      if ( (rows == 1) && isDiag() )
      {
        if ( diagVector[0] != val_type( 1.0, 0.0 ) )
        {
          result.expandDiag( Source.rows );
          result *= Source;
        }
        else
          result = Source;
      }

      if ( (Source.rows == 1) && Source.isDiag() )
      {
        if ( Source.diagVector[0] != val_type( 1.0, 0.0 ) )
        {
          HBBlockMatrixEntry newSource( Source );
          newSource.expandDiag( rows );
          result *= newSource;
        }
      }
    }
    else
    {
      result *= Source;
    }
  }
  else
  {
    // This is a mat-vec.
    result.rows = Source.rows;
    result.cols = Source.cols;
    result.denseMtx.reshape( result.rows, result.cols );

    if ( isDense() )
    {
      // Create a dense matrix to collect the result of the GEMM.
      result.denseMtx.multiply( Teuchos::NO_TRANS, Teuchos::NO_TRANS, 1.0, denseMtx, Source.denseMtx, 0.0 );
    }
    else
    {
      // Copy over dense matrix, scale rows.
      result.denseMtx.assign( Source.denseMtx );

      val_type alpha = diagVector[0];
      for (int j=0; j<result.cols; j++)
      {
        for (int i=0; i<result.rows; i++)
        {
          if (rows > 1)
            alpha = diagVector[i];

          result.denseMtx(i,j) *= alpha;
        }
      }
    }
  }

  return result;
}

// Return this / b
const HBBlockMatrixEntry HBBlockMatrixEntry::operator/  (const HBBlockMatrixEntry& Source) const
{
  HBBlockMatrixEntry result;
  bool isMatrix = ((Source.rows == Source.cols) && (rows == cols));

  if ( isMatrix )
  {
    result = *this;
  
    if ( rows != Source.rows )
    {
      if ( (rows == 1) && isDiag() )
      {
        result.expandDiag( Source.rows );
        result /= Source;
      }

      if ( (Source.rows == 1) && Source.isDiag() )
      {
        if ( Source.diagVector[0] != val_type( 1.0, 0.0 ) )
        {
          HBBlockMatrixEntry newSource( Source );
          newSource.expandDiag( rows );
          result /= newSource;
        }
      }
    }
    else
    {
      result /= Source;
    }
  }
  else
  {
    // This is a back solve with a vector.
    result.rows = rows;
    result.cols = cols;
    result.denseMtx.reshape( result.rows, result.cols );

    if ( Source.isDense() )
    {
      // Compute inverse of source matrix.
      mtx_type_nonlin A( Teuchos::Copy, Source.denseMtx );
      mtx_type_nonlin b( Teuchos::Copy, denseMtx );
      nonlin_solver denseSolver;
      denseSolver.factorWithEquilibration( true );
      denseSolver.setMatrix( Teuchos::rcp( &A, false ) );
      denseSolver.setVectors( Teuchos::rcp( &(result.denseMtx), false ), Teuchos::rcp( &b, false ) );
      denseSolver.factor();
      denseSolver.solve();
    }
    else
    {
      // This is a set of vectors scaled by the diagonal of Source.
      result.denseMtx.assign( denseMtx );

      // Now perform row scaling of the inverted matrix.
      val_type alpha = Source.diagVector[0];
      if ( alpha != val_type( 1.0, 0.0 ) || Source.rows>1 )
      {
        for (int j=0; j<result.cols; j++)
        {
          for (int i=0; i<result.rows; i++)
          {
            if (Source.rows > 1)
              alpha = Source.diagVector[i];

            result.denseMtx(i,j) /= alpha;
          }
        }
      }
    }
  }

  return result;
}

// Add one block matrix to another.
HBBlockMatrixEntry& HBBlockMatrixEntry::operator+= (const HBBlockMatrixEntry& Source)
{
  if ( (Source.rows != rows) || Source.cols != cols )
    Report::DevelFatal0() << "HBBlockMatrixEntry::operator+= : matrices are not compatible!";

  // Check all four possible scenarios of addition.
  if ( Source.isDense() )
  {
    if ( isDense() )
    {
      // Add into current dense matrix.
      denseMtx += Source.denseMtx;
    }
    else
    {
      // Copy over dense matrix and then add diagonals.
      denseMtx.reshape( Source.rows, Source.cols );
      denseMtx.assign( Source.denseMtx );
      for (int i=0; i<Source.rows; i++)
      {
        denseMtx(i,i) += diagVector[i];
      }
      diagVector.clear();
    }
  }
  else
  {
    // Add diagonals into current matrix.
    for (int i=0; i<rows; i++)
    {
      if ( isDense() )
        denseMtx(i,i) += Source.diagVector[i];
      else
        diagVector[i] += Source.diagVector[i];
    }
  }
 
  return *this;
}

HBBlockMatrixEntry& HBBlockMatrixEntry::operator-= (const HBBlockMatrixEntry& Source)
{
  if ( (Source.rows != rows) || Source.cols != cols )
    Report::DevelFatal0() << "HBBlockMatrixEntry::operator-= : matrices are not compatible!";

  // Check all four possible scenarios of subtraction.
  if ( Source.isDense() )
  {
    if ( isDense() )
    {
      // Add into current dense matrix.
      denseMtx -= Source.denseMtx;
    }
    else
    {
      // Copy over dense matrix and then add diagonals.
      denseMtx.reshape( Source.rows, Source.cols );
      denseMtx.putScalar( val_type( 0.0, 0.0 ) );
      for (int i=0; i<Source.rows; i++)
      {
        denseMtx(i,i) = diagVector[i];
      }
      denseMtx -= Source.denseMtx;
      diagVector.clear();
    }
  }
  else
  {
    // Add diagonals into current matrix.
    for (int i=0; i<rows; i++)
    {
      if ( isDense() )
        denseMtx(i,i) -= Source.diagVector[i];
      else
        diagVector[i] -= Source.diagVector[i];
    }
  }

  return *this;
}

HBBlockMatrixEntry& HBBlockMatrixEntry::operator*= (const HBBlockMatrixEntry& Source)
{
  if ( (Source.rows != rows) || Source.cols != cols )
    Report::DevelFatal0() << "HBBlockMatrixEntry::operator*= : matrices are not compatible!";

  // Check all four possible scenarios of multiplication.
  if ( Source.isDense() )
  {
    if ( isDense() )  
    {
      // Create a dense matrix to collect the result of the GEMM.
      mtx_type_nonlin result( rows, cols );
      result.multiply( Teuchos::NO_TRANS, Teuchos::NO_TRANS, 1.0, denseMtx, Source.denseMtx, 0.0 );
      denseMtx.assign( result );
    }
    else
    {
      // Copy over dense matrix, scale rows.
      denseMtx.reshape( Source.rows, Source.cols );
      denseMtx.assign( Source.denseMtx ); 
      for (int i=0; i<rows; i++)
      {
        val_type alpha = diagVector[i];
        mtx_type_nonlin row_i( Teuchos::View, denseMtx, 1, cols, i, 0 );
        row_i.scale( alpha );
      }
      diagVector.clear();
    }
  }
  else
  {
    if ( isDense() )
    {
      // Scale cols.
      for (int i=0; i<cols; i++)
      { 
        val_type alpha = Source.diagVector[i];
        mtx_type_nonlin col_i( Teuchos::View, denseMtx, rows, 1, 0, i );
	col_i.scale( alpha );
      }
    }
    else
    {
      // Multiply diagonals together.
      for (int i=0; i<rows; i++)
      {
        diagVector[i] *= Source.diagVector[i];
      }
    }
  }
 
  return *this;
}

HBBlockMatrixEntry& HBBlockMatrixEntry::operator/= (const HBBlockMatrixEntry& Source)
{
  if ( (Source.rows != rows) || Source.cols != cols )
    Report::DevelFatal0() << "HBBlockMatrixEntry::operator/= : matrices are not compatible!";

  // Check all four possible scenarios of division.
  if ( Source.isDense() )
  {
    if ( isDense() )
    {
      // Compute inverse of source matrix.
      // this = this / Source = this * inv(Source) = ( Source' \ this' )'
      mtx_type_nonlin A( Source.denseMtx, Teuchos::TRANS );
      mtx_type_nonlin b( denseMtx, Teuchos::TRANS );
      nonlin_solver denseSolver;
      denseSolver.factorWithEquilibration( true ); 
      denseSolver.setMatrix( Teuchos::rcp( &A, false ) );
      denseSolver.setVectors( Teuchos::rcp( &denseMtx, false ), Teuchos::rcp( &b, false ) );
      denseSolver.factor();
      denseSolver.solve();

      // Now transpose the solution back.
      for (int i=0; i<rows; i++)
      {
        for (int j=0; j<i; j++)
        {
          val_type tmp = denseMtx(i,j);
          denseMtx(i,j) = denseMtx(j,i);
          denseMtx(j,i) = tmp;
        }
      }
    } 
    else
    {
      // This is now a dense matrix that is the col scaling of the inv(Source).
      denseMtx.reshape( Source.rows, Source.cols );
      denseMtx.assign( Source.denseMtx );
      nonlin_solver denseSolver;
      denseSolver.setMatrix( Teuchos::rcp( &denseMtx, false ) );
      denseSolver.factor();
      denseSolver.invert();

      // Now perform col scaling of the inverted matrix.
      for (int i=0; i<cols; i++)
      {
        val_type alpha = diagVector[i];
        mtx_type_nonlin col_i( Teuchos::View, denseMtx, rows, 1, 0, i );
        col_i.scale( alpha );
      }
      diagVector.clear();
    }
  }
  else
  {
    if ( isDense() )
    {
      // Scale rows.
      for (int i=0; i<rows; i++)
      {
        val_type alpha = Source.diagVector[i];
        mtx_type_nonlin row_i( Teuchos::View, denseMtx, 1, cols, i, 0 );
        row_i.scale( Teuchos::ScalarTraits<val_type>::one() / alpha );
      }
    }
    else
    {
      // Multiply diagonals together.
      for (int i=0; i<rows; i++)
      {
        diagVector[i] /= Source.diagVector[i];
      }
    }
  }  

  return *this;
}

bool HBBlockMatrixEntry::operator==(const HBBlockMatrixEntry& Source) const
{
  // Check for special case of null matrix.
  bool ret = false;

  if (Source.rows==0 && Source.cols==0 && Source.denseMtx.empty() && Source.diagVector.empty())
  {
    if (rows && cols)
    {
      // This doesn't make a lot of sense, but the abstractions in Basker require that
      // this matrix can be the same as an empty one if it is zero.
      val_type suma = std::accumulate( diagVector.begin(), diagVector.end(), Teuchos::ScalarTraits<val_type>::zero() );
      Teuchos::ScalarTraits<val_type>::magnitudeType sumb = denseMtx.normFrobenius();
      if ( (suma == Teuchos::ScalarTraits<val_type>::zero()) && (sumb == 0.0) )
        ret = true; 
    }
    else
    {
      // This matrix is also empty, so they are the same.
      ret = true;
    }
  }
  else
  {
    if ( isDense() )
    {
      ret = ( denseMtx == Source.denseMtx );
    }
    else
    {
      ret = ( diagVector == Source.diagVector );
    }
  }
     
  return ret; 
}

bool HBBlockMatrixEntry::operator!=(const HBBlockMatrixEntry& Source) const
{
  return( !(*this == Source) );
}

bool HBBlockMatrixEntry::operator> (const HBBlockMatrixEntry& Source) const
{
  bool ret = false;

  if ( isDiag() )
  {
    // Need to check if this diagonal is singular.
    if ( Source.isDense() )
    {
      bool singA = false;
      for (int i=0; i<rows; i++)
      {
        if ( Teuchos::ScalarTraits<val_type>::magnitude( diagVector[i] ) == 0.0 )
        {
          singA = true;
          break;
        }
      } 
      if (!singA)
        ret = true;
    }
    else
    {
      Teuchos::ScalarTraits<val_type>::magnitudeType mina = Teuchos::ScalarTraits<val_type>::magnitude( diagVector[0] );
      Teuchos::ScalarTraits<val_type>::magnitudeType maxa = Teuchos::ScalarTraits<val_type>::magnitude( diagVector[0] );
      for (int i=1; i<rows; i++)
      {
        Teuchos::ScalarTraits<val_type>::magnitudeType val = 
                             Teuchos::ScalarTraits<val_type>::magnitude( diagVector[i] );
        if (val > maxa)
          maxa = val;
        if (val < mina)
          mina = val;
      }

      Teuchos::ScalarTraits<val_type>::magnitudeType minb = Teuchos::ScalarTraits<val_type>::magnitude( Source.diagVector[0] );
      Teuchos::ScalarTraits<val_type>::magnitudeType maxb = Teuchos::ScalarTraits<val_type>::magnitude( Source.diagVector[0] );
      for (int i=1; i<Source.rows; i++)
      {
        Teuchos::ScalarTraits<val_type>::magnitudeType val = 
                             Teuchos::ScalarTraits<val_type>::magnitude( Source.diagVector[i] );
        if (val > maxb)
          maxb = val;
        if (val < minb)
          minb = val;
      }

      if (mina == 0.0)
        ret = false;
      else if (minb == 0.0) 
        ret = true;
      else
        ret = ( maxa/mina ) < ( maxb/minb );
    }
  }
  else
  {
    if ( Source.isDense() )
    {
      Teuchos::ScalarTraits<val_type>::magnitudeType condEst, condEst2;
      mtx_type_nonlin inverse( Teuchos::Copy, denseMtx ), inverse2( Teuchos::Copy, Source.denseMtx );
      nonlin_solver denseSolver;

      denseSolver.setMatrix( Teuchos::rcp( &inverse, false ) );
      denseSolver.factor();
      denseSolver.reciprocalConditionEstimate( condEst );

      denseSolver.setMatrix( Teuchos::rcp( &inverse2, false ) );
      denseSolver.factor();
      denseSolver.reciprocalConditionEstimate( condEst2 );

      if ( condEst == 0.0 )
        ret = false;
      else if ( condEst2 == 0.0 )
        ret = true;
      else
        ret = ( 1.0/condEst ) < ( 1.0/condEst2 );
    }
    else
    {
      // Need to check if the Source a zero diagonal.
      bool singB = false;
      for (int i=0; i<rows; i++)
      {
        if ( Teuchos::ScalarTraits<val_type>::magnitude( Source.diagVector[i] ) == 0.0 )
        {
          singB = true;
          break;
        }
      } 
      if (singB)
        ret = true;
    }
  }

  return ret; 
}

bool HBBlockMatrixEntry::operator< (const HBBlockMatrixEntry& Source) const
{
  return ( !(*this > Source) );
}

void HBBlockMatrixEntry::putScalar(const val_type value)
{
  if ( isDiag() )
  {
    for (unsigned int i=0; i<diagVector.size(); i++)
    {
      diagVector[i] = value;
    }
  }
  if ( isDense() )
  {
    denseMtx.putScalar( value );
  }
}

void HBBlockMatrixEntry::print(std::ostream& os) const
{
  if ( isDense() )
  {
    os << "HBBlockMatrixEntry Dense: " << std::endl;
    denseMtx.print( os );
  }
  else
  {
    os << "HBBlockMatrixEntry Diagonal: " << std::endl;
    os << "Rows : " << rows << std::endl;
    os << "Columns : " << cols << std::endl;
    os << "Values : ";
    for (unsigned int i=0; i<diagVector.size(); i++)
    {
      os << diagVector[i] << " ";
    }
    os << std::endl;
  }
}

void HBBlockMatrixEntry::expandDiag( int nrows )
{
  val_type value = diagVector[0];

  rows = nrows;
  cols = nrows;
  diagVector.resize( nrows, value );
}

void HBBlockMatrixEntry::addToDiag( int index, val_type val )
{
  if (rows && cols)
  {
    if (isDiag())
    {
      diagVector[index] += val;
    }
    else
    {
      denseMtx(index, index) += val;
    }
  }
}

double HBBlockMatrixEntry::normFrobenius() const
{
  mag_type norm = 0.0;
  if (isDiag())
  {
    for (int i=0; i<rows; i++)
    {
      norm += Teuchos::ScalarTraits<val_type>::magnitude( diagVector[i]*diagVector[i] );
    }
    norm = Teuchos::ScalarTraits<val_type>::magnitude(
             Teuchos::ScalarTraits<val_type>::squareroot(norm));
  }
  else
  {
    norm = denseMtx.normFrobenius();
  }

  return norm;
}

int packHBBlockMatrix(const HBBlockMatrixEntry& Source, std::vector<double>& vec)
{
  int sizeVec = vec.size();
  int reqStorage = 2 * Source.rows;
  if ( Source.isDense() )
  {
    reqStorage *= Source.cols;
  }

  // Resize if necessary.
  if ( sizeVec < reqStorage )
  {
    vec.resize( reqStorage );
  } 

  // Now copy values from Source into vec.
  if ( Source.isDense() )
  {
    for (int i=0; i<Source.rows; i++)
    {
      for (int j=0; j<Source.cols; j++)
      {
        vec[ j*Source.rows + i ] = Source.denseMtx( i, j ).real();
        vec[ Source.rows*Source.cols + j*Source.rows + i ] = Source.denseMtx( i, j ).imag();
      }
    }
  }
  else
  {
    for (int i=0; i<Source.rows; i++)
    {
      vec[ i ] = Source.diagVector[ i ].real();
      vec[ Source.rows + i ] = Source.diagVector[ i ].imag();
    } 
  }

  // Return the length of the vector that has been packed.
  return reqStorage;
}

void unpackHBBlockMatrixUpdate(const std::vector<double>& vec, bool isDense, HBBlockMatrixEntry& Source)
{
  // Now copy values from vec into Source.
  if (isDense)
  {
    for (int i=0; i<Source.rows; i++)
    {
      for (int j=0; j<Source.cols; j++)
      {
        Source.denseMtx( i, j ) += HBBlockMatrixEntry::val_type( vec[ j*Source.rows + i ],
                                                                 vec[ Source.rows*Source.cols + j*Source.rows + i ] );
      }
    }
  }
  else
  {
    for (int i=0; i<Source.rows; i++)
    {
      if ( Source.isDense() )
      {
        Source.denseMtx( i, i ) += HBBlockMatrixEntry::val_type( vec[ i ], vec[ Source.rows + i ] );
      }
      else
      {
        Source.diagVector[ i ] += HBBlockMatrixEntry::val_type( vec[ i ], vec[ Source.rows + i ] );
      }
    }
  }
}

} // end namespace Xyce

// Overload print operator.
std::ostream& operator<< (std::ostream& os, const Xyce::HBBlockMatrixEntry& obj)
{
  obj.print( os );
  return os;
}

