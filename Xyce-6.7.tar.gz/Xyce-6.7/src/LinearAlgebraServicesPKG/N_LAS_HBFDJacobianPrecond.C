//-----------------------------------------------------------------------------
// Copyright Notice
//
//   Copyright 2002 Sandia Corporation. Under the terms
//   of Contract DE-AC04-94AL85000 with Sandia Corporation, the U.S.
//   Government retains certain rights in this software.
//
//    Xyce(TM) Parallel Electrical Simulator
//    Copyright (C) 2002-2017 Sandia Corporation
//
//    This program is free software: you can redistribute it and/or modify
//    it under the terms of the GNU General Public License as published by
//    the Free Software Foundation, either version 3 of the License, or
//    (at your option) any later version.
//
//    This program is distributed in the hope that it will be useful,
//    but WITHOUT ANY WARRANTY; without even the implied warranty of
//    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//    GNU General Public License for more details.
//
//    You should have received a copy of the GNU General Public License
//    along with this program.  If not, see <http://www.gnu.org/licenses/>.
//-----------------------------------------------------------------------------

//-------------------------------------------------------------------------
//
// Purpose        : Implementation file for the Iterative linear solver
//                  interface.
//
// Special Notes  :
//
// Creator        : Heidi K. Thornquist, SNL, Electrical & Microsystem Modeling
//
// Creation Date  : 11/11/08
//
//
//
//
//-------------------------------------------------------------------------

// ---------- Standard Includes ----------

#include <Xyce_config.h>

#include <sstream>

// ----------   Xyce Includes   ----------


#include <N_LAS_HBFDJacobianPrecond.h>
#include <N_LAS_HBFDJacobianEpetraOperator.h>
#include <N_LAS_HBBuilder.h>
#include <N_LOA_HBLoader.h>
#include <N_MPDE_State.h>

#include <N_LAS_MultiVector.h>
#include <N_LAS_BlockVector.h>
#include <N_LAS_Matrix.h>
#include <N_LAS_FilteredMatrix.h>

#include <N_LAS_Problem.h>
#include <N_LAS_Builder.h>
#include <N_LAS_System.h>
#include <N_LOA_Loader.h>

#include <N_UTL_Timer.h>

#include <N_ERH_ErrorMgr.h>

#include <N_PDS_SerialComm.h>

#include <Teuchos_RCP.hpp>
#include <Epetra_LinearProblem.h>
#include <Epetra_CrsMatrix.h>
#include <Epetra_MultiVector.h>
#include <Amesos.h>
#include <EpetraExt_MatrixMatrix.h>

using Teuchos::RCP;
using Teuchos::rcp;

namespace Xyce {
namespace Linear {

//-----------------------------------------------------------------------------
// Function      : HBFDJacobianPrecond::HBFDJacobianPrecond
// Purpose       : Constructor
// Special Notes :
// Scope         : Public
// Creator       : Heidi Thornquist, SNL, Electrical & Microsystem Modeling
// Creation Date : 11/11/08
//-----------------------------------------------------------------------------
HBFDJacobianPrecond::HBFDJacobianPrecond(
  Linear::Builder &     builder)
  : Preconditioner(),
    hbOsc_(false),
    builder_(builder)
{
  setDefaultOptions();
}

//-----------------------------------------------------------------------------
// Function      : HBFDJacobianPrecond::setDefaultOptions
// Purpose       : resets Ifpack options
// Special Notes :
// Scope         : Public
// Creator       : Heidi Thornquist, SNL, Electrical & Microsystem Modeling
// Creation Date : 11/11/08
//-----------------------------------------------------------------------------
bool HBFDJacobianPrecond::setDefaultOptions()
{
  return true;
}

//-----------------------------------------------------------------------------
// Function      : HBFDJacobianPrecond::setDefaultOption
// Purpose       : resets Ifpack option
// Special Notes :
// Scope         : Public
// Creator       : Heidi Thornquist, SNL, Electrical & Microsystem Modeling
// Creation Date : 11/11/08
//-----------------------------------------------------------------------------
bool HBFDJacobianPrecond::setDefaultOption( const std::string & option )
{
  return true;
}

//-----------------------------------------------------------------------------
// Function      : HBFDJacobianPrecond::setOptions
// Purpose       : sets Ifpack options and params from modelblock
// Special Notes :
// Scope         : Public
// Creator       : Heidi Thornquist, SNL, Electrical & Microsystem Modeling
// Creation Date : 11/11/08
//-----------------------------------------------------------------------------
bool HBFDJacobianPrecond::setOptions( const Util::OptionBlock & OB )
{
  // Set the parameters from the list
  Util::ParamList::const_iterator it_tpL = OB.begin();
  Util::ParamList::const_iterator end_tpL = OB.end();
  for (; it_tpL != end_tpL; ++it_tpL)
    {
      this->setParam( *it_tpL );
    }

  // store for restart of solver_
  if( &OB != options_.get() )
    {
      options_ = Teuchos::rcp( &OB, false );
    }

  return true;
}

//-----------------------------------------------------------------------------
// Function      : HBFDJacobianPrecond::setParam
// Purpose       : sets Ifpack option
// Special Notes :
// Scope         : Public
// Creator       : Heidi Thornquist, SNL, Electrical & Microsystem Modeling
// Creation Date : 11/11/08
//-----------------------------------------------------------------------------
bool HBFDJacobianPrecond::setParam( const Util::Param & param )
{
  std::string tag = param.tag();
  std::string uTag = param.uTag();

  return true;
}

//-----------------------------------------------------------------------------
// Function      : HBFDJacobianPrecond::initGraph
// Purpose       : Initialize the graph using information from the System
// Special Notes :
// Scope         : Public
// Creator       : Heidi Thornquist, SNL, Electrical & Microsystem Modeling
// Creation Date : 12/11/08
//-----------------------------------------------------------------------------
bool HBFDJacobianPrecond::initGraph( const Teuchos::RCP<Problem> & problem )
{
  // Since this is a time-domain preconditioner, rather than a frequency-domain preconditioner,
  // the graph from the application builder can be used to generate an Amesos solver for each
  // diagonal block.
  RCP<BlockVector> bXt = hbBuilderPtr_->createTimeDomainBlockVector();
  N_ = bXt->blockCount();

  // Generate the vectors for the N_ linear problems to be solved on the diagonal.
  diagRHS_ = rcp( builder_.createVector() );
  diagSoln_ = rcp( builder_.createVector() );
  diagMatrix_.resize(N_);
  epetraProblem_.resize(N_);
  amesosPtr_.resize(N_);

  Amesos amesosFactory;

  for (int i=0; i<N_; ++i) {
    diagMatrix_[i] = rcp( builder_.createMatrix() );
    epetraProblem_[i] = rcp( new Epetra_LinearProblem( &(diagMatrix_[i]->epetraObj()), 
                             &(diagRHS_->epetraObj()), &(diagSoln_->epetraObj()) ) );
    amesosPtr_[i] = rcp( amesosFactory.Create( "Klu", *epetraProblem_[i] ) );
    amesosPtr_[i]->SymbolicFactorization();
  }

  return true;
}

//-----------------------------------------------------------------------------
// Function      : HBFDJacobianPrecond::initValues
// Purpose       : Initialize the values of the Epetra_LinearSystem's
// Special Notes :
// Scope         : Public
// Creator       : Heidi Thornquist, SNL, Electrical & Microsystem Modeling
// Creation Date : 12/11/08
//-----------------------------------------------------------------------------
bool HBFDJacobianPrecond::initValues( const Teuchos::RCP<Problem> & problem )
{
  // Get the separated stored Jacobian matrices from the HB loader.
  Teuchos::RCP<FilteredMatrix>& linAppdQdx = hbLoaderPtr_->getStoreLindQdx();
  Teuchos::RCP<FilteredMatrix>& linAppdFdx = hbLoaderPtr_->getStoreLindFdx();
  
  std::vector<Teuchos::RCP<FilteredMatrix> >& vecNLAppdQdx = hbLoaderPtr_->getStoreNLdQdx();
  std::vector<Teuchos::RCP<FilteredMatrix> >& vecNLAppdFdx = hbLoaderPtr_->getStoreNLdFdx();

  // Compute the diagonal matrices
  // C(t_i)/h_i + G(t_i)
  double h=0.0;
  for( int i = 0; i < N_; ++i )
  {
    // Initialize the diagonal matrix and temporary matrix.
    diagMatrix_[i]->put( 0.0 );

    // If there is only one time step, then h is considered constant.
    if (timeSteps_.size() != 1)
      h = timeSteps_[i];
    else
      h = timeSteps_[0];
   
    // First insert linear matrix values for both C and G 
    linAppdQdx->addToMatrix( *(diagMatrix_[i]), 1.0/h );
    linAppdFdx->addToMatrix( *(diagMatrix_[i]) );
 
    // Next compute nonlinear matrix values for both C and G
    vecNLAppdQdx[i]->addToMatrix( *(diagMatrix_[i]), 1.0/h );
    vecNLAppdFdx[i]->addToMatrix( *(diagMatrix_[i]) );
  }

  return true;
}

//-----------------------------------------------------------------------------
// Function      : HBFDJacobianPrecond::compute
// Purpose       : Compute a preconditioner M such that M ~= A^{-1}.
// Special Notes :
// Scope         : Public
// Creator       : Heidi Thornquist, SNL, Electrical & Microsystem Modeling
// Creation Date : 11/11/08
//-----------------------------------------------------------------------------
bool HBFDJacobianPrecond::compute()
{
  bool precStatus = true;

  // Compute numeric factorization for each block.
  for ( int i=0; i<N_; ++i ) {
    amesosPtr_[i]->NumericFactorization();
  }

  if ( Teuchos::is_null( epetraPrec_ ) )
    epetraPrec_ = fdJacobianOperator( epetraProblem_, amesosPtr_, hbBuilderPtr_, 
                                      hbLoaderPtr_, timeSteps_, hbOsc_ );

  if ( Teuchos::is_null( epetraPrec_ ) )
    return false;

  return precStatus;
}

//-----------------------------------------------------------------------------
// Function      : HBFDJacobianPrecond::apply
// Purpose       : Calls the actual preconditioner to apply y = M*x.
// Special Notes :
// Scope         : Public
// Creator       : Heidi Thornquist, SNL, Electrical & Microsystem Modeling
// Creation Date : 11/11/08
//-----------------------------------------------------------------------------
int HBFDJacobianPrecond::apply( MultiVector & x, MultiVector & y )
{
  int precStatus = 0;
  // If there is no preconditioner to apply return a nonzero code
  if( Teuchos::is_null(epetraPrec_) )
    precStatus = -1;
  else
    precStatus = epetraPrec_->Apply( x.epetraObj(), y.epetraObj() );

  return precStatus;
}

} // namespace Linear
} // namespace Xyce
