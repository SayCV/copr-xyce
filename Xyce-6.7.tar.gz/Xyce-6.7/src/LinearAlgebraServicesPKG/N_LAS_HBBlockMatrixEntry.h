//-----------------------------------------------------------------------------
// Copyright Notice
//
//   Copyright 2002 Sandia Corporation. Under the terms
//   of Contract DE-AC04-94AL85000 with Sandia Corporation, the U.S.
//   Government retains certain rights in this software.
//
//    Xyce(TM) Parallel Electrical Simulator
//    Copyright (C) 2002-2017 Sandia Corporation
//
//    This program is free software: you can redistribute it and/or modify
//    it under the terms of the GNU General Public License as published by
//    the Free Software Foundation, either version 3 of the License, or
//    (at your option) any later version.
//
//    This program is distributed in the hope that it will be useful,
//    but WITHOUT ANY WARRANTY; without even the implied warranty of
//    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//    GNU General Public License for more details.
//
//    You should have received a copy of the GNU General Public License
//    along with this program.  If not, see <http://www.gnu.org/licenses/>.
//-----------------------------------------------------------------------------

//-----------------------------------------------------------------------------
//
// Purpose        : HB Block Matrix
//
// Special Notes  :
//
// Creator        : Heidi Thornquist, SNL, Parallel Computational Sciences
//
// Creation Date  : 12/7/16
//
//
//
//
//-----------------------------------------------------------------------------

#ifndef Xyce_N_LAS_HBBlockMatrixEntry_h
#define Xyce_N_LAS_HBBlockMatrixEntry_h

#include <Xyce_config.h>

#include <vector>
#include <iostream>

#if defined(Xyce_AMESOS2) && !defined(SHYLUBASKER)

#include "Amesos2_config.h"
#include "Amesos2_Basker_TypeMap.hpp"
#include "Amesos2_Basker.hpp"

#endif

#include "Teuchos_SerialDenseMatrix.hpp"
#include "Teuchos_SerialDenseSolver.hpp"

namespace Xyce 
{

// Create a block matrix for each Xyce matrix entry.
// This matrix can be dense (SerialDenseMatrix) or diagonal (std::vector).
struct HBBlockMatrixEntry {
  typedef std::complex<double> val_type;
  typedef Teuchos::ScalarTraits<std::complex<double> >::magnitudeType mag_type;
  typedef Teuchos::SerialDenseMatrix<int, val_type> mtx_type_nonlin;
  typedef Teuchos::SerialDenseSolver<int, val_type> nonlin_solver;
  typedef std::vector<val_type> mtx_type_lin;
  

  // Default constructor
  HBBlockMatrixEntry()
  : rows( 0 ),
    cols( 0 )
  {}

  // Null constructor
  HBBlockMatrixEntry( int should_be_null )
  : rows( 0 ),
    cols( 0 )
  {
    if ( should_be_null )
      std::cout << "Null constructor received value: " << should_be_null << std::endl;
  }

  // Basic constructor
  HBBlockMatrixEntry( int numRows, int numCols, bool isDense )
  : rows( numRows ),
    cols( numCols )
  {
    if (isDense)
      denseMtx.reshape( rows, cols );
    else
      diagVector.resize( rows );
  }

  // Copy contructor
  HBBlockMatrixEntry( const HBBlockMatrixEntry& Source )
  : rows( Source.rows ),
    cols( Source.cols )
  {
    if (Source.isDense())
    {
      denseMtx.reshape( rows, cols );
      denseMtx.assign( Source.denseMtx );
    }
    else
    {
      diagVector = Source.diagVector;
    }
  }

  // Is this entry related to a linear block (diagonal)
  bool isDiag() const { return (diagVector.size() > 0); }

  // Is this entry related to a nonlinear block (dense)
  bool isDense() const { return ( !denseMtx.empty() ); }   

  // Overload operators for this matrix.
  HBBlockMatrixEntry& operator=  (const double value);
  HBBlockMatrixEntry& operator=  (const val_type value);
  HBBlockMatrixEntry& operator=  (const HBBlockMatrixEntry& Source);

  const HBBlockMatrixEntry operator+  (const HBBlockMatrixEntry& Source) const;
  const HBBlockMatrixEntry operator-  (const HBBlockMatrixEntry& Source) const;
  const HBBlockMatrixEntry operator*  (const HBBlockMatrixEntry& Source) const;
  const HBBlockMatrixEntry operator/  (const HBBlockMatrixEntry& Source) const;

  HBBlockMatrixEntry& operator+= (const HBBlockMatrixEntry& Source);
  HBBlockMatrixEntry& operator-= (const HBBlockMatrixEntry& Source);
  HBBlockMatrixEntry& operator*= (const HBBlockMatrixEntry& Source);
  HBBlockMatrixEntry& operator/= (const HBBlockMatrixEntry& Source);

  bool operator==(const HBBlockMatrixEntry& Source) const;
  bool operator!=(const HBBlockMatrixEntry& Source) const;
  bool operator> (const HBBlockMatrixEntry& Source) const;
  bool operator< (const HBBlockMatrixEntry& Source) const;

  // Initialize values of either diagonal or dense block with value.
  void putScalar(const val_type value);

  // This function will be used to expand any 1x1s to be compatible with block sizes
  void expandDiag( int nrows );

  // Add a value to the diagonal entry of either dense or diagonal matrix.
  void addToDiag( int index, val_type val ); 

  // Frobenius norm
  double normFrobenius() const;

  void print(std::ostream& os) const;
 
  int rows, cols;
  mtx_type_nonlin denseMtx;
  mtx_type_lin diagVector;
};

int packHBBlockMatrix(const HBBlockMatrixEntry& Source, std::vector<double>& vec);
void unpackHBBlockMatrixUpdate(const std::vector<double>& vec, bool isDense, HBBlockMatrixEntry& Source);

}

// Overload print operator.
std::ostream& operator<< (std::ostream& os, const Xyce::HBBlockMatrixEntry& obj);

#if defined(Xyce_AMESOS2) && !defined(SHYLUBASKER)

// Specialization of BASKER_ScalarTraits for block vectors
template <>
struct BASKER_ScalarTraits< Xyce::HBBlockMatrixEntry > {
  typedef Xyce::HBBlockMatrixEntry valType;
  typedef Xyce::HBBlockMatrixEntry magnitudeType;
  // Fix this one.
  static inline valType reciprocal(valType c){ return c; }
  static inline valType divide(valType a, valType b){ return a/b; }
  static inline magnitudeType approxABS(valType a) { return a; }
  static inline magnitudeType abs(valType a) { return a; }
  // Fix this one.
  static inline bool gt (valType a, valType b){ return a>b; }
};

namespace Amesos2 {

  // Enable HBBlockMatrixEntry as a valid Scalar type for Basker
  template <>
  struct TypeMap< Basker, Xyce::HBBlockMatrixEntry > {
    static Xyce::HBBlockMatrixEntry dtype;
    typedef Xyce::HBBlockMatrixEntry type;
    typedef Xyce::HBBlockMatrixEntry magnitude_type;
  };

}

#endif

#endif // Xyce_N_LAS_HBBlockMatrixEntry_h
