//-----------------------------------------------------------------------------
// Copyright Notice
//
//   Copyright 2002 Sandia Corporation. Under the terms
//   of Contract DE-AC04-94AL85000 with Sandia Corporation, the U.S.
//   Government retains certain rights in this software.
//
//    Xyce(TM) Parallel Electrical Simulator
//    Copyright (C) 2002-2017 Sandia Corporation
//
//    This program is free software: you can redistribute it and/or modify
//    it under the terms of the GNU General Public License as published by
//    the Free Software Foundation, either version 3 of the License, or
//    (at your option) any later version.
//
//    This program is distributed in the hope that it will be useful,
//    but WITHOUT ANY WARRANTY; without even the implied warranty of
//    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//    GNU General Public License for more details.
//
//    You should have received a copy of the GNU General Public License
//    along with this program.  If not, see <http://www.gnu.org/licenses/>.
//-----------------------------------------------------------------------------

//-----------------------------------------------------------------------------
//
// Purpose        : Builder class for parallel/serial linear objects
//
// Special Notes  :
//
// Creator        : Robert Hoekstra, SNL, Parallel Computational Sciences
//
// Creation Date  : 01/22/01
//
//
//
//
//-----------------------------------------------------------------------------

#include <Xyce_config.h>

#include <N_UTL_fwd.h>

#include <N_ERH_ErrorMgr.h>
#include <N_LAS_Builder.h>
#include <N_LAS_LAFactory.h>
#include <N_LAS_Matrix.h>
#include <N_LAS_MultiVector.h>
#include <N_LAS_QueryUtil.h>
#include <N_LAS_Vector.h>
#include <N_PDS_Comm.h>
#include <N_PDS_GlobalAccessor.h>
#include <N_PDS_Manager.h>
#include <N_PDS_ParMap.h>
#include <N_PDS_MPI.h>
#include <N_UTL_FeatureTest.h>
#include <N_UTL_Functors.h>

#include <Epetra_CrsGraph.h>
#include <Epetra_CrsMatrix.h>
#include <Epetra_Map.h>
#include <Epetra_Export.h>
#include <Epetra_MapColoring.h>
#include <EpetraExt_View_CrsGraph.h>

using std::max;
using Xyce::VERBOSE_LINEAR;

namespace Xyce {
namespace Linear {

//-----------------------------------------------------------------------------
// Function      : Builder::~
// Purpose       :
// Special Notes :
// Scope         :
// Creator       :
// Creation Date :
//-----------------------------------------------------------------------------
Builder::~Builder()
{}

//-----------------------------------------------------------------------------
// Function      : Builder::createMultiVector
// Purpose       : returns Soln/RHS sized multiVector
// Special Notes :
// Scope         : Public
// Creator       : Robert Hoekstra, SNL, Parallel Computational Sciences
// Creation Date : 6/10/00
//-----------------------------------------------------------------------------
MultiVector * Builder::createMultiVector( const int numVectors, const double value ) const
{
  return LAFactory::newMultiVector( value,
                                    *(pdsMgr_->getParallelMap(Parallel::SOLUTION)),
                                    numVectors,
                                    *(pdsMgr_->getParallelMap(Parallel::SOLUTION_OVERLAP_GND)) );
}

//-----------------------------------------------------------------------------
// Function      : Builder::createStateMultiVector
// Purpose       : returns State sized multiVector
// Special Notes :
// Scope         : Public
// Creator       : Robert Hoekstra, SNL, Parallel Computational Sciences
// Creation Date : 6/10/00
//-----------------------------------------------------------------------------
MultiVector * Builder::createStateMultiVector( const int numVectors, const double value ) const
{
  return LAFactory::newMultiVector( value,
                                    *(pdsMgr_->getParallelMap(Parallel::STATE)),
                                    numVectors,
                                    *(pdsMgr_->getParallelMap(Parallel::STATE_OVERLAP)) );
}

//-----------------------------------------------------------------------------
// Function      : Builder::createStoreMultiVector
// Purpose       : returns Store sized multiVector
// Special Notes :
// Scope         : Public
// Creator       : Eric Keiter
// Creation Date :
//-----------------------------------------------------------------------------
MultiVector * Builder::createStoreMultiVector( const int numVectors, const double value ) const
{
  return LAFactory::newMultiVector( value,
                                    *(pdsMgr_->getParallelMap(Parallel::STORE)),
                                    numVectors,
                                    *(pdsMgr_->getParallelMap(Parallel::STORE_OVERLAP)) );
}

//-----------------------------------------------------------------------------
// Function      : Builder::createVector
// Purpose       : returns Soln/RHS sized vector
// Special Notes : Takes an initial value argument.
// Scope         : Public
// Creator       : Scott A. Hutchinson, SNL, Computational Sciences
// Creation Date : 03/02/01
//-----------------------------------------------------------------------------
Vector * Builder::createVector( const double value ) const
{
    return LAFactory::newVector( value,
                                 *(pdsMgr_->getParallelMap(Parallel::SOLUTION)),
                                 *(pdsMgr_->getParallelMap(Parallel::SOLUTION_OVERLAP_GND)) );
}

//-----------------------------------------------------------------------------
// Function      : Builder::createStateVector
// Purpose       : returns State sized vector
// Special Notes :
// Scope         : Public
// Creator       : Robert Hoekstra, SNL, Parallel Computational Sciences
// Creation Date : 6/10/00
//-----------------------------------------------------------------------------
Vector * Builder::createStateVector( const double value ) const
{
    return LAFactory::newVector( value,
                                 *(pdsMgr_->getParallelMap(Parallel::STATE)),
                                 *(pdsMgr_->getParallelMap(Parallel::STATE_OVERLAP)) );
}

//-----------------------------------------------------------------------------
// Function      : Builder::createStoreVector
// Purpose       : returns Store sized vector
// Special Notes :
// Scope         : Public
// Creator       : Eric Keiter, SNL
// Creation Date :
//-----------------------------------------------------------------------------
Vector * Builder::createStoreVector( const double value ) const
{
    return LAFactory::newVector( value,
                                 *(pdsMgr_->getParallelMap(Parallel::STORE)),
                                 *(pdsMgr_->getParallelMap(Parallel::STORE_OVERLAP)) );
}


//-----------------------------------------------------------------------------
// Function      : Builder::createStoreVector
// Purpose       : returns Store sized vector
// Special Notes :
// Scope         : Public
// Creator       : Eric Keiter, SNL
// Creation Date :
//-----------------------------------------------------------------------------
Vector * Builder::createLeadCurrentVector( const double value ) const
{
    return LAFactory::newVector( value,
                                 *(pdsMgr_->getParallelMap(Parallel::LEADCURRENT)),
                                 *(pdsMgr_->getParallelMap(Parallel::LEADCURRENT_OVERLAP)) );
}

//-----------------------------------------------------------------------------
// Function      : Builder::createMatrix
// Purpose       : returns Matrix initialized based on QueryUtil and ParMap
// Special Notes :
// Scope         : Public
// Creator       : Robert Hoekstra, SNL, Parallel Computational Sciences
// Creation Date : 6/10/00
//-----------------------------------------------------------------------------
Matrix * Builder::createMatrix(const double initialValue) const
{

  Matrix * mat = 0;

  Epetra_CrsGraph * overlapGraph = pdsMgr_->getMatrixGraph( Parallel::JACOBIAN_OVERLAP_GND );
  Epetra_CrsGraph * baseGraph = pdsMgr_->getMatrixGraph( Parallel::JACOBIAN );

  mat = new Matrix( overlapGraph, baseGraph );

  return mat;
}

//-----------------------------------------------------------------------------
// Function      : Builder::createSolnColoring
// Purpose       : Color Map representing variable types in solution vector
// Special Notes :
// Scope         : Public
// Creator       : Robert Hoekstra, SNL, Parallel Computational Sciences
// Creation Date : 03/08/04
//-----------------------------------------------------------------------------
Epetra_MapColoring * Builder::createSolnColoring() const
{
  const std::vector<char> & charColors = lasQueryUtil_->rowList_VarType();

  int size = charColors.size();
  std::vector<int> colors( size );
  for( int i = 0; i < size; ++i )
  {
    switch( charColors[i] )
    {
      case 'V': colors[i] = 0;
                break;
      case 'I': colors[i] = 1;
                break;
      default : colors[i] = 2;
                break;
    }
  }

  return new Epetra_MapColoring( *(pdsMgr_->getParallelMap(Parallel::SOLUTION)->petraBlockMap()),
                                 &colors[0], 0 );
}


//-----------------------------------------------------------------------------
// Function      : Builder::createInitialConditionColoring
// Purpose       :
// Special Notes : The .IC and .NODESET capabilities will use the variables
//                 which are colored 0.  This will be all voltage nodes not
//                 connected to independent sources.
// Scope         : Public
// Creator       : Eric R. Keiter,  SNL
// Creation Date : 10/15/07
//-----------------------------------------------------------------------------
Epetra_MapColoring * Builder::createInitialConditionColoring() const
{
  const std::vector<char> & charColors = lasQueryUtil_->rowList_VarType();
  const std::vector<int> & vsrcGIDColors = lasQueryUtil_->vsrcGIDVec();

  int size = charColors.size();
  int vsrcSize = vsrcGIDColors.size();
  std::vector<int> colors( size );
  for( int i = 0; i < size; ++i )
  {
    switch( charColors[i] )
    {
      case 'V': colors[i] = 0;
                break;
      case 'I': colors[i] = 1;
                break;
      default : colors[i] = 2;
                break;
    }
  }

  N_PDS_ParMap * solnMap = pdsMgr_->getParallelMap(Parallel::SOLUTION);
  for( int i=0; i < vsrcSize; ++i )
  {
    int vsrcID = vsrcGIDColors[i];
    // Convert the ID from local to global if it is valid and the build is parallel.
    if (vsrcID >= 0)
    {
#ifdef Xyce_PARALLEL_MPI
      vsrcID = solnMap->globalToLocalIndex( vsrcGIDColors[i] );
#endif
      if (vsrcID < size && vsrcID >= 0)
        colors[vsrcID] = 1;
    }
  }

  return new Epetra_MapColoring( *(solnMap->petraBlockMap()), &colors[0], 0 );
}

//-----------------------------------------------------------------------------
// Function      : Builder::generateParMaps
// Purpose       : Creates parallel maps for SOLN, STATE, STORE, and LEAD_CURRENT
// Special Notes :
// Scope         : Public
// Creator       : Robert Hoekstra, SNL, Parallel Computational Sciences
// Creation Date : 1/24/01
//-----------------------------------------------------------------------------
bool Builder::generateParMaps()
{
  int numLocalRows = lasQueryUtil_->numLocalRows();
  int numLocalStateVars = lasQueryUtil_->numLocalStateVars();
  int numLocalStoreVars = lasQueryUtil_->numLocalStoreVars();
  int numLocalLeadCurrentVars = lasQueryUtil_->numLocalLeadCurrentVars();

  if( pdsMgr_->getPDSComm()->isSerial() )
  {
    // Copy the soln GID list, since ground will be appended to it.
    std::vector<int> arrayGIDs = lasQueryUtil_->rowList_GID();
    const std::vector<int>& arrayStateGIDs = lasQueryUtil_->rowList_StateGID();
    const std::vector<int>& arrayStoreGIDs = lasQueryUtil_->rowList_StoreGID();
    const std::vector<int>& arrayLeadCurrentGIDs = lasQueryUtil_->rowList_LeadCurrentGID();
  
    N_PDS_ParMap *solnMap = pdsMgr_->createParallelMap(numLocalRows, numLocalRows, arrayGIDs);
    N_PDS_ParMap *stateMap = pdsMgr_->createParallelMap(numLocalStateVars, numLocalStateVars, arrayStateGIDs);
    N_PDS_ParMap *storeMap = pdsMgr_->createParallelMap(numLocalStoreVars, numLocalStoreVars, arrayStoreGIDs);
    N_PDS_ParMap *leadCurrentMap = pdsMgr_->createParallelMap(numLocalLeadCurrentVars, numLocalLeadCurrentVars, arrayLeadCurrentGIDs);

    // Create solution map with ground by appending ground to the end of the arrayGIDs vector.
    arrayGIDs.push_back(-1);
    numLocalRows++;
    N_PDS_ParMap *overlapGndSolnMap = pdsMgr_->createParallelMap(
	numLocalRows,
        numLocalRows,
        arrayGIDs,
        -1 );

    // Register serial maps. 
    pdsMgr_->addParallelMap( Parallel::SOLUTION, solnMap );
    pdsMgr_->addParallelMap( Parallel::STATE, stateMap );
    pdsMgr_->addParallelMap( Parallel::STORE, storeMap );
    pdsMgr_->addParallelMap( Parallel::LEADCURRENT, leadCurrentMap );
    pdsMgr_->addParallelMap( Parallel::SOLUTION_OVERLAP_GND, overlapGndSolnMap );

    // Link maps that are the same in serial and parallel because of the lack of overlap.
    pdsMgr_->linkParallelMap( Parallel::SOLUTION_OVERLAP, Parallel::SOLUTION );
    pdsMgr_->linkParallelMap( Parallel::STATE_OVERLAP, Parallel::STATE );
    pdsMgr_->linkParallelMap( Parallel::STORE_OVERLAP, Parallel::STORE );
    pdsMgr_->linkParallelMap( Parallel::LEADCURRENT_OVERLAP, Parallel::LEADCURRENT );
  }
  else
  {
    // Create solution map, solution overlap map, and solution overlap map with ground nodes.
    std::vector<int> arrayGIDs = lasQueryUtil_->rowList_GID();

    int numGlobalRows = lasQueryUtil_->numGlobalRows();
    N_PDS_ParMap *solnMap = pdsMgr_->createParallelMap(numGlobalRows, numLocalRows, arrayGIDs);

    int procCnt = pdsMgr_->getPDSComm()->numProc();
    int numExternRows = lasQueryUtil_->numExternRows();
    int totalRows = numLocalRows + numExternRows;

    int size = lasQueryUtil_->rowList_ExternGID().size();
    for(int i = 0; i < size; ++i)
      arrayGIDs.push_back(lasQueryUtil_->rowList_ExternGID()[i].first);

    int numGlobalExternRows = lasQueryUtil_->numGlobalExternRows();
    int totalGlobalRows = numGlobalRows + numGlobalExternRows;
    N_PDS_ParMap *overlapSolnMap = pdsMgr_->createParallelMap(
  	totalGlobalRows,
        totalRows,
        arrayGIDs );

    arrayGIDs.push_back(-1);
    totalGlobalRows += procCnt;
    totalRows++;
    N_PDS_ParMap *overlapGndSolnMap = pdsMgr_->createParallelMap(
	totalGlobalRows,
        totalRows,
        arrayGIDs,
        -1 );

    // Register the parallel maps.
    pdsMgr_->addParallelMap( Parallel::SOLUTION, solnMap );
    pdsMgr_->addParallelMap( Parallel::SOLUTION_OVERLAP, overlapSolnMap );
    pdsMgr_->addParallelMap( Parallel::SOLUTION_OVERLAP_GND, overlapGndSolnMap );

    // Output size of overlap.
    if (VERBOSE_LINEAR)
    {
      int procID = pdsMgr_->getPDSComm()->procID();

      std::cout << "Solution variable distribution, Processor: " << procID << " of " << procCnt << ": numLocalRows= " << numLocalRows << " of numGlobalRows= " << numGlobalRows << std::endl; 
      std::cout << "Solution variable overlap, Processor " << procID << " of " << procCnt << ": numExternRows= " << numExternRows << " of numGlobalExternRows= " << numGlobalExternRows << std::endl; 
    }

    // Create state map and state overlap map.
    int numGlobalStateVars = lasQueryUtil_->numGlobalStateVars();
    int numGlobalExternStateVars = lasQueryUtil_->numGlobalExternStateVars();
    //if (numGlobalExternStateVars)
    {
      std::vector<int> arrayStateGIDs = lasQueryUtil_->rowList_StateGID();
      N_PDS_ParMap *stateMap = pdsMgr_->createParallelMap(numGlobalStateVars, numLocalStateVars, arrayStateGIDs);

      int numExternStateVars = lasQueryUtil_->numExternStateVars();
      int totalStateVars = numLocalStateVars + numExternStateVars;
      arrayStateGIDs.reserve(totalStateVars);

      size = lasQueryUtil_->rowList_ExternStateGID().size();
      for( int i = 0; i < size; ++i )
        arrayStateGIDs.push_back(lasQueryUtil_->rowList_ExternStateGID()[i].first);

      int totalGlobalStateVars = numGlobalStateVars + numGlobalExternStateVars;
      N_PDS_ParMap *overlapStateMap = pdsMgr_->createParallelMap(
        totalGlobalStateVars,
        totalStateVars,
        arrayStateGIDs );
      
      // Register the parallel maps.
      pdsMgr_->addParallelMap( Parallel::STATE, stateMap );
      pdsMgr_->addParallelMap( Parallel::STATE_OVERLAP, overlapStateMap );
    }
    /*
    else
    {
      const std::vector<int>& arrayStateGIDs = lasQueryUtil_->rowList_StateGID();
      N_PDS_ParMap *stateMap = pdsMgr_->createParallelMap(numGlobalStateVars, numLocalStateVars, arrayStateGIDs);
      pdsMgr_->addParallelMap( Parallel::STATE, stateMap );
      pdsMgr_->linkParallelMap( Parallel::STATE_OVERLAP, Parallel::STATE );
    } 
    */

    // Create store map and store overlap map.
    int numGlobalStoreVars = lasQueryUtil_->numGlobalStoreVars();
    int numGlobalExternStoreVars = lasQueryUtil_->numGlobalExternStoreVars();
    //if (numGlobalExternStoreVars)
    {
      std::vector<int> arrayStoreGIDs = lasQueryUtil_->rowList_StoreGID();
      N_PDS_ParMap *storeMap = pdsMgr_->createParallelMap(numGlobalStoreVars, numLocalStoreVars, arrayStoreGIDs);

      int numExternStoreVars = lasQueryUtil_->numExternStoreVars();
      int totalStoreVars = numLocalStoreVars + numExternStoreVars;
      arrayStoreGIDs.reserve(totalStoreVars);

      size = lasQueryUtil_->rowList_ExternStoreGID().size();
      for( int i = 0; i < size; ++i )
        arrayStoreGIDs.push_back(lasQueryUtil_->rowList_ExternStoreGID()[i].first);

      int totalGlobalStoreVars = numGlobalStoreVars + numGlobalExternStoreVars;
      N_PDS_ParMap *overlapStoreMap = pdsMgr_->createParallelMap(
        totalGlobalStoreVars,
        totalStoreVars,
        arrayStoreGIDs );
   
      // Register the parallel maps. 
      pdsMgr_->addParallelMap( Parallel::STORE, storeMap );
      pdsMgr_->addParallelMap( Parallel::STORE_OVERLAP, overlapStoreMap );
    }
    /*
    else
    {
      const std::vector<int>& arrayStoreGIDs = lasQueryUtil_->rowList_StoreGID();
      N_PDS_ParMap *storeMap = pdsMgr_->createParallelMap(numGlobalStoreVars, numLocalStoreVars, arrayStoreGIDs);
      pdsMgr_->addParallelMap( Parallel::STORE, storeMap );
      pdsMgr_->linkParallelMap( Parallel::STORE_OVERLAP, Parallel::STORE );
    }
    */
  
    // Create lead current map and lead current overlap map.
    int numGlobalLeadCurrentVars = lasQueryUtil_->numGlobalLeadCurrentVars();
    int numGlobalExternLeadCurrentVars = lasQueryUtil_->numGlobalExternLeadCurrentVars();
    //if (numGlobalExternLeadCurrentVars)
    {
      std::vector<int> arrayLeadCurrentGIDs = lasQueryUtil_->rowList_LeadCurrentGID();
      N_PDS_ParMap *leadCurrentMap = pdsMgr_->createParallelMap(numGlobalLeadCurrentVars, numLocalLeadCurrentVars, arrayLeadCurrentGIDs);
    
      int numExternLeadCurrentVars = lasQueryUtil_->numExternLeadCurrentVars();
      int totalLeadCurrentVars = numLocalLeadCurrentVars + numExternLeadCurrentVars;
      arrayLeadCurrentGIDs.reserve(totalLeadCurrentVars);
      
      size = lasQueryUtil_->rowList_ExternLeadCurrentGID().size();
      for( int i = 0; i < size; ++i )
        arrayLeadCurrentGIDs.push_back(lasQueryUtil_->rowList_ExternLeadCurrentGID()[i].first);

      int totalGlobalLeadCurrentVars = numGlobalLeadCurrentVars + numGlobalExternLeadCurrentVars;
      N_PDS_ParMap *overlapLeadCurrentMap = pdsMgr_->createParallelMap(
        totalGlobalLeadCurrentVars,
        totalLeadCurrentVars,
        arrayLeadCurrentGIDs );

      // Register all parallel maps.
      pdsMgr_->addParallelMap( Parallel::LEADCURRENT, leadCurrentMap );
      pdsMgr_->addParallelMap( Parallel::LEADCURRENT_OVERLAP, overlapLeadCurrentMap );
    }
    /*
    else
    {
      const std::vector<int>& arrayLeadCurrentGIDs = lasQueryUtil_->rowList_LeadCurrentGID();
      N_PDS_ParMap *leadCurrentMap = pdsMgr_->createParallelMap(numLocalLeadCurrentVars, numLocalLeadCurrentVars, arrayLeadCurrentGIDs);
      pdsMgr_->addParallelMap( Parallel::LEADCURRENT, leadCurrentMap );
      pdsMgr_->linkParallelMap( Parallel::LEADCURRENT_OVERLAP, Parallel::LEADCURRENT );
    }
    */

    // Add global accessors for parallel data migration.
    // NOTE:  This has to be after the map registration.
    N_PDS_GlobalAccessor * solnGA = pdsMgr_->addGlobalAccessor( Parallel::SOLUTION );
    solnGA->registerExternGIDVector( lasQueryUtil_->rowList_ExternGID() );
    solnGA->generateMigrationPlan();

    if (numGlobalExternStateVars)
    {
      N_PDS_GlobalAccessor * stateGA = pdsMgr_->addGlobalAccessor( Parallel::STATE );
      stateGA->registerExternGIDVector( lasQueryUtil_->rowList_ExternStateGID() );
      stateGA->generateMigrationPlan();
    }

    if (numGlobalExternStoreVars)
    {
      N_PDS_GlobalAccessor * storeGA = pdsMgr_->addGlobalAccessor( Parallel::STORE );
      storeGA->registerExternGIDVector( lasQueryUtil_->rowList_ExternStoreGID() );
      storeGA->generateMigrationPlan();
    }
  }

  return true;
}

//-----------------------------------------------------------------------------
// Function      : Builder::generateGraphs
// Purpose       : Generation of Matrix Graphs, stored with ParMgr
// Special Notes :
// Scope         : Public
// Creator       : Robert Hoekstra, SNL, Parallel Computational Sciences
// Creation Date : 8/23/02
//-----------------------------------------------------------------------------
bool Builder::generateGraphs()
{
  const std::vector< std::vector<int> > & rcData = lasQueryUtil_->rowList_ColList();
  const std::vector<int> & arrayNZs = lasQueryUtil_->rowList_NumNZs();

  int numLocalRows_Overlap = rcData.size();

  Epetra_BlockMap & overlapGndMap = *(pdsMgr_->getParallelMap( Parallel::SOLUTION_OVERLAP_GND )->petraBlockMap());
  Epetra_BlockMap & overlapMap = *(pdsMgr_->getParallelMap( Parallel::SOLUTION_OVERLAP )->petraBlockMap());
  Epetra_BlockMap & localMap = *(pdsMgr_->getParallelMap( Parallel::SOLUTION )->petraBlockMap());

  Epetra_CrsGraph * overlapGndGraph = new Epetra_CrsGraph( Copy, overlapGndMap, &arrayNZs[0] );
  Epetra_CrsGraph * overlapGraph = new Epetra_CrsGraph( Copy, overlapMap, &arrayNZs[0] );

  for( int i = 0; i < numLocalRows_Overlap; ++i )
  {
    std::vector<int>& rcData_i = const_cast<std::vector<int> &>(rcData[i]);
    if( arrayNZs[i] )
      overlapGndGraph->InsertGlobalIndices( overlapGndMap.GID(i), arrayNZs[i], &rcData_i[0] );

    if( overlapGndMap.GID(i) != -1 && arrayNZs[i] )
    {
      if( rcData_i[0] == -1 )
        overlapGraph->InsertGlobalIndices( overlapMap.GID(i), arrayNZs[i]-1, &rcData_i[1] );
      else
        overlapGraph->InsertGlobalIndices( overlapMap.GID(i), arrayNZs[i], &rcData_i[0] );
    }
  }
  overlapGndGraph->FillComplete();
  overlapGraph->FillComplete();
  pdsMgr_->addMatrixGraph( Parallel::JACOBIAN_OVERLAP_GND, overlapGndGraph );
  pdsMgr_->addMatrixGraph( Parallel::JACOBIAN_OVERLAP, overlapGraph );

  if( pdsMgr_->getPDSComm()->isSerial() )
  {
    // The Jacobian graph and Jacobian overlap graph are the same in serial.
    pdsMgr_->linkMatrixGraph( Parallel::JACOBIAN, Parallel::JACOBIAN_OVERLAP );
  }
  else
  {
    Epetra_Export exporter( overlapMap, localMap );
    Epetra_CrsGraph * localGraph = new Epetra_CrsGraph( Copy, localMap, 0 );
    localGraph->Export( *overlapGraph, exporter, Add );
    if (VERBOSE_LINEAR)
      Xyce::lout() << "Exported To Local Graph!\n"  << std::endl;

    localGraph->FillComplete();

    if (VERBOSE_LINEAR)
      Xyce::lout() << "Local Graph Transformed!\n"  << std::endl;

    pdsMgr_->addMatrixGraph( Parallel::JACOBIAN, localGraph );
  }

  return true;
}

//-----------------------------------------------------------------------------
// Function      : Builder::setupSeparatedLSObjects()
// Purpose       :
// Special Notes : This is for the separation of the solution variables related
//                 to linear and nonlinear devices.
// Scope         : Public
// Creator       : Heidi Thornquist and Ting Mei, Electrical Simulation and Modeling
// Creation Date : 04/01/15
//-----------------------------------------------------------------------------
bool Builder::setupSeparatedLSObjects()
{
  // First create separate linear and nonlinear maps.

  // Get all of the local GIDs
  const std::vector<int>& arrayGIDs = lasQueryUtil_->rowList_GID();

  // Get only the local nonlin GIDs
  // NOTE:  These are not necessarily local in terms of the current solution map.
  const std::vector<int>& nonlinGIDs = lasQueryUtil_->nonlinGIDVec();

  // Collect the global nonlin GIDs
  int tnumNonlinGIDs = nonlinGIDs.size();
  int numNonlinGIDs = nonlinGIDs.size();
  pdsMgr_->getPDSComm()->sumAll( &numNonlinGIDs, &tnumNonlinGIDs, 1 );
  std::vector<int> globalNLGIDs( tnumNonlinGIDs );
  std::vector<int> finalNLGIDs( tnumNonlinGIDs );

  std::vector<int>::iterator nonlin_it;

#ifdef Xyce_PARALLEL_MPI
  int procCnt = pdsMgr_->getPDSComm()->numProc();
  int procID = pdsMgr_->getPDSComm()->procID();
  std::vector<int> numNLGIDs( procCnt, 0.0 );
  Parallel::AllGather(pdsMgr_->getPDSComm()->comm(), numNonlinGIDs, numNLGIDs);
  for (int i=1; i<procCnt; i++)
    numNLGIDs[i] += numNLGIDs[i-1];
  numNLGIDs.insert(numNLGIDs.begin(), 0);

  std::vector<int> tmp_allNLGIDs( tnumNonlinGIDs ); 
  for (int i=numNLGIDs[procID]; i<numNLGIDs[procID+1]; i++)
    tmp_allNLGIDs[ i ] = nonlinGIDs[ i - numNLGIDs[procID] ];

  pdsMgr_->getPDSComm()->sumAll( &tmp_allNLGIDs[0], &globalNLGIDs[0], tnumNonlinGIDs );
  std::sort( globalNLGIDs.begin(), globalNLGIDs.end() );
  std::vector<int>::iterator last = std::unique(globalNLGIDs.begin(), globalNLGIDs.end());
  globalNLGIDs.erase(last, globalNLGIDs.end());
  tnumNonlinGIDs = globalNLGIDs.size();

  // Get list of global nonlinear GIDs that are on this processor.
  // NOTE:  nonlinGIDs may have off-processor GIDs, so this is necessary in parallel.
  nonlin_it = std::set_intersection (globalNLGIDs.begin(), globalNLGIDs.end(),
                                     arrayGIDs.begin(), arrayGIDs.end(),
                                     finalNLGIDs.begin());
  finalNLGIDs.resize(nonlin_it-finalNLGIDs.begin());      
#else
  globalNLGIDs = nonlinGIDs;
  finalNLGIDs = nonlinGIDs;
#endif
  
  // Make linear GID vector.
  // NOTE: This is the initial cut at the linear GIDs, it will be pruned after
  // the graph is generated in the event that any linearGID is associated with
  // a nonlinear node 
  // (ex. a vsrc connected to a nonlinear device, branch equation uses nonlinear node)
  std::vector<int> linGIDs;

  nonlin_it = globalNLGIDs.begin();
  std::vector<int>::const_iterator lcl_it = arrayGIDs.begin();
  for ( ; lcl_it != arrayGIDs.end(); lcl_it++ )
  {
    std::vector<int>::iterator found_it = std::find( nonlin_it, globalNLGIDs.end(), *lcl_it );
    if (found_it == globalNLGIDs.end())
      linGIDs.push_back( *lcl_it );
    else 
      nonlin_it = found_it;
  }
  std::sort( linGIDs.begin(), linGIDs.end() );

  // First create the graphs, then correct the maps, remove linear GIDs if necessary.
  Epetra_Map * baseMap = pdsMgr_->getParallelMap(Parallel::SOLUTION)->petraMap();
  Epetra_CrsGraph * baseFullGraph = pdsMgr_->getMatrixGraph(Parallel::JACOBIAN);
  int numLocalRows = baseFullGraph->NumMyRows();

  std::vector<int> linArrayNZs(numLocalRows), nonlinArrayNZs(numLocalRows);
  std::vector< std::vector<int> > linArrayCols( numLocalRows), nonlinArrayCols( numLocalRows);
 
  int numIndices, maxIndices = baseFullGraph->MaxNumIndices();
  std::vector<int> Indices(maxIndices); 

  for (int i=0; i<numLocalRows; i++)
  {
    std::vector<int>::iterator found_it = std::find( linGIDs.begin(), linGIDs.end(), arrayGIDs[i] );

    int baseRow = baseMap->GID(i);
    baseFullGraph->ExtractGlobalRowCopy( baseRow, maxIndices, numIndices, &Indices[0] );
    std::sort( Indices.begin(), Indices.begin()+numIndices );

    // Check if this is a row associated with a linear device
    if (found_it != linGIDs.end())
    {
      // Check if there are any linear GID entries in linArrayCols.  If not, this linear variable
      // must have an equation that uses purely nonlinear nodes (ex. branch equations)
      bool isEmpty = std::includes( globalNLGIDs.begin(), globalNLGIDs.end(), 
                                    Indices.begin(), Indices.begin()+numIndices );

      // This row is associated with a linear device, we copy the whole thing.
      if (!isEmpty)
      {
        linArrayCols[i].resize( numIndices );
        std::copy( Indices.begin(), Indices.begin()+numIndices, linArrayCols[i].begin() );
      }
      else
      { 
        // There are no linear GIDs associated with this linear row, move it to a nonlinear GID.
        int removedGID = *(found_it);
        linGIDs.erase( found_it );
        globalNLGIDs.push_back( removedGID );
        std::sort( globalNLGIDs.begin(), globalNLGIDs.end() );
        finalNLGIDs.push_back( removedGID );
        std::sort( finalNLGIDs.begin(), finalNLGIDs.end() );
        nonlinArrayCols[i].resize( numIndices );
        std::copy( Indices.begin(), Indices.begin()+numIndices, nonlinArrayCols[i].begin() );
      }
    }
    else
    {
      // Pick out entries that are nonlinear GIDs
      nonlin_it = globalNLGIDs.begin();
      std::vector<int>::iterator lin_it = linGIDs.begin();
      std::vector<int>::iterator lin_end = linGIDs.end();
      std::vector<int>::iterator all_it = Indices.begin();
      for ( ; all_it != Indices.begin()+numIndices; all_it++ )
      {
        // Check if in nonlinear list
        std::vector<int>::iterator check_it = std::find( nonlin_it, globalNLGIDs.end(), *all_it );
        if (check_it != globalNLGIDs.end()) 
        {
          
          nonlinArrayCols[i].push_back( *all_it );
          nonlin_it = check_it;
        }
        else
        {
          linArrayCols[i].push_back( *all_it );
        }
      }
    }
    
    // Get the number of nonzeros for these rows.
    linArrayNZs[i] = linArrayCols[i].size();
    nonlinArrayNZs[i] = nonlinArrayCols[i].size();
  }

  // Get final nonlinear GID list size, just in case some were added.
  numNonlinGIDs = finalNLGIDs.size();

  // Construct maps from linear and nonlinear data.
  int tnumLinGIDs, numLinGIDs = linGIDs.size();
  pdsMgr_->getPDSComm()->sumAll( &numLinGIDs, &tnumLinGIDs, 1 );
  pdsMgr_->getPDSComm()->sumAll( &numNonlinGIDs, &tnumNonlinGIDs, 1 );

  N_PDS_ParMap * linSolnMap = pdsMgr_->createParallelMap(tnumLinGIDs, numLinGIDs, linGIDs);
  N_PDS_ParMap * nonlinSolnMap = pdsMgr_->createParallelMap(tnumNonlinGIDs, numNonlinGIDs, finalNLGIDs);
  pdsMgr_->addParallelMap(Parallel::LINEAR_SOLUTION, linSolnMap);
  pdsMgr_->addParallelMap(Parallel::NONLINEAR_SOLUTION, nonlinSolnMap);

  if (DEBUG_LINEAR)
  {
    Xyce::dout() << "Linear Solution Map:" << std::endl;
    linSolnMap->petraMap()->Print(std::cout);

    Xyce::dout() << "Nonlinear Solution Map:" << std::endl;
    nonlinSolnMap->petraMap()->Print(std::cout);

    // Construct graphs from linear and nonlinear data.
    Xyce::dout() << "Base solution map:" << std::endl;
    baseMap->Print(std::cout);
  }

  Epetra_CrsGraph * linearGraph = new Epetra_CrsGraph( Copy, *baseMap, &linArrayNZs[0] );
  Epetra_CrsGraph * nonlinGraph = new Epetra_CrsGraph( Copy, *baseMap, &nonlinArrayNZs[0] );

  for( int i = 0; i < numLocalRows; ++i )
  {
    // Add linear variable entries to graph.
    if( linArrayNZs[i] )
    {
      linearGraph->InsertGlobalIndices( arrayGIDs[i], linArrayNZs[i], &(linArrayCols[i])[0] );
    }
    // Add nonlinear variable entries to graph.
    if( nonlinArrayNZs[i] )
    {
      nonlinGraph->InsertGlobalIndices( arrayGIDs[i], nonlinArrayNZs[i], &(nonlinArrayCols[i])[0] );
    }
  }
  linearGraph->FillComplete();
  nonlinGraph->FillComplete();

  pdsMgr_->addMatrixGraph( Parallel::LINEAR_JACOBIAN, linearGraph );
  pdsMgr_->addMatrixGraph( Parallel::NONLINEAR_JACOBIAN, nonlinGraph );

  if (DEBUG_LINEAR)
  {
    std::cout << "Linear graph: " << std::endl;
    linearGraph->Print(std::cout);  
    std::cout << "Nonlinear graph: " << std::endl;
    nonlinGraph->Print(std::cout); 
  }

  return true;
}

//-----------------------------------------------------------------------------
// Function      : Builder::getSeparatedSolnMap
// Purpose       :
// Special Notes : This is for the separation of the solution variables related
//                 to linear and nonlinear devices.
// Scope         : Public
// Creator       : Heidi Thornquist and Ting Mei, Electrical Simulation and Modeling
// Creation Date : 04/01/15
//-----------------------------------------------------------------------------
void Builder::getSeparatedSolnMap( RCP<N_PDS_ParMap>& linear_map,
                                   RCP<N_PDS_ParMap>& nonlin_map
                                 ) const
{
  linear_map = Teuchos::rcp(pdsMgr_->getParallelMap(Parallel::LINEAR_SOLUTION),false);
  nonlin_map = Teuchos::rcp(pdsMgr_->getParallelMap(Parallel::NONLINEAR_SOLUTION),false);
}

//-----------------------------------------------------------------------------
// Function      : Builder::getSeparatedGraph
// Purpose       :
// Special Notes : This is for the separation of the solution variables related
//                 to linear and nonlinear devices.
// Scope         : Public
// Creator       : Heidi Thornquist and Ting Mei, Electrical Simulation and Modeling
// Creation Date : 04/01/15
//-----------------------------------------------------------------------------
void Builder::getSeparatedGraph( RCP<Epetra_CrsGraph>& linear_graph,
                                 RCP<Epetra_CrsGraph>& nonlin_graph
                               ) const
{
  linear_graph = Teuchos::rcp(pdsMgr_->getMatrixGraph( Parallel::LINEAR_JACOBIAN ),false);
  nonlin_graph = Teuchos::rcp(pdsMgr_->getMatrixGraph( Parallel::NONLINEAR_JACOBIAN ),false);
}

//-----------------------------------------------------------------------------
// Function      : Builder::getSolutionMap
// Purpose       :
// Special Notes : This is specifically for blockAnalysis types (like MPDE & HB)
// so we can get a valid map from the builder.
// Scope         : Public
// Creator       : Todd Coffey, 1414
// Creation Date : 09/05/08
//-----------------------------------------------------------------------------
RCP<const Epetra_Map> Builder::getSolutionMap() const
{
  return(Teuchos::rcp(pdsMgr_->getParallelMap(Parallel::SOLUTION)->petraMap(),false));
}

//-----------------------------------------------------------------------------
// Function      : Builder::getSolutionMap
// Purpose       :
// Special Notes : This is specifically for blockAnalysis types (like MPDE & HB)
// so we can get a valid map from the builder.
// Scope         : Public
// Creator       : Todd Coffey, 1414
// Creation Date : 09/05/08
//-----------------------------------------------------------------------------
RCP<Epetra_Map> Builder::getSolutionMap() 
{
  return(Teuchos::rcp(pdsMgr_->getParallelMap(Parallel::SOLUTION)->petraMap(),false));
}

} // namespace Linear
} // namespace Xyce
