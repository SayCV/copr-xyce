//-----------------------------------------------------------------------------
// Copyright Notice
//
//   Copyright 2002 Sandia Corporation. Under the terms
//   of Contract DE-AC04-94AL85000 with Sandia Corporation, the U.S.
//   Government retains certain rights in this software.
//
//    Xyce(TM) Parallel Electrical Simulator
//    Copyright (C) 2002-2017 Sandia Corporation
//
//    This program is free software: you can redistribute it and/or modify
//    it under the terms of the GNU General Public License as published by
//    the Free Software Foundation, either version 3 of the License, or
//    (at your option) any later version.
//
//    This program is distributed in the hope that it will be useful,
//    but WITHOUT ANY WARRANTY; without even the implied warranty of
//    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//    GNU General Public License for more details.
//
//    You should have received a copy of the GNU General Public License
//    along with this program.  If not, see <http://www.gnu.org/licenses/>.
//-----------------------------------------------------------------------------

//-------------------------------------------------------------------------
//
// Purpose        : Implemenation file for the Abstract interface to sparse
//                  matrix type.
//
// Special Notes  :
//
// Creator        : Scott A. Hutchinson, SNL, Parallel Computational Sciences
//
// Creation Date  : 05/20/00
//
//
//
//
//-------------------------------------------------------------------------

#include <Xyce_config.h>


// ---------- Standard Includes ----------

#include <algorithm>

// ----------   Xyce Includes   ----------

#include <N_UTL_fwd.h>

#include <N_ERH_ErrorMgr.h>
#include <N_LAS_Matrix.h>
#include <N_LAS_MultiVector.h>
#include <N_LAS_Vector.h>
#include <N_PDS_ParMap.h>
#include <N_UTL_FeatureTest.h>

#include <Epetra_CrsMatrix.h>
#include <Epetra_Vector.h>
#include <Epetra_CrsGraph.h>
#include <Epetra_Export.h>
#include <Epetra_Import.h>
#include <Epetra_Map.h>
#include <Epetra_Comm.h>
#include <EpetraExt_View_CrsMatrix.h>
#include <EpetraExt_RowMatrixOut.h>
#include <Epetra_OffsetIndex.h>

namespace Xyce {
namespace Linear {

//-----------------------------------------------------------------------------
// Function      : Matrix::~Matrix
// Purpose       : Destructor
// Special Notes :
// Scope         : Public
// Creator       : Scott A. Hutchinson, SNL, Parallel Computational Sciences
// Creation Date : 05/20/00
//-----------------------------------------------------------------------------
Matrix::~Matrix()
{
  if ( isOwned_ ) 
  {
    if( oDCRSMatrix_ != aDCRSMatrix_ )
    {
      if( viewTransform_ )
      {
        delete viewTransform_; //destroys aDCRSMatrix_ as well
      }
      else
      {
        delete aDCRSMatrix_;
      }
    }

    if( oDCRSMatrix_ ) 
      delete oDCRSMatrix_;
  }

  if( exporter_ ) 
    delete exporter_;

  if( offsetIndex_ ) 
    delete offsetIndex_;
}


//-----------------------------------------------------------------------------
// Function      : Matrix::Matrix
// Purpose       : Constructor
// Special Notes :
// Scope         : Public
// Creator       : Scott A. Hutchinson, SNL, Parallel Computational Sciences
// Creation Date : 06/04/00
//-----------------------------------------------------------------------------
Matrix::Matrix( N_PDS_ParMap & map, std::vector<int> & diagArray )
: aDCRSMatrix_(0),
  oDCRSMatrix_(0),
  viewTransform_(0),
  exporter_(0),
  offsetIndex_(0),
  isOwned_(true)
{
  aDCRSMatrix_ = new Epetra_CrsMatrix( Copy, *map.petraMap() , &(diagArray[0]) );
  oDCRSMatrix_ = aDCRSMatrix_;
}

//-----------------------------------------------------------------------------
// Function      : Matrix::Matrix
// Purpose       : Constructor
// Special Notes :
// Scope         : Public
// Creator       : Robert Hoekstra, SNL, Parallel Computational Sciences
// Creation Date : 04/09/03
//-----------------------------------------------------------------------------
Matrix::Matrix( Epetra_CrsMatrix * origMatrix, bool isOwned )
: aDCRSMatrix_( origMatrix ),
  viewTransform_(0),
  exporter_(0),
  offsetIndex_(0),
  isOwned_(isOwned)
{
  oDCRSMatrix_ = aDCRSMatrix_;
}

//-----------------------------------------------------------------------------
// Function      : Matrix::Matrix
// Purpose       : Constructor
// Special Notes :
// Scope         : Public
// Creator       : Robert Hoekstra, SNL, Parallel Computational Sciences
// Creation Date : 08/21/02
//-----------------------------------------------------------------------------
Matrix::Matrix( Epetra_CrsGraph * overlapGraph,
                Epetra_CrsGraph * baseGraph )
: aDCRSMatrix_(0),
  oDCRSMatrix_(0),
  viewTransform_(0),
  exporter_(0),
  offsetIndex_(0),
  isOwned_(true)
{
  oDCRSMatrix_ = new Epetra_CrsMatrix( Copy, *overlapGraph );

  if ( (oDCRSMatrix_->Comm()).NumProc() > 1 )
  { 
    aDCRSMatrix_ = new Epetra_CrsMatrix( Copy, *baseGraph );
    exporter_ = new Epetra_Export( overlapGraph->RowMap(), baseGraph->RowMap() );
    offsetIndex_ = new Epetra_OffsetIndex( *overlapGraph, *baseGraph, *exporter_ );
  }
  else
  {
    viewTransform_ = new EpetraExt::CrsMatrix_View( *overlapGraph, *baseGraph );
    aDCRSMatrix_ = &((*viewTransform_)( *oDCRSMatrix_ ));
  }
}

//-----------------------------------------------------------------------------
// Function      : Matrix::fillComplete
// Purpose       :
// Special Notes :
// Scope         : Public
// Creator       : Robert Hoekstra, SNL, Parallel Computational Sciences
// Creation Date : 08/29/03
//-----------------------------------------------------------------------------
void Matrix::fillComplete()
{
  if( exporter_ )
  {
    aDCRSMatrix_->Export( *oDCRSMatrix_, *exporter_, Add, offsetIndex_ );
  }
}

//-----------------------------------------------------------------------------
// Function      : Matrix::matvec
// Purpose       : Sparse-matrix vector multiply - multivector version.  This
//                 function forms the product y = Ax where x and y are
//                 multivectors.  If transA is true, multiply by the transpose
//                 of matrix, otherwise just use matrix.
// Special Notes :
// Scope         : Public
// Creator       : Scott A. Hutchinson, SNL, Parallel Computational Sciences
// Creation Date : 06/04/00
//-----------------------------------------------------------------------------
void Matrix::matvec(bool transA, const MultiVector &x,
                          MultiVector &y)
{
  int PetraError = aDCRSMatrix_->Multiply(transA, *(x.aMultiVector_),
					  *(y.aMultiVector_));

  if (DEBUG_LINEAR)
    processError( "Matrix::matvec - ", PetraError);
}

//-----------------------------------------------------------------------------
// Function      : Matrix::filterInfNorm
// Purpose       : Filter out values below inf norm * threshold
// Special Notes :
// Scope         : Public
// Creator       : Robert J Hoekstra, SNL, Parallel Computational Sciences
// Creation Date : 3/4/01
//-----------------------------------------------------------------------------
void Matrix::filterInfNorm( const double & threshold )
{
  if( aDCRSMatrix_->Filled() ) return;

  double thres = threshold * aDCRSMatrix_->NormInf();
  int numMyRows = aDCRSMatrix_->NumMyRows();
  int numEntries;
  int * indices;
  double * values;

  for( int i = 0; i < numMyRows; ++i )
  {
    aDCRSMatrix_->ExtractMyRowView( i, numEntries, values, indices );
    for( int j = 0; j < numEntries; ++j )
      if( fabs(values[j]) < thres ) values[j] = 0.0;
  }
}

//-----------------------------------------------------------------------------
// Function      : Matrix::filterRowSum
// Purpose       : Filter out values below row sum * threshold
// Special Notes :
// Scope         : Public
// Creator       : Robert J Hoekstra, SNL, Parallel Computational Sciences
// Creation Date : 3/4/01
//-----------------------------------------------------------------------------
void Matrix::filterRowSum( const double & threshold )
{
  if( aDCRSMatrix_->Filled() ) return;

  Epetra_Vector vec( aDCRSMatrix_->RowMap() );
  aDCRSMatrix_->InvRowSums( vec );

  int numMyRows = aDCRSMatrix_->NumMyRows();
  int numEntries;
  int * indices;
  double * values;

  for( int i = 0; i < numMyRows; ++i )
  {
    aDCRSMatrix_->ExtractMyRowView( i, numEntries, values, indices );
    double rowThres = threshold / vec[i];
    for( int j = 0; j < numEntries; ++j )
      if( fabs(values[j]) < rowThres ) values[j] = 0.0;
  }
}

//-----------------------------------------------------------------------------
// Function      : Matrix::put
// Purpose       : Put function for the sparse-matrix.
// Special Notes :
// Scope         : Public
// Creator       : Scott A. Hutchinson, SNL, Parallel Computational Sciences
// Creation Date : 06/04/00
//-----------------------------------------------------------------------------
void Matrix::put( double s )
{
  if ( exporter_ )
  {
    aDCRSMatrix_->PutScalar(s);
  }
  oDCRSMatrix_->PutScalar(s);
}

//-----------------------------------------------------------------------------
// Function      : Matrix::scale
// Purpose       : Scale function for the sparse-matrix.
// Special Notes :
// Scope         : Public
// Creator       : Scott A. Hutchinson, SNL, Parallel Computational Sciences
// Creation Date : 06/04/00
//-----------------------------------------------------------------------------
void Matrix::scale(double scaleFactor)
{
  if ( exporter_ )
  {
    aDCRSMatrix_->Scale(scaleFactor);
  }
  oDCRSMatrix_->Scale(scaleFactor);
}

//-----------------------------------------------------------------------------
// Function      : Matrix::getRowLength
// Purpose       : Returns the number of nonzeroes in the row.
// Special Notes :
// Scope         : Public
// Creator       : Scott A. Hutchinson, SNL, Parallel Computational Sciences
// Creation Date : 06/04/00
//-----------------------------------------------------------------------------
int Matrix::getRowLength(int row) const
{
  return aDCRSMatrix_->NumAllocatedGlobalEntries(row);
}

//-----------------------------------------------------------------------------
// Function      : Matrix::getRow
// Purpose       : Returns row coefficients and associated column indices.
// Special Notes : Uses Petra's ExtractRowCopy so assumes user has
//               : setup necessary space in arrays.  Could use
//               : ExtractRowView which does not require user to setup space.
// Scope         : Public
// Creator       : Scott A. Hutchinson, SNL, Parallel Computational Sciences
// Creation Date : 06/04/00
//-----------------------------------------------------------------------------
void Matrix::getRow(int row, int &length, double *coeffs, int *colIndices) const
{
  std::cout << "Matrix::getRow( " << row << " ) " << std::endl;
  int PetraError = aDCRSMatrix_->ExtractGlobalRowView(row, length, coeffs, colIndices);

  if (DEBUG_LINEAR)
    processError( "Matrix::getRow - ", PetraError );
}


//-----------------------------------------------------------------------------
// Function      : Matrix::getRowCopy
// Purpose       :
// Special Notes :
// Scope         : Public
// Creator       : Eric R. Keiter, SNL
// Creation Date : 03/05/06
//-----------------------------------------------------------------------------
void Matrix::getRowCopy
  (int row, int length, int & numEntries, double *coeffs, int *colIndices) const
{
  int PetraError = aDCRSMatrix_->ExtractGlobalRowCopy
       (row, length, numEntries, coeffs, colIndices);

  if (DEBUG_LINEAR)
    processError( "Matrix::getRowCopy - ", PetraError );
}

//-----------------------------------------------------------------------------
// Function      : Matrix::getLocalRowCopy
// Purpose       :
// Special Notes :
//               :
//               :
// Scope         : Public
// Creator       : Eric R. Keiter, SNL
// Creation Date : 03/05/06
//-----------------------------------------------------------------------------
void Matrix::getLocalRowCopy
  (int row, int length, int & numEntries, double *coeffs, int *colIndices) const
{
  int PetraError = aDCRSMatrix_->ExtractMyRowCopy
       (row, length, numEntries, coeffs, colIndices);

  if (DEBUG_LINEAR)
    processError( "Matrix::getLocalRowCopy - ", PetraError );
}

//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------
// Function      : Matrix::putRow
// Purpose       : Put a row into the sparse matrix.
// Special Notes : Replace already allocated values
// Scope         : Public
// Creator       : Scott A. Hutchinson, SNL, Parallel Computational Sciences
// Creation Date : 06/04/00
//-----------------------------------------------------------------------------
bool Matrix::putRow(int row, int length, const double *coeffs, const int *colIndices)
{
  int PetraError = oDCRSMatrix_->ReplaceGlobalValues(row, length, coeffs, colIndices);

  if (DEBUG_LINEAR)
    processError( "Matrix::putRow - ", PetraError );

  return true;
}

//-----------------------------------------------------------------------------
// Function      : Matrix::getLocalNumRows
// Purpose       : Returns the number of nonzeroes in the row.
// Special Notes :
// Scope         : Public
// Creator       : Dave Shirley, PSSI
// Creation Date : 05/24/06
//-----------------------------------------------------------------------------
int Matrix::getLocalNumRows() const
{
  return aDCRSMatrix_->NumMyRows();
}

//-----------------------------------------------------------------------------
// Function      : Matrix::getLocalRowLength
// Purpose       : Returns the number of nonzeroes in the row.
// Special Notes :
// Scope         : Public
// Creator       : Dave Shirley, PSSI
// Creation Date : 05/05/06
//-----------------------------------------------------------------------------
int Matrix::getLocalRowLength(int row) const
{
  return aDCRSMatrix_->NumMyEntries(row);
}

//-----------------------------------------------------------------------------
// Function      : Matrix::putLocalRow
// Function      : Matrix::shirleyPutRow
// Purpose       : Put a row into the sparse matrix.
// Special Notes : Replace already allocated values.
//                 erkeite: note; unlike putRow, this function uses the
//                 a-matrix.
//
//                 erkeite:  This function was mis-named as putLocalRow.
//                 The row index being used here needs to be a gid (global),
//                 not an lid (local).  I have re-named it shirleyPutRow
//                 for now.  (in part because I need a real putLocalRow).
//
//                 If it were truly a local function, it would call the
//                 epetra function: ReplaceMyValues.
//
// Scope         : Public
// Creator       : Dave Shirley, PSSI
// Creation Date : 05/24/06
//-----------------------------------------------------------------------------
//bool Matrix::putLocalRow(int row, int length, double *coeffs, int *colIndices)
bool Matrix::shirleyPutRow(int row, int length, double *coeffs, int *colIndices)
{
  int PetraError = aDCRSMatrix_->ReplaceGlobalValues(row, length, coeffs, colIndices);

  if (DEBUG_LINEAR)
    processError( "Matrix::putRow - ", PetraError );

  return true;
}

//-----------------------------------------------------------------------------
// Function      : Matrix::putLocalRow
// Purpose       : Put values into a row into the sparse matrix, using local indices.
// Special Notes :
// Scope         : Public
// Creator       : Eric R. Keiter, SNL
// Creation Date : 04/29/12
//-----------------------------------------------------------------------------
bool Matrix::putLocalRow(int row, int length, const double * coeffs,
                                                   const int * colIndices)
{
  double * tmp_c = const_cast<double *>(coeffs);
  int * tmp_i = const_cast<int *>(colIndices);
  int PetraError = aDCRSMatrix_->ReplaceMyValues(row, length, tmp_c, tmp_i);

  if (DEBUG_LINEAR || DEBUG_DEVICE)
    processError( "Matrix::putLocalRow - ", PetraError );

  return true;
}

//-----------------------------------------------------------------------------
// Function      : Matrix::insertRow
// Purpose       : Put a row into the sparse matrix.
// Special Notes : Insert into unallocated locations
// Scope         : Public
// Creator       : Scott A. Hutchinson, SNL, Parallel Computational Sciences
// Creation Date : 06/04/00
//-----------------------------------------------------------------------------
void Matrix::insertRow(int row, int length, double *coeffs, int *colIndices)
{
  int PetraError = oDCRSMatrix_->InsertGlobalValues(row, length, coeffs, colIndices);

  if (DEBUG_LINEAR)
    processError( "Matrix::insertRow - ", PetraError );
}

//-----------------------------------------------------------------------------
// Function      : Matrix::replaceLocalRow
// Purpose       : Replace a row in the sparse matrix.
// Special Notes : replace allocated locations
// Scope         : Public
// Creator       : Todd Coffey, 1414, Heidi Thornquist, 1437
// Creation Date : 01/31/07
//-----------------------------------------------------------------------------
void Matrix::replaceLocalRow(int row, int length, double *coeffs, int *colIndices)
{
  int PetraError = oDCRSMatrix_->ReplaceMyValues(row, length, coeffs, colIndices);

  if (DEBUG_LINEAR || DEBUG_DEVICE)
    processError( "Matrix::replaceLocalRow - ", PetraError );
}

//-----------------------------------------------------------------------------
// Function      : Matrix::getDiagonal
// Purpose       : Return the diagonal entries of the sparse matrix.
// Special Notes :
// Scope         : Public
// Creator       : Scott A. Hutchinson, SNL, Parallel Computational Sciences
// Creation Date : 06/04/00
//-----------------------------------------------------------------------------
void Matrix::getDiagonal( Vector & diagonal ) const
{
  int PetraError = aDCRSMatrix_->ExtractDiagonalCopy( *((*(diagonal.aMultiVector_))(0)) );

  if (DEBUG_LINEAR)
    processError( "Matrix::getDiagonal - ", PetraError );
}

//-----------------------------------------------------------------------------
// Function      : Matrix::replaceDiagonal
// Purpose       : Replace values of diagonal elements
// Special Notes :
// Scope         : Public
// Creator       : Robert Hoekstra, SNL, Parallel Computational Sciences
// Creation Date : 03/05/03
//-----------------------------------------------------------------------------
bool Matrix::replaceDiagonal( const Vector & vec )
{
  Epetra_Vector * eVec = vec.epetraVector();
  int PetraError = aDCRSMatrix_->ReplaceDiagonalValues( *eVec );
  delete eVec;

  if (DEBUG_LINEAR)
    processError( "Matrix::replaceDiagonal - ", PetraError );

  return true;
}

//-----------------------------------------------------------------------------
// Function      : Matrix::sumIntoDiagonal
// Purpose       : Sums values into diagonal elements
// Special Notes :
// Scope         : Public
// Creator       : Robert Hoekstra, SNL, Parallel Computational Sciences
// Creation Date : 03/05/03
//-----------------------------------------------------------------------------
bool Matrix::sumIntoDiagonal( const Vector & vec )
{
  Epetra_Vector * eVec = vec.epetraVector();
  Epetra_Vector nVec( *eVec );
  aDCRSMatrix_->ExtractDiagonalCopy( nVec );
  nVec.Update( 1.0, *eVec, 1.0 );
  int PetraError = aDCRSMatrix_->ReplaceDiagonalValues( nVec );
  delete eVec;

  if (DEBUG_LINEAR)
    processError( "Matrix::replaceDiagonal - ", PetraError );

  return true;
}

//-----------------------------------------------------------------------------
// Function      : Matrix::sumIntoRow
// Purpose       : Sum values into a row into the sparse matrix.
// Special Notes :
// Scope         : Public
// Creator       : Scott A. Hutchinson, SNL, Parallel Computational Sciences
// Creation Date : 06/04/00
//-----------------------------------------------------------------------------
bool Matrix::sumIntoRow(int row, int length, const double * coeffs,
                                                   const int * colIndices)
{
  double * tmp_c = const_cast<double *>(coeffs);
  int * tmp_i = const_cast<int *>(colIndices);
  int PetraError = oDCRSMatrix_->SumIntoGlobalValues(row, length, tmp_c, tmp_i);

  if (DEBUG_LINEAR || DEBUG_DEVICE)
    processError( "Matrix::sumIntoRow - ", PetraError );

  return true;
}

//-----------------------------------------------------------------------------
// Function      : Matrix::sumIntoLocalRow
// Purpose       : Sum values into a row into the sparse matrix, using local indices.
// Special Notes :
// Scope         : Public
// Creator       : Eric R. Keiter, SNL
// Creation Date : 04/30/10
//-----------------------------------------------------------------------------
bool Matrix::sumIntoLocalRow(int row, int length, const double * coeffs,
                                                   const int * colIndices)
{
  double * tmp_c = const_cast<double *>(coeffs);
  int * tmp_i = const_cast<int *>(colIndices);
  int PetraError = oDCRSMatrix_->SumIntoMyValues(row, length, tmp_c, tmp_i);

  if (DEBUG_LINEAR || DEBUG_DEVICE)
    processError( "Matrix::sumIntoLocalRow - ", PetraError );

  return true;
}

//-----------------------------------------------------------------------------
// Function      : Matrix::returnRawEntryPointer
//
// Purpose       : This function returns a raw double* pointer to a single
//                 matrix element, specified by the local row,col indices.
//
// Special Notes : This function is much more convenient for developers of the
//                 device package than dealing with local compressed rows and
//                 the offsets required to use the bracket operators.
//
// Scope         : Public
// Creator       : Eric R. Keiter, SNL
// Creation Date : 05/18/2010
//-----------------------------------------------------------------------------
double * Matrix::returnRawEntryPointer (int lidRow, int lidCol)
{
  double * retPtr=0;

  int num_entries;
  int * indices;
  double * values;

  oDCRSMatrix_->ExtractMyRowView( lidRow, num_entries, values, indices );

  for( int j = 0; j < num_entries; ++j )
  {
     if (indices[j] == lidCol)
     {
       retPtr = &(values[j]);
       break;
     }
  }

  return retPtr;
}

//-----------------------------------------------------------------------------
// Function      : Matrix::extractLocalRowView
// Purpose       :
// Special Notes :
// Scope         : Public
// Creator       : Eric R. Keiter, SNL
// Creation Date : 05/18/2010
//-----------------------------------------------------------------------------
int Matrix::extractLocalRowView(int lidRow, int& numEntries, double*& values, int*& indices) const
{
  return oDCRSMatrix_->ExtractMyRowView( lidRow, numEntries, values, indices );
}

//-----------------------------------------------------------------------------
// Function      : Matrix::extractLocalRowView
// Purpose       :
// Special Notes :
// Scope         : Public
// Creator       : Eric R. Keiter, SNL
// Creation Date : 05/18/2010
//-----------------------------------------------------------------------------
int Matrix::extractLocalRowView(int lidRow, int& numEntries, double*& values) const
{
  return oDCRSMatrix_->ExtractMyRowView( lidRow, numEntries, values);
}

//-----------------------------------------------------------------------------
// Function      : Matrix::sumIntoRowWithTest
// Purpose       : Sum values into a row into the sparse matrix.
// Special Notes : Tests for redundant indices and fixes
// Scope         : Public
// Creator       : Robert J. Hoekstra, SNL, Parallel Computational Sciences
// Creation Date : 01/04/00
//-----------------------------------------------------------------------------
bool Matrix::sumIntoRowWithTest(int row, int length, const double *coeffs,
                                                           const int *colIndices)
{
  int new_length = 0;
  std::vector<double> new_vals(length);
  std::vector<int> new_indices(length);

  int i, j;
  bool found;

  for( i = 0; i < length; ++i )
  {
    if( colIndices[i] != -1 )
    {
      found = false;
      for( j = 0; j < new_length; ++j )
        if( new_indices[j] == colIndices[i] )
        {
          new_vals[j] += coeffs[i];
          found = true;
          continue;
        }
      if( !found )
      {
        new_indices[new_length] = colIndices[i];
        new_vals[new_length] = coeffs[i];
        ++new_length;
      }
    }

  }

  sumIntoRow( row, new_length, &(new_vals[0]), &(new_indices[0]) );

  return true;
}

#ifdef Xyce_LOCAL_INDEX_MATRIX

//-----------------------------------------------------------------------------
// Function      : Matrix::sumIntoLocalRow
// Purpose       : Sum values into a row into the sparse matrix.
// Special Notes :
// Scope         : Public
// Creator       : Robert Hoekstra, SNL, Parallel Computational Sciences
// Creation Date : 06/24/02
//-----------------------------------------------------------------------------
bool Matrix::sumIntoLocalRow( int row,
                                    int length,
                                    const std::vector<double> & vals,
                                    const std::vector<int> & indices )
{
  int new_length = 0;
  bool found;
  int i, j;

  std::vector<double> new_vals(length);
  std::vector<int> new_indices(length);

  for( i = 0; i < length; ++i )
  {
    if( aDCRSMatrix_->GCID(indices[i]) != -1 )
    {
      found = false;
      for( j = 0; j < new_length; ++j )
        if( new_indices[j] == indices[i] )
        {
          new_vals[j] += vals[i];
          found = true;
          continue;
        }
      if( !found )
      {
        new_indices[new_length] = indices[i];
        new_vals[new_length] = vals[i];
        ++new_length;
      }
    }
  }

/*
  Xyce::dout() << "Matrix:sumIntoLocalRow\n";
  for( int i = 0; i < length; ++i )
    Xyce::dout() << i << " " << indices[i] << " " << vals[i] << std::endl;
  Xyce::dout() << "-----------------------\n";
  for( int i = 0; i < new_length; ++i )
    Xyce::dout() << i << " " << new_indices[i] << " " << new_vals[i] << std::endl;
  Xyce::dout() << "-----------------------\n";
*/

  int PetraError = aDCRSMatrix_->SumIntoMyValues( row, new_length, &new_vals[0], &new_indices[0] );

  if (DEBUG_LINEAR || DEBUG_DEVICE)
    processError( "Matrix::sumIntoLocalRow - ", PetraError );

  return true;
}

#endif


//-----------------------------------------------------------------------------
// Function      : Matrix::add
// Purpose       : Sums in a matrix contribution
// Special Notes : WARNING: only works if graphs match, no checking
// Scope         : Public
// Creator       : Robert J. Hoekstra, SNL, Parallel Computational Sciences
// Creation Date : 3/11/04
//-----------------------------------------------------------------------------
void Matrix::add( const Matrix & A )
{
  int NumRows = A.aDCRSMatrix_->NumMyRows();
  int* Indices;
  double* Values;
  int NumIndices;

  for( int i = 0; i < NumRows; ++i )
  {
    A.aDCRSMatrix_->ExtractMyRowView( i, NumIndices, Values, Indices );
    aDCRSMatrix_->SumIntoMyValues( i, NumIndices, Values, Indices );
  }
}

//-----------------------------------------------------------------------------
// Function      : Matrix::addOverlap
// Purpose       : Sums in a matrix contribution
// Special Notes : WARNING: only works if graphs match, no checking
// Scope         : Public
// Creator       : Robert J. Hoekstra, SNL, Parallel Computational Sciences
// Creation Date : 3/11/04
//-----------------------------------------------------------------------------
void Matrix::addOverlap( const Matrix & A )
{
  int NumRows = A.oDCRSMatrix_->NumMyRows();
  int* Indices;
  double* Values;
  int NumIndices;

  for( int i = 0; i < NumRows; ++i )
  {
    A.oDCRSMatrix_->ExtractMyRowView( i, NumIndices, Values, Indices );
    oDCRSMatrix_->SumIntoMyValues( i, NumIndices, Values, Indices );
  }
}

//-----------------------------------------------------------------------------
// Function      : Matrix::linearCombo
// Purpose       : Sums in a matrix contribution
// Special Notes : WARNING: only works if graphs EXACTLY match no checking
//
//                 this = a*A + b*B
//
// Scope         : Public
// Creator       : Eric Keiter
// Creation Date : 2/13/07
//-----------------------------------------------------------------------------
void Matrix::linearCombo( const double a, const Matrix & A,
                                const double b, const Matrix & B)
{
  int NumRows = (*aDCRSMatrix_).NumMyRows();

  int *aIndices, *bIndices;
  int aNumIndices, bNumIndices;
  double *aValues, *bValues;

  for( int i = 0; i < NumRows; ++i ) {
    // Get a view of the i-th row for A and B.
    A.aDCRSMatrix_->ExtractMyRowView( i, aNumIndices, aValues, aIndices );
    B.aDCRSMatrix_->ExtractMyRowView( i, bNumIndices, bValues, bIndices );

    // Add in the entries from each matrix.
    for ( int j = 0; j < aNumIndices; ++j )
      (*aDCRSMatrix_)[i][j] = a*aValues[j] + b*bValues[j];
  }
}

//-----------------------------------------------------------------------------
// Function      : Matrix::operator[]
// Purpose       : Direct access into matrix rows using local indexing
// Special Notes :
// Scope         : Public
// Creator       : Robert J. Hoekstra, SNL, Parallel Computational Sciences
// Creation Date : 9/5/02
//-----------------------------------------------------------------------------
double * Matrix::operator[]( int row )
{
  return (*oDCRSMatrix_)[row];
}

//-----------------------------------------------------------------------------
// Function      : Matrix::operator[] const
// Purpose       : Direct access into matrix rows using local indexing
// Special Notes : const version
// Scope         : Public
// Creator       : Robert J. Hoekstra, SNL, Parallel Computational Sciences
// Creation Date : 9/5/02
//-----------------------------------------------------------------------------
double * Matrix::operator[]( int row ) const
{
  return (*oDCRSMatrix_)[row];
}

//-----------------------------------------------------------------------------
// Function      : Matrix::rowMax
// Purpose       : Returns the maximum absolute value of the entries in the
//                 row.
// Special Notes :
// Scope         : Public
// Creator       : Scott A. Hutchinson, SNL, Parallel Computational Sciences
// Creation Date : 06/04/00
//-----------------------------------------------------------------------------
double Matrix::rowMax(int row) const
{
  if (DEBUG_LINEAR)
    Report::DevelFatal().in("Matrix::rowMax")
      << "Not Available with Current Petra";

  return false;
}

//-----------------------------------------------------------------------------
// Function      : Matrix::writeToFile
// Purpose       : Dumps out the sparse matrix to a file.
// Special Notes :
// Scope         : Public
// Creator       : Scott A. Hutchinson, SNL, Parallel Computational Sciences
// Creation Date : 06/19/00
//-----------------------------------------------------------------------------
void Matrix::writeToFile(const char *filename, bool useLIDs, bool mmFormat )
{
  if (!mmFormat)
  {
    int numProcs = aDCRSMatrix_->Comm().NumProc();
    int thisProc = aDCRSMatrix_->Comm().MyPID();
    int masterRank = 0;

    int MaxNumEntries = aDCRSMatrix_->MaxNumEntries();
    std::vector<int> Indices( MaxNumEntries );
    std::vector<double> Values( MaxNumEntries );
    int NumEntries;
    int NumMyRows = aDCRSMatrix_->NumMyRows();

    if( !aDCRSMatrix_->Filled() )
    {
      std::cerr << "Matrix: can't writeToFile unless Filled!" << std::endl;
      return;
    }

    for( int p = 0; p < numProcs; ++p )
    {
      aDCRSMatrix_->Comm().Barrier();

      if( p == thisProc )
      {
        FILE *file = NULL;

        if( masterRank == thisProc )
        {
          file = fopen( filename, "w" );
          fprintf( file, "%d\n", aDCRSMatrix_->NumGlobalNonzeros() );
        }
        else
          file = fopen( filename, "a" );

        for( int i = 0; i < NumMyRows; ++i )
        {

          if( useLIDs )
          {
            int num_entries;
            int * indices;
            double * values;
            aDCRSMatrix_->ExtractMyRowView( i, num_entries, values, indices );
            for( int j = 0; j < num_entries; ++j )
             fprintf( file, "%d %d %26.18e\n", i, indices[j], values[j] );
          }
          else
          {
            int Row = aDCRSMatrix_->Graph().RowMap().GID(i);

            aDCRSMatrix_->ExtractGlobalRowCopy( Row, MaxNumEntries, NumEntries, &Values[0], &Indices[0] );

            for( int j = 0; j < NumEntries; ++j )
             fprintf( file, "%d %d %26.18e\n", Row, Indices[j], Values[j] );
          }
        }

        fclose( file );
      }
    }
  }
  else
  {
    std::string sandiaReq = "Sandia National Laboratories is a multi-program laboratory managed and operated by Sandia Corporation,\n%";
    sandiaReq += " a wholly owned subsidiary of Lockheed Martin Corporation, for the U.S. Department of Energy's National Nuclear \n%";
    sandiaReq += " Security Administration under contract DE-AC04-94AL85000.\n%\n% Xyce circuit matrix.\n%%";

    EpetraExt::RowMatrixToMatrixMarketFile( filename, *aDCRSMatrix_, sandiaReq.c_str() );
  }
}

//-----------------------------------------------------------------------------
// Function      : Matrix::processError
// Purpose       : Concrete implementation which processes Petra (in this case)
//                 error codes taken from the Petra member function returns.
// Special Notes : Petra specific.  NOTE ALSO - this function is currently
//                 within the "Xyce_DEBUG_LINEAR" ifdef and so any calls to
//                 this should also be so bracketed.
// Scope         : Private
// Creator       : Scott A. Hutchinson, SNL, Parallel Computational Sciences
// Creation Date : 06/04/00
//-----------------------------------------------------------------------------
void Matrix::processError(std::string methodMsg, int error) const
{

  const std::string PetraError("Function returned with an error.\n");

  // Process the error
  if( error < 0 )
    Report::DevelFatal0() << methodMsg + PetraError;

}

//-----------------------------------------------------------------------------
// Function      : operator<<
// Purpose       : output stream pipe operator for Matrix
// Special Notes :
// Scope         : Public
// Creator       : Robert Hoekstra, SNL, Parallel Computational Sciences
// Creation Date : 07/14/00
//-----------------------------------------------------------------------------
void Matrix::printPetraObject(std::ostream &os) const
{
  if (oDCRSMatrix_ != aDCRSMatrix_)
  {
    os << *oDCRSMatrix_;
  }
  os << *aDCRSMatrix_;
}

//-----------------------------------------------------------------------------
// Function      : Matrix::setUseTranspose
// Purpose       :
// Special Notes :
// Scope         : Public
// Creator       : Eric R. Keiter, SNL, Parallel Computational Sciences
// Creation Date : 11/20/02
//-----------------------------------------------------------------------------
int Matrix::setUseTranspose (bool useTranspose)
{
  return aDCRSMatrix_->SetUseTranspose(useTranspose);
}

//-----------------------------------------------------------------------------
// Function      : Matrix::useTranspose
// Purpose       :
// Special Notes :
// Scope         : Public
// Creator       : Eric R. Keiter, SNL, Parallel Computational Sciences
// Creation Date : 11/20/02
//-----------------------------------------------------------------------------
bool Matrix::useTranspose ()
{
  return aDCRSMatrix_->UseTranspose();
}

} // namespace Linear
} // namespace Xyce
